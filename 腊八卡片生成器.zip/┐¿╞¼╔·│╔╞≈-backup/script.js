// 全局变量
let currentPage = 1;
let totalPages = 5;
let currentCardType = 'cover';
let cardData = [];
let currentColorSchemes = {
    cover: 'apple-ios',
    content: 'apple-ios'
};

// 样式设置
let styleSettings = {
    // 封面样式设置
    cover: {
        mainTitleSize: 24,
        mainTitleColor: '#ffffff',
        subTitleSize: 20,
        subTitleColor: '#ffffff',
        descriptionSize: 15,
        descriptionColor: '#ffffff',
        fontFamily: "'Yozai', serif"
    },
    // 内容样式设置
    content: {
        titleSize: 24,
        titleWeight: 'bold',
        titleColor: '#333333',
        titleAlign: 'left',
        contentSize: 14,
        contentColor: '#666666',
        contentLineHeight: 1.5,
        contentParagraphSpacing: 12,
        textAlign: 'left',
        fontFamily: "'Yozai', serif",
        showTitle: true
    }
};

// 封面元素变换状态
let coverElementsTransform = {
    title: {
        x: 0,
        y: 0
    },
    subtitle: {
        x: 0,
        y: 0,
        rotate: 0
    },
    description: {
        x: 0,
        y: 0
    }
};

// 拖拽状态
let isDragging = false;
let isRotating = false;
let dragStartX = 0;
let dragStartY = 0;
let rotationStartAngle = 0;
let selectedElement = null;

// 渐变背景设置
let gradientSettings = {
    cover: {
        type: 'linear',
        angle: 135,
        color1: '#ff6b6b',
        color2: '#ee5a6f'
    },
    content: {
        type: 'linear',
        angle: 135,
        color1: '#ff6b6b',
        color2: '#ee5a6f'
    }
};

// 卡片样式设置
let cardStyleSettings = {
    cover: {
        borderWidth: 2,
        borderColor: '#ff2442',
        borderRadius: 16
    },
    content: {
        borderWidth: 2,
        borderColor: '#ff2442',
        borderRadius: 16
    }
};

// 背景图片设置
let backgroundImageData = {
    cover: {
        image: null,
        useImage: true,
        opacity: 0
    },
    content: {
        image: null,
        useImage: true,
        opacity: 0
    }
};

// 配色方案
const colorSchemes = {
    'apple-ios': {
        gradientColor1: '#FFFFFF',
        gradientColor2: '#F2F2F7',
        textColor: '#000000',
        secondaryTextColor: '#8E8E93',
        borderColor: '#C7C7CC',
        accentColor: '#007AFF'
    },
    'pastel-palette': {
        gradientColor1: '#FEFFFF',
        gradientColor2: '#F0F4C3',
        textColor: '#000000',
        secondaryTextColor: '#795548',
        borderColor: '#BDBDBD',
        accentColor: '#FFAB40'
    },
    'classic-blue-white': {
        gradientColor1: '#FFFFFF',
        gradientColor2: '#E3F2FD',
        textColor: '#1A237E',
        secondaryTextColor: '#64B5F6',
        borderColor: '#BBDEFB',
        accentColor: '#1976D2'
    },
    'macaron-garden': {
        gradientColor1: '#F5F5DC',
        gradientColor2: '#D1E8E2',
        textColor: '#343A40',
        secondaryTextColor: '#6C757D',
        borderColor: '#ADB5BD',
        accentColor: '#9CE7B5'
    },
    'macaron-lavender': {
        gradientColor1: '#E6E6FA',
        gradientColor2: '#F0FFF0',
        textColor: '#343A40',
        secondaryTextColor: '#6C757D',
        borderColor: '#ADB5BD',
        accentColor: '#DDA0DD'
    },
    'stationery-style': {
        gradientColor1: '#FFFFF0',
        gradientColor2: '#F5F5DC',
        textColor: '#343A40',
        secondaryTextColor: '#6C757D',
        borderColor: '#D2B48C',
        accentColor: '#8B4513'
    }
};

// 初始化
async function init() {
    try {
        // 首先初始化事件监听器，确保所有功能按钮都能正常工作
        initEventListeners();
        
        // 然后加载卡片数据
        await loadCardData();
        
        // 加载当前页面数据
        loadCurrentPageData();
        
        // 切换卡片类型显示
        if (currentCardType === 'cover') {
            document.getElementById('cover-edit-section').style.display = 'block';
            document.getElementById('content-edit-section').style.display = 'none';
            document.getElementById('pagination-section').style.display = 'none';
        } else {
            document.getElementById('content-edit-section').style.display = 'block';
            document.getElementById('cover-edit-section').style.display = 'none';
            document.getElementById('pagination-section').style.display = 'block';
        }
        
        // 应用配色方案
        applyColorScheme('apple-ios', 'cover');
        applyColorScheme('apple-ios', 'content');
        
        // 同步styleSettings到UI中的颜色选择框
        const coverMainTitleColor = document.getElementById('cover-main-title-color');
        const coverSubTitleColor = document.getElementById('cover-sub-title-color');
        const coverDescriptionColor = document.getElementById('cover-description-color');
        const titleFontColor = document.getElementById('title-font-color');
        const contentFontColor = document.getElementById('content-font-color');
        
        if (coverMainTitleColor) coverMainTitleColor.value = styleSettings.cover.mainTitleColor;
        if (coverSubTitleColor) coverSubTitleColor.value = styleSettings.cover.subTitleColor;
        if (coverDescriptionColor) coverDescriptionColor.value = styleSettings.cover.descriptionColor;
        if (titleFontColor) titleFontColor.value = styleSettings.content.titleColor;
        if (contentFontColor) contentFontColor.value = styleSettings.content.contentColor;
        
        // 设置字体选择器
        const coverFontFamily = document.getElementById('cover-font-family');
        const contentFontFamily = document.getElementById('font-family');
        if (coverFontFamily) coverFontFamily.value = styleSettings.cover.fontFamily;
        if (contentFontFamily) contentFontFamily.value = styleSettings.content.fontFamily;
        
        // 默认勾选使用背景图片复选框
        const useCoverBackgroundImageCheckbox = document.getElementById('use-cover-background-image-checkbox');
        const useContentBackgroundImageCheckbox = document.getElementById('use-content-background-image-checkbox');
        if (useCoverBackgroundImageCheckbox) useCoverBackgroundImageCheckbox.checked = true;
        if (useContentBackgroundImageCheckbox) useContentBackgroundImageCheckbox.checked = true;
        
        // 更新预览
        updatePreview();
    } catch (error) {
        console.error('初始化失败:', error);
        showStatus('初始化失败', 'error');
    }
}

// 加载卡片数据
async function loadCardData() {
    try {
        cardData = [
            {
                title: "本世纪第二晚的腊八节",
                content: "2026年1月26日的腊八节特别引人关注，因为它是本世纪第二晚的腊八节，仅仅比2084年1月27日的腊八节早一天。我查了一下资料，发现这种现象其实和咱们老祖宗传下来的农历置闰规则密切相关。\n\n你知道吗，2025年农历有一个闰十月，这就把整个农历年拉长了，结果腊月（也就是农历十二月）就跟着往后推迟了，腊八节作为农历十二月初八，对应的公历日期自然也就延后了。"
            },
            {
                title: "置闰：传统历法的智慧",
                content: "说到农历，咱们都知道它是阴阳合历，既要跟着月亮的阴晴圆缺走，又要兼顾太阳公转的周期。可你知道吗，月亮绕地球一圈大概是29.5天，12个月下来也就354天左右，比太阳公转的365天少了11天左右。\n\n为了让这两个周期对上，古人就发明了置闰法，差不多每19年要加7个闰月。我觉得这置闰规则特别有意思，就像大自然的时间调节器一样。"
            },
            {
                title: "腊八节的传统习俗",
                content: "腊八节的习俗可丰富了，我最熟悉的就是喝腊八粥。我记得小时候，每到腊八节，我妈一大早就起来熬粥，锅里放着大米、小米、红豆、绿豆、花生、枣子等好多食材，整个家里都飘着香味。\n\n民间还有句俗语叫\"腊八腊八，冻掉下巴\"，意思是说腊八前后天气特别冷，喝碗热乎的腊八粥正好暖和暖和。"
            },
            {
                title: "传统节日的现代意义",
                content: "现在大家平时都挺忙的，每天跟着公历的节奏跑，很少有时间停下来想想生活的意义。我觉得传统节日就像一个个锚点，提醒我们慢下来，陪陪家人，感受一下生活的仪式感。\n\n就拿腊八节来说，不管多忙，我都会抽空自己熬一锅粥，哪怕简单点，也觉得心里踏实。"
            },
            {
                title: "节日的文化温度",
                content: "我觉得节日的真正意义不在于它具体在哪一天，而在于它所承载的文化温度。今年的腊八节虽然来得特别晚，但那份温暖的感觉一点都没少。早上我给家里打电话，我妈说她又熬了腊八粥，还说等我回家的时候再给我做。\n\n你看，这就是节日的力量——不管相隔多远，它总能把家人的心连在一起。"
            }
        ];
        
        totalPages = cardData.length;
        const totalPagesElement = document.getElementById('total-pages');
        const pageInputElement = document.getElementById('page-input');
        
        if (totalPagesElement) totalPagesElement.textContent = totalPages;
        if (pageInputElement) {
            pageInputElement.max = totalPages;
            pageInputElement.value = 1;
        }
        
    } catch (error) {
        console.error('加载卡片数据失败:', error);
        showStatus('加载卡片数据失败', 'error');
    }
}

// 初始化事件监听器
function initEventListeners() {
    // 文档选择和加载
    const documentUploadBtn = document.getElementById('load-document-btn');
    const documentUploadInput = document.getElementById('document-upload');
    
    if (documentUploadBtn && documentUploadInput) {
        documentUploadBtn.addEventListener('click', () => {
            documentUploadInput.click();
        });
        documentUploadInput.addEventListener('change', loadDocument);
    }
    
    // 卡片类型切换
    const coverCardBtn = document.getElementById('cover-card-btn');
    const contentCardBtn = document.getElementById('content-card-btn');
    
    if (coverCardBtn) {
        coverCardBtn.addEventListener('click', () => {
            switchCardType('cover');
        });
    }
    
    if (contentCardBtn) {
        contentCardBtn.addEventListener('click', () => {
            switchCardType('content');
        });
    }
    
    // 分页控制
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const jumpPageBtn = document.getElementById('jump-page-btn');
    
    if (prevPageBtn) {
        prevPageBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                updatePageInfo();
                loadCurrentPageData();
                updatePreview();
            }
        });
    }
    
    if (nextPageBtn) {
        nextPageBtn.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                updatePageInfo();
                loadCurrentPageData();
                updatePreview();
            }
        });
    }
    
    if (jumpPageBtn) {
        jumpPageBtn.addEventListener('click', () => {
            const pageInput = document.getElementById('page-input');
            if (pageInput) {
                const pageNum = parseInt(pageInput.value);
                if (pageNum >= 1 && pageNum <= totalPages) {
                    currentPage = pageNum;
                    updatePageInfo();
                    loadCurrentPageData();
                    updatePreview();
                }
            }
        });
    }
    
    // 内容编辑
    const coverMainTitle = document.getElementById('cover-main-title');
    const coverSubTitle = document.getElementById('cover-sub-title');
    const coverDescription = document.getElementById('cover-description');
    const cardTitle = document.getElementById('card-title');
    const cardContent = document.getElementById('card-content');
    
    if (coverMainTitle) coverMainTitle.addEventListener('input', updatePreview);
    if (coverSubTitle) coverSubTitle.addEventListener('input', updatePreview);
    if (coverDescription) coverDescription.addEventListener('input', updatePreview);
    if (cardTitle) cardTitle.addEventListener('input', updatePreview);
    if (cardContent) cardContent.addEventListener('input', updatePreview);
    
    // 封面样式设置事件监听器
    const coverMainTitleSize = document.getElementById('cover-main-title-size');
    const coverMainTitleColor = document.getElementById('cover-main-title-color');
    const coverSubTitleSize = document.getElementById('cover-sub-title-size');
    const coverSubTitleColor = document.getElementById('cover-sub-title-color');
    const coverDescriptionSize = document.getElementById('cover-description-size');
    const coverDescriptionColor = document.getElementById('cover-description-color');
    const coverFontFamily = document.getElementById('cover-font-family');
    
    if (coverMainTitleSize) {
        coverMainTitleSize.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('cover-main-title-size-value').textContent = `${value}px`;
            updatePreview();
        });
    }
    
    if (coverMainTitleColor) coverMainTitleColor.addEventListener('input', updatePreview);
    if (coverSubTitleSize) {
        coverSubTitleSize.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('cover-sub-title-size-value').textContent = `${value}px`;
            updatePreview();
        });
    }
    if (coverSubTitleColor) coverSubTitleColor.addEventListener('input', updatePreview);
    if (coverDescriptionSize) {
        coverDescriptionSize.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('cover-description-size-value').textContent = `${value}px`;
            updatePreview();
        });
    }
    if (coverDescriptionColor) coverDescriptionColor.addEventListener('input', updatePreview);
    if (coverFontFamily) coverFontFamily.addEventListener('change', updatePreview);
    
    // 内容编辑样式设置事件监听器
    const titleFontSize = document.getElementById('title-font-size');
    const titleFontWeight = document.getElementById('title-font-weight');
    const titleFontColor = document.getElementById('title-font-color');
    const contentLineHeight = document.getElementById('content-line-height');
    const contentFontSize = document.getElementById('content-font-size');
    const contentFontColor = document.getElementById('content-font-color');
    const textAlign = document.getElementById('text-align');
    const fontFamily = document.getElementById('font-family');
    const showTitleCheckbox = document.getElementById('show-title-checkbox');
    
    if (titleFontSize) {
        titleFontSize.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('title-font-size-value').textContent = `${value}px`;
            updatePreview();
        });
    }
    if (titleFontWeight) titleFontWeight.addEventListener('change', updatePreview);
    if (titleFontColor) titleFontColor.addEventListener('input', updatePreview);
    if (contentLineHeight) {
        contentLineHeight.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('content-line-height-value').textContent = value;
            updatePreview();
        });
    }
    
    // 段落间距设置事件监听器
    const contentParagraphSpacing = document.getElementById('content-paragraph-spacing');
    if (contentParagraphSpacing) {
        contentParagraphSpacing.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('content-paragraph-spacing-value').textContent = `${value}px`;
            updatePreview();
        });
    }
    if (contentFontSize) {
        contentFontSize.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('content-font-size-value').textContent = `${value}px`;
            updatePreview();
        });
    }
    if (contentFontColor) contentFontColor.addEventListener('input', updatePreview);
    if (textAlign) textAlign.addEventListener('change', updatePreview);
    if (fontFamily) fontFamily.addEventListener('change', updatePreview);
    if (showTitleCheckbox) {
        showTitleCheckbox.addEventListener('change', updatePreview);
        showTitleCheckbox.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
    
    // 标题对齐方式
    const titleTextAlign = document.getElementById('title-text-align');
    if (titleTextAlign) {
        titleTextAlign.addEventListener('change', updatePreview);
    }
    
    // 背景图片设置事件监听器
    const loadCoverBackgroundImageBtn = document.getElementById('load-cover-background-image-btn');
    const coverBackgroundImageUpload = document.getElementById('cover-background-image-upload');
    const useCoverBackgroundImageCheckbox = document.getElementById('use-cover-background-image-checkbox');
    const coverBackgroundImageOpacity = document.getElementById('cover-background-image-opacity');
    const loadContentBackgroundImageBtn = document.getElementById('load-content-background-image-btn');
    const contentBackgroundImageUpload = document.getElementById('content-background-image-upload');
    const useContentBackgroundImageCheckbox = document.getElementById('use-content-background-image-checkbox');
    const contentBackgroundImageOpacity = document.getElementById('content-background-image-opacity');
    
    if (loadCoverBackgroundImageBtn && coverBackgroundImageUpload) {
        loadCoverBackgroundImageBtn.addEventListener('click', () => {
            coverBackgroundImageUpload.click();
        });
        coverBackgroundImageUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    backgroundImageData.cover.image = e.target.result;
                    updatePreview();
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    if (useCoverBackgroundImageCheckbox) {
        useCoverBackgroundImageCheckbox.addEventListener('change', function() {
            backgroundImageData.cover.useImage = this.checked;
            updatePreview();
        });
    }
    if (coverBackgroundImageOpacity) {
        coverBackgroundImageOpacity.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('cover-background-image-opacity-value').textContent = `${value}%`;
            backgroundImageData.cover.opacity = value;
            updatePreview();
        });
    }
    
    if (loadContentBackgroundImageBtn && contentBackgroundImageUpload) {
        loadContentBackgroundImageBtn.addEventListener('click', () => {
            contentBackgroundImageUpload.click();
        });
        contentBackgroundImageUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    backgroundImageData.content.image = e.target.result;
                    updatePreview();
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    if (useContentBackgroundImageCheckbox) {
        useContentBackgroundImageCheckbox.addEventListener('change', function() {
            backgroundImageData.content.useImage = this.checked;
            updatePreview();
        });
    }
    if (contentBackgroundImageOpacity) {
        contentBackgroundImageOpacity.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('content-background-image-opacity-value').textContent = `${value}%`;
            backgroundImageData.content.opacity = value;
            updatePreview();
        });
    }
    
    // 卡片描边设置事件监听器
    const borderWidth = document.getElementById('border-width');
    const borderColor = document.getElementById('border-color');
    
    if (borderWidth) {
        borderWidth.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('border-width-value').textContent = `${value}px`;
            cardStyleSettings[currentCardType].borderWidth = value;
            updatePreview();
        });
    }
    
    if (borderColor) {
        borderColor.addEventListener('input', function() {
            cardStyleSettings[currentCardType].borderColor = this.value;
            updatePreview();
        });
    }
    
    // 渐变背景设置事件监听器
    const gradientType = document.getElementById('gradient-type');
    const gradientAngle = document.getElementById('gradient-angle');
    const gradientColor1 = document.getElementById('gradient-color-1');
    const gradientColor2 = document.getElementById('gradient-color-2');
    
    if (gradientType) {
        gradientType.addEventListener('change', function() {
            gradientSettings[currentCardType].type = this.value;
            updatePreview();
        });
    }
    
    if (gradientAngle) {
        gradientAngle.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('gradient-angle-value').textContent = `${value}°`;
            gradientSettings[currentCardType].angle = value;
            updatePreview();
        });
    }
    
    if (gradientColor1) {
        gradientColor1.addEventListener('input', function() {
            gradientSettings[currentCardType].color1 = this.value;
            updatePreview();
        });
    }
    
    if (gradientColor2) {
        gradientColor2.addEventListener('input', function() {
            gradientSettings[currentCardType].color2 = this.value;
            updatePreview();
        });
    }
    
    // 视觉效果设置事件监听器
    const cardRadius = document.getElementById('card-radius');
    
    if (cardRadius) {
        cardRadius.addEventListener('input', function() {
            const value = this.value;
            document.getElementById('card-radius-value').textContent = `${value}px`;
            cardStyleSettings[currentCardType].borderRadius = value;
            updatePreview();
        });
    }
    
    // 配色方案选择事件监听器
    const colorSchemes = document.querySelectorAll('.color-scheme');
    colorSchemes.forEach(scheme => {
        scheme.addEventListener('click', function() {
            const schemeName = this.dataset.scheme;
            applyColorScheme(schemeName, currentCardType);
            
            // 更新选中状态
            colorSchemes.forEach(s => s.classList.remove('active'));
            this.classList.add('active');
        });
    })
    
    // 下载功能
    const downloadCurrentBtn = document.getElementById('download-current-btn');
    const batchDownloadBtn = document.getElementById('batch-download-btn');
    
    if (downloadCurrentBtn) {
        downloadCurrentBtn.addEventListener('click', downloadCurrentCard);
    }
    
    if (batchDownloadBtn) {
        batchDownloadBtn.addEventListener('click', batchDownloadCards);
    }
    
    // 配置导入导出功能
    const importConfigBtn = document.getElementById('import-config-btn');
    const exportConfigBtn = document.getElementById('export-config-btn');
    const configUpload = document.getElementById('config-upload');
    
    if (importConfigBtn) importConfigBtn.addEventListener('click', importConfig);
    if (exportConfigBtn) exportConfigBtn.addEventListener('click', exportConfig);
    if (configUpload) configUpload.addEventListener('change', handleConfigFileSelect);
    
    // 封面元素交互功能
    const titleContainer = document.getElementById('title-container');
    const subtitleContainer = document.getElementById('subtitle-container');
    const descriptionContainer = document.getElementById('description-container');
    const rotateHandle = document.getElementById('rotate-handle');
    
    if (titleContainer && subtitleContainer && descriptionContainer) {
        // 点击事件 - 选择/取消选择
        titleContainer.addEventListener('click', function(e) {
            e.stopPropagation();
            selectedElement = selectedElement === 'title' ? null : 'title';
            updateElementsTransform();
        });
        
        subtitleContainer.addEventListener('click', function(e) {
            e.stopPropagation();
            selectedElement = 'subtitle';
            updateElementsTransform();
        });
        
        descriptionContainer.addEventListener('click', function(e) {
            e.stopPropagation();
            selectedElement = selectedElement === 'description' ? null : 'description';
            updateElementsTransform();
        });
        
        // 点击其他地方 - 取消选择（但保留封面小标题的选择状态）
        document.addEventListener('click', function(e) {
            if (!titleContainer.contains(e.target) && 
                !subtitleContainer.contains(e.target) && 
                !descriptionContainer.contains(e.target) &&
                selectedElement !== 'subtitle') {
                selectedElement = null;
                updateElementsTransform();
            }
        });
        
        // 鼠标按下事件 - 开始拖拽
        function startDrag(element, e) {
            isDragging = true;
            selectedElement = element;
            dragStartX = e.clientX - coverElementsTransform[element].x;
            dragStartY = e.clientY - coverElementsTransform[element].y;
            updateElementsTransform();
        }
        
        titleContainer.addEventListener('mousedown', function(e) {
            startDrag('title', e);
        });
        
        subtitleContainer.addEventListener('mousedown', function(e) {
            if (e.target === rotateHandle) return;
            startDrag('subtitle', e);
        });
        
        descriptionContainer.addEventListener('mousedown', function(e) {
            startDrag('description', e);
        });
        
        // 鼠标移动事件 - 拖拽中
        document.addEventListener('mousemove', function(e) {
            if (isDragging && selectedElement) {
                coverElementsTransform[selectedElement].x = e.clientX - dragStartX;
                coverElementsTransform[selectedElement].y = e.clientY - dragStartY;
                updateElementsTransform();
            } else if (isRotating && selectedElement === 'subtitle') {
                const containerRect = subtitleContainer.getBoundingClientRect();
                const centerX = containerRect.left + containerRect.width / 2;
                const centerY = containerRect.top + containerRect.height / 2;
                
                const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI;
                coverElementsTransform.subtitle.rotate = angle - rotationStartAngle;
                updateElementsTransform();
            }
        });
        
        // 鼠标释放事件 - 结束拖拽
        document.addEventListener('mouseup', function() {
            isDragging = false;
            isRotating = false;
        });
        
        // 旋转控制点鼠标按下事件 - 开始旋转
        if (rotateHandle) {
            rotateHandle.addEventListener('mousedown', function(e) {
                e.stopPropagation();
                isRotating = true;
                
                const containerRect = subtitleContainer.getBoundingClientRect();
                const centerX = containerRect.left + containerRect.width / 2;
                const centerY = containerRect.top + containerRect.height / 2;
                
                rotationStartAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI - coverElementsTransform.subtitle.rotate;
            });
        }
}

// 切换卡片类型
function switchCardType(type) {
    currentCardType = type;
    
    // 更新按钮状态
    const coverCardBtn = document.getElementById('cover-card-btn');
    const contentCardBtn = document.getElementById('content-card-btn');
    
    if (coverCardBtn && contentCardBtn) {
        if (type === 'cover') {
            coverCardBtn.classList.remove('btn-secondary');
            coverCardBtn.classList.add('btn-primary');
            contentCardBtn.classList.remove('btn-primary');
            contentCardBtn.classList.add('btn-secondary');
            
            // 显示封面卡片，隐藏内容卡片
            const coverCard = document.getElementById('cover-card');
            const contentCard = document.getElementById('content-card');
            
            if (coverCard) coverCard.style.display = 'flex';
            if (contentCard) contentCard.style.display = 'none';
            
            // 显示封面编辑区，隐藏内容编辑区
            const coverEditSection = document.getElementById('cover-edit-section');
            const contentEditSection = document.getElementById('content-edit-section');
            const paginationSection = document.getElementById('pagination-section');
            
            if (coverEditSection) coverEditSection.style.display = 'block';
            if (contentEditSection) contentEditSection.style.display = 'none';
            if (paginationSection) paginationSection.style.display = 'none';
        } else {
            contentCardBtn.classList.remove('btn-secondary');
            contentCardBtn.classList.add('btn-primary');
            coverCardBtn.classList.remove('btn-primary');
            coverCardBtn.classList.add('btn-secondary');
            
            // 显示内容卡片，隐藏封面卡片
            const coverCard = document.getElementById('cover-card');
            const contentCard = document.getElementById('content-card');
            
            if (contentCard) contentCard.style.display = 'flex';
            if (coverCard) coverCard.style.display = 'none';
            
            // 显示内容编辑区，隐藏封面编辑区
            const contentEditSection = document.getElementById('content-edit-section');
            const coverEditSection = document.getElementById('cover-edit-section');
            const paginationSection = document.getElementById('pagination-section');
            
            if (contentEditSection) contentEditSection.style.display = 'block';
            if (coverEditSection) coverEditSection.style.display = 'none';
            if (paginationSection) paginationSection.style.display = 'block';
        }
    }
    
    // 切换到内容卡片时，加载当前页面数据
    if (type === 'content') {
        loadCurrentPageData();
    }
    
    // 更新预览
    updatePreview();
}

// 更新元素变换
function updateElementsTransform() {
    const coverTitle = document.getElementById('preview-cover-title');
    const coverSubtitle = document.getElementById('preview-cover-subtitle');
    const coverDescription = document.getElementById('preview-cover-description');
    const rotateHandle = document.getElementById('rotate-handle');
    
    if (coverTitle) {
        coverTitle.style.transform = `translate(${coverElementsTransform.title.x}px, ${coverElementsTransform.title.y}px)`;
    }
    
    if (coverSubtitle) {
        coverSubtitle.style.transform = `translate(${coverElementsTransform.subtitle.x}px, ${coverElementsTransform.subtitle.y}px) rotate(${coverElementsTransform.subtitle.rotate}deg)`;
    }
    
    if (coverDescription) {
        coverDescription.style.transform = `translate(${coverElementsTransform.description.x}px, ${coverElementsTransform.description.y}px)`;
    }
    
    // 显示/隐藏旋转控制点
    if (rotateHandle) {
        if (selectedElement === 'subtitle') {
            rotateHandle.style.display = 'block';
            const subtitleContainer = document.getElementById('subtitle-container');
            if (subtitleContainer) {
                rotateHandle.style.top = '-15px';
                rotateHandle.style.right = '-15px';
            }
        } else {
            rotateHandle.style.display = 'none';
        }
    }
    
    // 显示/隐藏边界框
    const subtitleBoundingBox = document.getElementById('subtitle-bounding-box');
    if (subtitleBoundingBox) {
        if (selectedElement === 'subtitle') {
            subtitleBoundingBox.style.display = 'block';
        } else {
            subtitleBoundingBox.style.display = 'none';
        }
    }
}

// 更新分页信息
function updatePageInfo() {
    const currentPageElement = document.getElementById('current-page');
    const pageInput = document.getElementById('page-input');
    const pageNumberElement = document.getElementById('page-number');
    
    if (currentPageElement) currentPageElement.textContent = currentPage;
    if (pageInput) pageInput.value = currentPage;
    if (pageNumberElement) pageNumberElement.textContent = `第${currentPage}页`;
}

// 加载当前页面数据
function loadCurrentPageData() {
    if (cardData.length > 0 && currentPage <= cardData.length) {
        const data = cardData[currentPage - 1];
        const cardTitle = document.getElementById('card-title');
        const cardContent = document.getElementById('card-content');
        
        if (cardTitle) cardTitle.value = data.title;
        if (cardContent) cardContent.value = data.content;
    }
}

// 应用配色方案
function applyColorScheme(schemeName, cardType) {
    const scheme = colorSchemes[schemeName];
    if (scheme) {
        if (cardType === 'cover') {
            // 应用封面文字颜色
            const coverMainTitleColor = document.getElementById('cover-main-title-color');
            const coverSubTitleColor = document.getElementById('cover-sub-title-color');
            const coverDescriptionColor = document.getElementById('cover-description-color');
            
            if (coverMainTitleColor) {
                coverMainTitleColor.value = scheme.textColor;
                styleSettings.cover.mainTitleColor = scheme.textColor;
            }
            if (coverSubTitleColor) {
                coverSubTitleColor.value = scheme.secondaryTextColor;
                styleSettings.cover.subTitleColor = scheme.secondaryTextColor;
            }
            if (coverDescriptionColor) {
                coverDescriptionColor.value = scheme.secondaryTextColor;
                styleSettings.cover.descriptionColor = scheme.secondaryTextColor;
            }
        } else {
            // 应用内容卡片文字颜色
            const titleFontColor = document.getElementById('title-font-color');
            const contentFontColor = document.getElementById('content-font-color');
            
            if (titleFontColor) {
                titleFontColor.value = scheme.textColor;
                styleSettings.content.titleColor = scheme.textColor;
            }
            if (contentFontColor) {
                contentFontColor.value = scheme.secondaryTextColor;
                styleSettings.content.contentColor = scheme.secondaryTextColor;
            }
        }
        
        // 应用渐变颜色
        gradientSettings[currentCardType].color1 = scheme.gradientColor1;
        gradientSettings[currentCardType].color2 = scheme.gradientColor2;
        
        // 更新预览
        updatePreview();
    }
}

// 更新预览
function updatePreview() {
    // 获取封面内容
    const coverMainTitle = document.getElementById('cover-main-title')?.value || '腊八节知识卡片';
    const coverSubTitle = document.getElementById('cover-sub-title')?.value || '传统节日的文化温度与智慧';
    const coverDescription = document.getElementById('cover-description')?.value || '';
    
    // 获取封面样式设置
    const coverMainTitleSize = document.getElementById('cover-main-title-size')?.value || 24;
    const coverMainTitleColor = document.getElementById('cover-main-title-color')?.value || '#ffffff';
    const coverSubTitleSize = document.getElementById('cover-sub-title-size')?.value || 20;
    const coverSubTitleColor = document.getElementById('cover-sub-title-color')?.value || '#ffffff';
    const coverDescriptionSize = document.getElementById('cover-description-size')?.value || 15;
    const coverDescriptionColor = document.getElementById('cover-description-color')?.value || '#ffffff';
    const coverFontFamily = document.getElementById('cover-font-family')?.value || "'Yozai', serif";
    
    // 应用封面标题样式
    const coverCard = document.getElementById('cover-card');
    const coverTitle = document.getElementById('preview-cover-title');
    const coverSubtitle = document.getElementById('preview-cover-subtitle');
    const coverDescriptionElement = document.getElementById('preview-cover-description');
    
    if (coverCard && coverTitle && coverSubtitle) {
        if (currentCardType === 'cover') {
            coverTitle.textContent = coverMainTitle;
            coverSubtitle.textContent = coverSubTitle;
            if (coverDescriptionElement) coverDescriptionElement.textContent = coverDescription;
            
            // 应用封面样式
            coverTitle.style.fontSize = `${coverMainTitleSize}px`;
            coverTitle.style.color = coverMainTitleColor;
            coverTitle.style.fontFamily = coverFontFamily;
            
            coverSubtitle.style.fontSize = `${coverSubTitleSize}px`;
            coverSubtitle.style.color = coverSubTitleColor;
            coverSubtitle.style.fontFamily = coverFontFamily;
            
            if (coverDescriptionElement) {
                coverDescriptionElement.style.fontSize = `${coverDescriptionSize}px`;
                coverDescriptionElement.style.color = coverDescriptionColor;
                coverDescriptionElement.style.fontFamily = coverFontFamily;
            }
        } else {
            const cardTitle = document.getElementById('card-title');
            if (cardTitle) {
                coverTitle.textContent = cardTitle.value;
                coverTitle.style.fontSize = `${coverMainTitleSize}px`;
                coverTitle.style.color = coverMainTitleColor;
                coverTitle.style.fontFamily = coverFontFamily;
            }
            coverSubtitle.textContent = `第${currentPage}页，共${totalPages}页`;
            coverSubtitle.style.fontSize = `${coverSubTitleSize}px`;
            coverSubtitle.style.color = coverSubTitleColor;
            coverSubtitle.style.fontFamily = coverFontFamily;
            if (coverDescriptionElement) coverDescriptionElement.textContent = '';
        }
    }
    
    // 获取内容编辑样式设置
    const titleFontSize = document.getElementById('title-font-size')?.value || 24;
    const titleFontWeight = document.getElementById('title-font-weight')?.value || 'bold';
    const titleFontColor = document.getElementById('title-font-color')?.value || '#333333';
    const contentLineHeight = document.getElementById('content-line-height')?.value || 1.5;
    const contentParagraphSpacing = document.getElementById('content-paragraph-spacing')?.value || 12;
    const contentFontSize = document.getElementById('content-font-size')?.value || 14;
    const contentFontColor = document.getElementById('content-font-color')?.value || '#666666';
    const textAlign = document.getElementById('text-align')?.value || 'left';
    const fontFamily = document.getElementById('font-family')?.value || "'Yozai', serif";
    const showTitleCheckbox = document.getElementById('show-title-checkbox')?.checked ?? true;
    const titleTextAlign = document.getElementById('title-text-align')?.value || 'left';
    
    // 应用内容卡片样式
    const contentCard = document.getElementById('content-card');
    const contentTitle = document.getElementById('preview-content-title');
    const contentBody = document.getElementById('preview-content-body');
    
    if (contentCard && contentTitle && contentBody) {
        const cardTitle = document.getElementById('card-title');
        const cardContent = document.getElementById('card-content');
        
        if (cardTitle) {
            contentTitle.textContent = cardTitle.value;
            contentTitle.style.display = showTitleCheckbox ? 'block' : 'none';
            contentTitle.style.fontSize = `${titleFontSize}px`;
            contentTitle.style.fontWeight = titleFontWeight;
            contentTitle.style.color = titleFontColor;
            contentTitle.style.fontFamily = fontFamily;
            contentTitle.style.textAlign = titleTextAlign;
        }
        
        if (cardContent) {
            contentBody.innerHTML = '';
            cardContent.value.split('\n\n').forEach(paragraph => {
                if (paragraph.trim()) {
                    const p = document.createElement('p');
                    p.textContent = paragraph;
                    p.style.fontSize = `${contentFontSize}px`;
                    p.style.color = contentFontColor;
                    p.style.fontFamily = fontFamily;
                    p.style.textAlign = textAlign;
                    p.style.lineHeight = contentLineHeight;
                    p.style.marginBottom = `${contentParagraphSpacing}px`;
                    contentBody.appendChild(p);
                }
            });
        }
    }
    
    // 应用卡片样式设置
    if (currentCardType === 'cover') {
        const coverCard = document.getElementById('cover-card');
        const coverGradient = document.querySelector('.cover-gradient');
        
        if (coverCard) {
            // 应用边框样式到封面卡片
            coverCard.style.borderWidth = `${cardStyleSettings.cover.borderWidth}px`;
            coverCard.style.borderColor = cardStyleSettings.cover.borderColor;
            coverCard.style.borderRadius = `${cardStyleSettings.cover.borderRadius}px`;
            coverCard.style.borderStyle = 'solid'; // 确保边框样式为实线
        }
        
        if (coverGradient) {
            // 应用渐变背景到封面渐变层
            const gradientType = gradientSettings.cover.type;
            const gradientAngle = gradientSettings.cover.angle;
            const color1 = gradientSettings.cover.color1;
            const color2 = gradientSettings.cover.color2;
            
            if (gradientType === 'linear') {
                coverGradient.style.background = `linear-gradient(${gradientAngle}deg, ${color1}, ${color2})`;
            } else {
                coverGradient.style.background = `radial-gradient(circle, ${color1}, ${color2})`;
            }
        }
        
        if (coverCard && coverGradient) {
            // 应用背景图片到封面卡片
            if (backgroundImageData.cover.useImage && backgroundImageData.cover.image) {
                const opacity = backgroundImageData.cover.opacity / 100;
                // 调整渐变层的透明度，以便显示背景图片
                // 透明度值越小（0%），渐变层透明度越低，图片显示越清晰
                // 透明度值越大（100%），渐变层透明度越高，图片显示越模糊
                coverCard.style.background = `url(${backgroundImageData.cover.image})`;
                coverCard.style.backgroundSize = 'cover';
                coverCard.style.backgroundPosition = 'center';
                coverGradient.style.opacity = `${opacity}`;
            } else {
                // 如果不使用背景图片，确保背景透明，让渐变层显示
                coverCard.style.background = 'transparent';
                coverGradient.style.opacity = '1';
            }
        }
    } else {
        const contentCard = document.getElementById('content-card');
        if (contentCard) {
            // 应用边框样式到内容卡片
            contentCard.style.borderWidth = `${cardStyleSettings.content.borderWidth}px`;
            contentCard.style.borderColor = cardStyleSettings.content.borderColor;
            contentCard.style.borderRadius = `${cardStyleSettings.content.borderRadius}px`;
            contentCard.style.borderStyle = 'solid'; // 确保边框样式为实线
            
            // 应用渐变背景到内容卡片
            const gradientType = gradientSettings.content.type;
            const gradientAngle = gradientSettings.content.angle;
            const color1 = gradientSettings.content.color1;
            const color2 = gradientSettings.content.color2;
            
            if (gradientType === 'linear') {
                contentCard.style.background = `linear-gradient(${gradientAngle}deg, ${color1}, ${color2})`;
            } else {
                contentCard.style.background = `radial-gradient(circle, ${color1}, ${color2})`;
            }
            
            // 应用背景图片到内容卡片
            if (backgroundImageData.content.useImage && backgroundImageData.content.image) {
                const opacity = backgroundImageData.content.opacity / 100;
                // 调整白色渐变层的透明度，以便显示背景图片
                // 透明度值越小（0%），白色渐变层透明度越低，图片显示越清晰
                // 透明度值越大（100%），白色渐变层透明度越高，图片显示越模糊
                contentCard.style.background = `linear-gradient(rgba(255, 255, 255, ${opacity}), rgba(255, 255, 255, ${opacity})), url(${backgroundImageData.content.image})`;
                contentCard.style.backgroundSize = 'cover';
                contentCard.style.backgroundPosition = 'center';
            }
        }
    }
    
    // 应用封面元素变换
    updateElementsTransform();
}

// 加载文档
function loadDocument() {
    const fileInput = document.getElementById('document-upload');
    const file = fileInput.files[0];
    
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        parseDocumentContent(content);
    };
    reader.readAsText(file, 'utf-8');
}

// 解析文档内容
function parseDocumentContent(content) {
    // 解析文档内容，识别"## 卡片1：""## 卡片2："等关键字自动分页
    const lines = content.split('\n');
    let currentTitle = '';
    let currentContent = [];
    
    cardData = [];
    
    lines.forEach(line => {
        line = line.trim();
        if (line) {
            if (line.match(/^## 卡片\d+：/)) {
                // 新的卡片开始
                if (currentTitle) {
                    // 保存上一页数据
                    cardData.push({
                        title: currentTitle,
                        content: currentContent.join('\n\n')
                    });
                }
                // 提取"卡片1："后面的内容作为标题，忽略"卡片1："这样的标记
                // 使用更准确的正则表达式，确保能够匹配所有格式的标记
                // 先去掉开头的"## "，然后匹配并移除"卡片1："这样的标记
                currentTitle = line.replace(/^##\s*/, '').replace(/^卡片\s*\d+\s*：/, '').trim();
                currentContent = [];
            } else {
                // 忽略文件开头的 # 开头的总标题，只处理卡片内容
                currentContent.push(line);
            }
        }
    });
    
    // 保存最后一页数据
    if (currentTitle) {
        cardData.push({
            title: currentTitle,
            content: currentContent.join('\n\n')
        });
    }
    
    // 如果没有标题，创建一个默认页面
    if (cardData.length === 0 && content.trim()) {
        cardData.push({
            title: '默认标题',
            content: content.trim()
        });
    }
    
    totalPages = cardData.length;
    const totalPagesElement = document.getElementById('total-pages');
    const pageInputElement = document.getElementById('page-input');
    const pageNumberElement = document.getElementById('page-number');
    
    if (totalPagesElement) totalPagesElement.textContent = totalPages;
    if (pageInputElement) {
        pageInputElement.max = totalPages;
        pageInputElement.value = 1;
    }
    if (pageNumberElement) pageNumberElement.textContent = `第${currentPage}页`;
    
    // 加载第一页数据
    currentPage = 1;
    loadCurrentPageData();
    updatePageInfo();
    updatePreview();
    
    showStatus('文档加载成功', 'success');
}

// 下载当前卡片
function downloadCurrentCard() {
    const cardElement = currentCardType === 'cover' ? document.getElementById('cover-card') : document.getElementById('content-card');
    if (!cardElement) {
        showStatus('卡片元素未找到', 'error');
        return;
    }
    
    // 检查html2canvas是否可用
    if (typeof html2canvas === 'undefined') {
        showStatus('html2canvas库未加载', 'error');
        return;
    }
    
    // 使用html2canvas将卡片转换为图片
    html2canvas(cardElement, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: null
    }).then(canvas => {
        // 将canvas转换为图片并下载
        const link = document.createElement('a');
        link.download = `${currentCardType === 'cover' ? '封面' : '内容'}卡片_${currentPage}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        showStatus('卡片下载成功', 'success');
    }).catch(error => {
        console.error('下载卡片失败:', error);
        showStatus('卡片下载失败', 'error');
    });
}

// 批量下载卡片
function batchDownloadCards() {
    const textOnly = document.getElementById('text-only-checkbox').checked;
    
    if (textOnly) {
        // 仅文字模式：导出为txt文件
        let textContent = '';
        cardData.forEach((card, index) => {
            textContent += `# ${card.title}\n\n${card.content}\n\n---\n\n`;
        });
        
        const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
        const link = document.createElement('a');
        link.download = '卡片内容.txt';
        link.href = URL.createObjectURL(blob);
        link.click();
        showStatus('卡片内容导出成功', 'success');
    } else {
        // 图片模式：批量下载为图片
        if (typeof html2canvas === 'undefined') {
            showStatus('html2canvas库未加载，无法生成图片', 'error');
            return;
        }
        
        showStatus('正在批量生成图片，请稍候...', 'info');
        
        // 生成所有卡片的图片
        const promises = [];
        
        // 先添加封面卡片
        const coverCard = document.getElementById('cover-card');
        if (coverCard) {
            promises.push(
                html2canvas(coverCard, {
                    scale: 2,
                    useCORS: true,
                    logging: false,
                    backgroundColor: null
                }).then(canvas => {
                    return {
                        name: '封面.png',
                        data: canvas.toDataURL('image/png')
                    };
                })
            );
        }
        
        // 再添加所有内容卡片
        const contentCard = document.getElementById('content-card');
        if (contentCard) {
            // 保存当前页面和卡片类型
            const originalPage = currentPage;
            const originalCardType = currentCardType;
            
            // 切换到内容卡片类型
            switchCardType('content');
            
            // 为每个内容卡片生成图片
            cardData.forEach((card, index) => {
                currentPage = index + 1;
                loadCurrentPageData();
                updatePreview();
                
                promises.push(
                    html2canvas(contentCard, {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        backgroundColor: null
                    }).then(canvas => {
                        return {
                            name: `内容卡片_${index + 1}.png`,
                            data: canvas.toDataURL('image/png')
                        };
                    })
                );
            });
            
            // 恢复原始页面和卡片类型
            currentPage = originalPage;
            switchCardType(originalCardType);
            loadCurrentPageData();
            updatePreview();
        }
        
        // 处理所有图片生成完成后的操作，逐个下载图片
        Promise.all(promises).then(images => {
            if (images.length === 0) {
                showStatus('没有生成任何图片', 'error');
                return;
            }
            
            // 逐个下载图片
            images.forEach((image, index) => {
                setTimeout(() => {
                    const link = document.createElement('a');
                    link.download = image.name;
                    link.href = image.data;
                    link.click();
                }, index * 500); // 每张图片间隔500毫秒下载
            });
            
            showStatus(`成功下载 ${images.length} 张图片`, 'success');
        }).catch(error => {
            console.error('批量生成图片失败:', error);
            showStatus('批量生成图片失败', 'error');
        });
    }
}

// 处理配置文件选择
function handleConfigFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const config = JSON.parse(e.target.result);
            
            // 导入配置
            if (config.currentColorSchemes) {
                currentColorSchemes = config.currentColorSchemes;
            }
            if (config.gradientSettings) {
                gradientSettings = config.gradientSettings;
            }
            if (config.cardStyleSettings) {
                cardStyleSettings = config.cardStyleSettings;
            }
            if (config.coverElementsTransform) {
                coverElementsTransform = config.coverElementsTransform;
            }
            if (config.styleSettings) {
                styleSettings = config.styleSettings;
                // 更新UI元素
                updateUIFromStyleSettings();
            }
            if (config.backgroundImageData) {
                if (config.backgroundImageData.cover) {
                    backgroundImageData.cover.useImage = config.backgroundImageData.cover.useImage;
                    backgroundImageData.cover.opacity = config.backgroundImageData.cover.opacity;
                }
                if (config.backgroundImageData.content) {
                    backgroundImageData.content.useImage = config.backgroundImageData.content.useImage;
                    backgroundImageData.content.opacity = config.backgroundImageData.content.opacity;
                }
                // 更新UI元素
                updateBackgroundImageUI();
            }
            
            // 更新预览
            updatePreview();
            showStatus('配置导入成功', 'success');
        } catch (error) {
            console.error('导入配置失败:', error);
            showStatus('导入配置失败', 'error');
        }
    };
    reader.readAsText(file);
}

// 更新样式设置
function updateStyleSettings() {
    // 获取封面样式设置
    const coverMainTitleSize = document.getElementById('cover-main-title-size')?.value || 24;
    const coverMainTitleColor = document.getElementById('cover-main-title-color')?.value || '#ffffff';
    const coverSubTitleSize = document.getElementById('cover-sub-title-size')?.value || 20;
    const coverSubTitleColor = document.getElementById('cover-sub-title-color')?.value || '#ffffff';
    const coverDescriptionSize = document.getElementById('cover-description-size')?.value || 15;
    const coverDescriptionColor = document.getElementById('cover-description-color')?.value || '#ffffff';
    const coverFontFamily = document.getElementById('cover-font-family')?.value || "'Yozai', serif";
    
    // 更新封面样式设置
    styleSettings.cover.mainTitleSize = parseInt(coverMainTitleSize);
    styleSettings.cover.mainTitleColor = coverMainTitleColor;
    styleSettings.cover.subTitleSize = parseInt(coverSubTitleSize);
    styleSettings.cover.subTitleColor = coverSubTitleColor;
    styleSettings.cover.descriptionSize = parseInt(coverDescriptionSize);
    styleSettings.cover.descriptionColor = coverDescriptionColor;
    styleSettings.cover.fontFamily = coverFontFamily;
    
    // 获取内容编辑样式设置
    const titleFontSize = document.getElementById('title-font-size')?.value || 24;
    const titleFontWeight = document.getElementById('title-font-weight')?.value || 'bold';
    const titleFontColor = document.getElementById('title-font-color')?.value || '#333333';
    const titleTextAlign = document.getElementById('title-text-align')?.value || 'left';
    const contentLineHeight = document.getElementById('content-line-height')?.value || 1.5;
    const contentParagraphSpacing = document.getElementById('content-paragraph-spacing')?.value || 12;
    const contentFontSize = document.getElementById('content-font-size')?.value || 14;
    const contentFontColor = document.getElementById('content-font-color')?.value || '#666666';
    const textAlign = document.getElementById('text-align')?.value || 'left';
    const fontFamily = document.getElementById('font-family')?.value || "'Yozai', serif";
    const showTitleCheckbox = document.getElementById('show-title-checkbox')?.checked ?? true;
    
    // 更新内容样式设置
    styleSettings.content.titleSize = parseInt(titleFontSize);
    styleSettings.content.titleWeight = titleFontWeight;
    styleSettings.content.titleColor = titleFontColor;
    styleSettings.content.titleAlign = titleTextAlign;
    styleSettings.content.contentSize = parseInt(contentFontSize);
    styleSettings.content.contentColor = contentFontColor;
    styleSettings.content.contentLineHeight = parseFloat(contentLineHeight);
    styleSettings.content.contentParagraphSpacing = parseInt(contentParagraphSpacing);
    styleSettings.content.textAlign = textAlign;
    styleSettings.content.fontFamily = fontFamily;
    styleSettings.content.showTitle = showTitleCheckbox;
    
    // 同步styleSettings到UI中的颜色选择框，确保颜色选择框与实际对应
    const coverMainTitleColorElement = document.getElementById('cover-main-title-color');
    const coverSubTitleColorElement = document.getElementById('cover-sub-title-color');
    const coverDescriptionColorElement = document.getElementById('cover-description-color');
    const titleFontColorElement = document.getElementById('title-font-color');
    const contentFontColorElement = document.getElementById('content-font-color');
    
    if (coverMainTitleColorElement) coverMainTitleColorElement.value = styleSettings.cover.mainTitleColor;
    if (coverSubTitleColorElement) coverSubTitleColorElement.value = styleSettings.cover.subTitleColor;
    if (coverDescriptionColorElement) coverDescriptionColorElement.value = styleSettings.cover.descriptionColor;
    if (titleFontColorElement) titleFontColorElement.value = styleSettings.content.titleColor;
    if (contentFontColorElement) contentFontColorElement.value = styleSettings.content.contentColor;
}

// 更新UI从样式设置
function updateUIFromStyleSettings() {
    // 更新封面样式设置UI
    const coverMainTitleSize = document.getElementById('cover-main-title-size');
    const coverMainTitleSizeValue = document.getElementById('cover-main-title-size-value');
    const coverMainTitleColor = document.getElementById('cover-main-title-color');
    const coverSubTitleSize = document.getElementById('cover-sub-title-size');
    const coverSubTitleSizeValue = document.getElementById('cover-sub-title-size-value');
    const coverSubTitleColor = document.getElementById('cover-sub-title-color');
    const coverDescriptionSize = document.getElementById('cover-description-size');
    const coverDescriptionSizeValue = document.getElementById('cover-description-size-value');
    const coverDescriptionColor = document.getElementById('cover-description-color');
    const coverFontFamily = document.getElementById('cover-font-family');
    
    if (coverMainTitleSize && styleSettings.cover.mainTitleSize !== undefined) {
        coverMainTitleSize.value = styleSettings.cover.mainTitleSize;
        if (coverMainTitleSizeValue) {
            coverMainTitleSizeValue.textContent = `${styleSettings.cover.mainTitleSize}px`;
        }
    }
    if (coverMainTitleColor && styleSettings.cover.mainTitleColor) {
        coverMainTitleColor.value = styleSettings.cover.mainTitleColor;
    }
    if (coverSubTitleSize && styleSettings.cover.subTitleSize !== undefined) {
        coverSubTitleSize.value = styleSettings.cover.subTitleSize;
        if (coverSubTitleSizeValue) {
            coverSubTitleSizeValue.textContent = `${styleSettings.cover.subTitleSize}px`;
        }
    }
    if (coverSubTitleColor && styleSettings.cover.subTitleColor) {
        coverSubTitleColor.value = styleSettings.cover.subTitleColor;
    }
    if (coverDescriptionSize && styleSettings.cover.descriptionSize !== undefined) {
        coverDescriptionSize.value = styleSettings.cover.descriptionSize;
        if (coverDescriptionSizeValue) {
            coverDescriptionSizeValue.textContent = `${styleSettings.cover.descriptionSize}px`;
        }
    }
    if (coverDescriptionColor && styleSettings.cover.descriptionColor) {
        coverDescriptionColor.value = styleSettings.cover.descriptionColor;
    }
    if (coverFontFamily && styleSettings.cover.fontFamily) {
        coverFontFamily.value = styleSettings.cover.fontFamily;
    }
    
    // 更新内容样式设置UI
    const titleFontSize = document.getElementById('title-font-size');
    const titleFontSizeValue = document.getElementById('title-font-size-value');
    const titleFontWeight = document.getElementById('title-font-weight');
    const titleFontColor = document.getElementById('title-font-color');
    const titleTextAlign = document.getElementById('title-text-align');
    const contentLineHeight = document.getElementById('content-line-height');
    const contentLineHeightValue = document.getElementById('content-line-height-value');
    const contentParagraphSpacing = document.getElementById('content-paragraph-spacing');
    const contentParagraphSpacingValue = document.getElementById('content-paragraph-spacing-value');
    const contentFontSize = document.getElementById('content-font-size');
    const contentFontSizeValue = document.getElementById('content-font-size-value');
    const contentFontColor = document.getElementById('content-font-color');
    const textAlign = document.getElementById('text-align');
    const fontFamily = document.getElementById('font-family');
    const showTitleCheckbox = document.getElementById('show-title-checkbox');
    
    if (titleFontSize && styleSettings.content.titleSize !== undefined) {
        titleFontSize.value = styleSettings.content.titleSize;
        if (titleFontSizeValue) {
            titleFontSizeValue.textContent = `${styleSettings.content.titleSize}px`;
        }
    }
    if (titleFontWeight && styleSettings.content.titleWeight) {
        titleFontWeight.value = styleSettings.content.titleWeight;
    }
    if (titleFontColor && styleSettings.content.titleColor) {
        titleFontColor.value = styleSettings.content.titleColor;
    }
    if (titleTextAlign && styleSettings.content.titleAlign) {
        titleTextAlign.value = styleSettings.content.titleAlign;
    }
    if (contentLineHeight && styleSettings.content.contentLineHeight !== undefined) {
        contentLineHeight.value = styleSettings.content.contentLineHeight;
        if (contentLineHeightValue) {
            contentLineHeightValue.textContent = styleSettings.content.contentLineHeight;
        }
    }
    if (contentParagraphSpacing && styleSettings.content.contentParagraphSpacing !== undefined) {
        contentParagraphSpacing.value = styleSettings.content.contentParagraphSpacing;
        if (contentParagraphSpacingValue) {
            contentParagraphSpacingValue.textContent = `${styleSettings.content.contentParagraphSpacing}px`;
        }
    }
    if (contentFontSize && styleSettings.content.contentSize !== undefined) {
        contentFontSize.value = styleSettings.content.contentSize;
        if (contentFontSizeValue) {
            contentFontSizeValue.textContent = `${styleSettings.content.contentSize}px`;
        }
    }
    if (contentFontColor && styleSettings.content.contentColor) {
        contentFontColor.value = styleSettings.content.contentColor;
    }
    if (textAlign && styleSettings.content.textAlign) {
        textAlign.value = styleSettings.content.textAlign;
    }
    if (fontFamily && styleSettings.content.fontFamily) {
        fontFamily.value = styleSettings.content.fontFamily;
    }
    if (showTitleCheckbox && styleSettings.content.showTitle !== undefined) {
        showTitleCheckbox.checked = styleSettings.content.showTitle;
    }
}

// 更新背景图片UI
function updateBackgroundImageUI() {
    // 更新封面背景图片设置
    const useCoverBackgroundImageCheckbox = document.getElementById('use-cover-background-image-checkbox');
    const coverBackgroundImageOpacity = document.getElementById('cover-background-image-opacity');
    const coverBackgroundImageOpacityValue = document.getElementById('cover-background-image-opacity-value');
    
    if (useCoverBackgroundImageCheckbox) {
        useCoverBackgroundImageCheckbox.checked = backgroundImageData.cover.useImage;
    }
    if (coverBackgroundImageOpacity) {
        coverBackgroundImageOpacity.value = backgroundImageData.cover.opacity;
    }
    if (coverBackgroundImageOpacityValue) {
        coverBackgroundImageOpacityValue.textContent = `${backgroundImageData.cover.opacity}%`;
    }
    
    // 更新内容背景图片设置
    const useContentBackgroundImageCheckbox = document.getElementById('use-content-background-image-checkbox');
    const contentBackgroundImageOpacity = document.getElementById('content-background-image-opacity');
    const contentBackgroundImageOpacityValue = document.getElementById('content-background-image-opacity-value');
    
    if (useContentBackgroundImageCheckbox) {
        useContentBackgroundImageCheckbox.checked = backgroundImageData.content.useImage;
    }
    if (contentBackgroundImageOpacity) {
        contentBackgroundImageOpacity.value = backgroundImageData.content.opacity;
    }
    if (contentBackgroundImageOpacityValue) {
        contentBackgroundImageOpacityValue.textContent = `${backgroundImageData.content.opacity}%`;
    }
}

// 显示状态消息
function showStatus(message, type) {
    const statusElement = document.getElementById('status-message');
    if (statusElement) {
        statusElement.textContent = message;
        statusElement.className = `status-message ${type}`;
        statusElement.style.display = 'block';
        
        // 3秒后自动隐藏
        setTimeout(() => {
            statusElement.style.display = 'none';
        }, 3000);
    }
}

// 导入配置
function importConfig() {
    const configUpload = document.getElementById('config-upload');
    if (configUpload) {
        configUpload.click();
    }
}

// 导出配置
function exportConfig() {
    const config = {
        currentColorSchemes,
        gradientSettings,
        cardStyleSettings,
        coverElementsTransform,
        styleSettings
    };
    
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '卡片配置.json';
    link.click();
    showStatus('配置导出成功', 'success');
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', init);