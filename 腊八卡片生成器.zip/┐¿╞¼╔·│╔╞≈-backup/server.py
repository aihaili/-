import http.server
import socketserver
import os

PORT = 9000

# 更改当前工作目录到脚本所在目录
os.chdir('e:\\Trae\\卡片 - 0201b\\卡片生成器')

Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving at http://localhost:{PORT}")
    httpd.serve_forever()