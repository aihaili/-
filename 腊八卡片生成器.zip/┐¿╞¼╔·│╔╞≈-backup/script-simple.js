// 全局变量
let currentPage = 1;
let totalPages = 5;
let currentCardType = 'cover';
let cardData = [];

// 初始化函数
async function init() {
    try {
        console.log('开始初始化...');
        
        // 初始化事件监听器
        initEventListeners();
        console.log('事件监听器初始化完成');
        
        // 加载卡片数据
        await loadCardData();
        console.log('卡片数据加载完成');
        
        // 加载当前页面数据
        loadCurrentPageData();
        console.log('当前页面数据加载完成');
        
        // 切换卡片类型显示
        switchCardType('cover');
        console.log('卡片类型显示切换完成');
        
        console.log('初始化完成！');
    } catch (error) {
        console.error('初始化失败:', error);
        showStatus('初始化失败', 'error');
    }
}

// 初始化事件监听器
function initEventListeners() {
    // 卡片类型切换
    const coverCardBtn = document.getElementById('cover-card-btn');
    const contentCardBtn = document.getElementById('content-card-btn');
    
    if (coverCardBtn) {
        coverCardBtn.addEventListener('click', () => {
            console.log('点击封面卡片按钮');
            switchCardType('cover');
        });
    }
    
    if (contentCardBtn) {
        contentCardBtn.addEventListener('click', () => {
            console.log('点击内容卡片按钮');
            switchCardType('content');
        });
    }
    
    // 分页控制
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    
    if (prevPageBtn) {
        prevPageBtn.addEventListener('click', () => {
            console.log('点击上一页按钮');
            if (currentPage > 1) {
                currentPage--;
                updatePageInfo();
                loadCurrentPageData();
                updatePreview();
            }
        });
    }
    
    if (nextPageBtn) {
        nextPageBtn.addEventListener('click', () => {
            console.log('点击下一页按钮');
            if (currentPage < totalPages) {
                currentPage++;
                updatePageInfo();
                loadCurrentPageData();
                updatePreview();
            }
        });
    }
    
    // 内容编辑
    const cardTitle = document.getElementById('card-title');
    const cardContent = document.getElementById('card-content');
    
    if (cardTitle) cardTitle.addEventListener('input', updatePreview);
    if (cardContent) cardContent.addEventListener('input', updatePreview);
}

// 加载卡片数据
async function loadCardData() {
    cardData = [
        {
            title: "本世纪第二晚的腊八节",
            content: "2026年1月26日的腊八节特别引人关注，因为它是本世纪第二晚的腊八节，仅仅比2084年1月27日的腊八节早一天。"
        },
        {
            title: "置闰：传统历法的智慧",
            content: "说到农历，咱们都知道它是阴阳合历，既要跟着月亮的阴晴圆缺走，又要兼顾太阳公转的周期。"
        },
        {
            title: "腊八节的传统习俗",
            content: "腊八节的习俗可丰富了，我最熟悉的就是喝腊八粥。"
        },
        {
            title: "传统节日的现代意义",
            content: "现在大家平时都挺忙的，每天跟着公历的节奏跑，很少有时间停下来想想生活的意义。"
        },
        {
            title: "节日的文化温度",
            content: "我觉得节日的真正意义不在于它具体在哪一天，而在于它所承载的文化温度。"
        }
    ];
    
    totalPages = cardData.length;
    const totalPagesElement = document.getElementById('total-pages');
    const pageInputElement = document.getElementById('page-input');
    
    if (totalPagesElement) totalPagesElement.textContent = totalPages;
    if (pageInputElement) {
        pageInputElement.max = totalPages;
        pageInputElement.value = 1;
    }
}

// 加载当前页面数据
function loadCurrentPageData() {
    if (cardData.length > 0 && currentPage <= cardData.length) {
        const data = cardData[currentPage - 1];
        const cardTitle = document.getElementById('card-title');
        const cardContent = document.getElementById('card-content');
        
        if (cardTitle) cardTitle.value = data.title;
        if (cardContent) cardContent.value = data.content;
    }
}

// 切换卡片类型
function switchCardType(type) {
    currentCardType = type;
    
    // 更新按钮状态
    const coverCardBtn = document.getElementById('cover-card-btn');
    const contentCardBtn = document.getElementById('content-card-btn');
    
    if (coverCardBtn && contentCardBtn) {
        if (type === 'cover') {
            coverCardBtn.classList.remove('btn-secondary');
            coverCardBtn.classList.add('btn-primary');
            contentCardBtn.classList.remove('btn-primary');
            contentCardBtn.classList.add('btn-secondary');
        } else {
            contentCardBtn.classList.remove('btn-secondary');
            contentCardBtn.classList.add('btn-primary');
            coverCardBtn.classList.remove('btn-primary');
            coverCardBtn.classList.add('btn-secondary');
        }
    }
    
    // 更新预览
    updatePreview();
}

// 更新分页信息
function updatePageInfo() {
    const currentPageElement = document.getElementById('current-page');
    const pageInput = document.getElementById('page-input');
    
    if (currentPageElement) currentPageElement.textContent = currentPage;
    if (pageInput) pageInput.value = currentPage;
}

// 更新预览
function updatePreview() {
    console.log('更新预览...');
    
    // 获取封面内容
    const coverMainTitle = document.getElementById('cover-main-title')?.value || '腊八节知识卡片';
    const coverSubTitle = document.getElementById('cover-sub-title')?.value || '传统节日的文化温度与智慧';
    
    // 更新封面预览
    const coverTitle = document.getElementById('preview-cover-title');
    const coverSubtitle = document.getElementById('preview-cover-subtitle');
    
    if (coverTitle) coverTitle.textContent = coverMainTitle;
    if (coverSubtitle) coverSubtitle.textContent = coverSubTitle;
    
    // 更新内容卡片预览
    const contentTitle = document.getElementById('preview-content-title');
    const contentBody = document.getElementById('preview-content-body');
    
    if (contentTitle && contentBody) {
        const cardTitle = document.getElementById('card-title');
        const cardContent = document.getElementById('card-content');
        
        if (cardTitle) contentTitle.textContent = cardTitle.value;
        if (cardContent) {
            contentBody.innerHTML = '';
            const paragraphs = cardContent.value.split('\n\n');
            paragraphs.forEach(paragraph => {
                if (paragraph.trim()) {
                    const p = document.createElement('p');
                    p.textContent = paragraph;
                    contentBody.appendChild(p);
                }
            });
        }
    }
}

// 显示状态消息
function showStatus(message, type) {
    const statusElement = document.getElementById('status-message');
    if (statusElement) {
        statusElement.textContent = message;
        statusElement.className = `status-message ${type}`;
        statusElement.style.display = 'block';
        
        // 3秒后自动隐藏
        setTimeout(() => {
            statusElement.style.display = 'none';
        }, 3000);
    }
}

// 测试函数
function testFunction() {
    console.log('测试函数被调用！');
    alert('测试函数被调用，JavaScript正常工作！');
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', function() {
    console.log('DOMContentLoaded事件触发，开始初始化...');
    init().catch(error => {
        console.error('初始化失败:', error);
        alert('初始化失败:', error);
    });
});
