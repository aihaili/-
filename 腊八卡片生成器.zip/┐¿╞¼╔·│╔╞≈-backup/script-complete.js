// 全局变量
let currentPage = 1;
let totalPages = 5;
let currentCardType = 'cover'; // cover 或 content
let cardData = [];
let currentColorSchemes = {
    cover: 'apple-ios',
    content: 'apple-ios'
};

// 封面元素变换状态
let coverElementsTransform = {
    title: {
        x: 0,
        y: 0,
        rotate: 0
    },
    subtitle: {
        x: 0,
        y: 0,
        rotate: 0
    },
    description: {
        x: 0,
        y: 0,
        rotate: 0
    },
    image: {
        x: 0,
        y: 0,
        rotate: 0,
        scale: 1
    }
};

// 拖拽状态
let isDragging = false;
let isRotating = false;
let isScaling = false;
let dragStartX = 0;
let dragStartY = 0;
let lastX = 0;
let lastY = 0;
let rotationStartAngle = 0;
let selectedElement = null; // 可能的值: 'title', 'subtitle', 'description', 'image', null
let hasDragged = false; // 标记是否进行了实际的拖拽操作
let activeElement = null; // 标记当前正在操作的元素，防止误操作

// 渐变背景设置
let gradientSettings = {
    cover: {
        type: 'linear',
        angle: 135,
        color1: '#ff6b6b',
        color2: '#ee5a6f'
    },
    content: {
        type: 'linear',
        angle: 135,
        color1: '#ff6b6b',
        color2: '#ee5a6f'
    }
};

// 卡片样式设置
let cardStyleSettings = {
    cover: {
        borderWidth: 2,
        borderColor: '#ff2442',
        borderRadius: 16
    },
    content: {
        borderWidth: 2,
        borderColor: '#ff2442',
        borderRadius: 16
    }
};

// 系统字体列表
const systemFonts = [
    { name: '等线', value: "'DengXian', sans-serif" },
    { name: '苹方', value: "'PingFang SC', sans-serif" },
    { name: '思源宋体', value: "'Source Han Serif SC', serif" },
    { name: '宋体', value: "'SimSun', serif" },
    { name: '黑体', value: "'SimHei', sans-serif" },
    { name: '楷体', value: "'KaiTi', serif" },
    { name: '仿宋', value: "'FangSong', serif" },
    { name: 'Arial', value: 'Arial, sans-serif' },
    { name: 'Times New Roman', value: "'Times New Roman', serif" },
    { name: 'Courier New', value: "'Courier New', monospace" }
];

// 背景图片设置
let backgroundImageData = {
    cover: {
        image: null,
        useImage: false,
        opacity: 100
    },
    content: {
        image: null,
        useImage: false,
        opacity: 100
    }
};

// 更新图层视觉顺序
function updateLayerVisualOrder() {
    const layerList = document.getElementById('layer-list');
    const layerItems = layerList.querySelectorAll('.layer-item');
    const layerElements = {
        title: document.getElementById('title-container'),
        subtitle: document.getElementById('subtitle-container'),
        description: document.getElementById('description-container'),
        image: document.getElementById('image-container'),
        doodle: document.getElementById('doodle-canvas')
    };
    
    // 从前往后遍历图层，设置z-index，确保图层管理中越往上的图层z-index越大
    let zIndex = 20; // 基础z-index
    layerItems.forEach((item, index) => {
        const layerType = item.dataset.layer;
        const element = layerElements[layerType];
        if (element) { // 包括涂鸦图层，允许图层管理控制其z-index
            // 图层管理中越往上的图层，z-index越大，这样在视觉上就越在前面
            element.style.zIndex = zIndex - index;
            console.log('设置图层', layerType, '的z-index为', zIndex - index);
        }
    });
    
    // 确保涂鸦画布始终可见（display属性为block）
    if (layerElements.doodle) {
        // 检查涂鸦图层是否被用户手动隐藏
        const doodleLayerItem = document.querySelector('.layer-item[data-layer="doodle"]');
        const doodleVisibility = doodleLayerItem.querySelector('.layer-visibility');
        if (!doodleVisibility || !doodleVisibility.classList.contains('hidden')) {
            layerElements.doodle.style.display = 'block';
            // 重新绘制画布内容，确保遮挡移除后内容可见
            redrawCanvas();
        }
    }
    
    // 确保所有图层的内容都正确显示
    setTimeout(() => {
        // 再次重绘涂鸦内容，确保它在所有图层操作后都能显示
        if (layerElements.doodle) {
            const doodleLayerItem = document.querySelector('.layer-item[data-layer="doodle"]');
            const doodleVisibility = doodleLayerItem.querySelector('.layer-visibility');
            if (!doodleVisibility || !doodleVisibility.classList.contains('hidden')) {
                redrawCanvas();
            }
        }
    }, 50);
    
    // 再次确保涂鸦画布的显示状态，防止浏览器渲染问题
    setTimeout(() => {
        if (layerElements.doodle) {
            const doodleLayerItem = document.querySelector('.layer-item[data-layer="doodle"]');
            const doodleVisibility = doodleLayerItem.querySelector('.layer-visibility');
            if (!doodleVisibility || !doodleVisibility.classList.contains('hidden')) {
                layerElements.doodle.style.display = 'block';
                // 强制浏览器重排和重绘
                layerElements.doodle.style.transform = 'translateZ(0)';
                void layerElements.doodle.offsetWidth;
                redrawCanvas();
            }
        }
    }, 100);
}

// 各元素自动换行状态管理
let textElementAutoWrapState = {
    title: false,
    subtitle: false,
    description: false
};

// 内容卡片文字设置
let contentCardTextSettings = {
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        fontColor: '#333333',
        textAlign: 'left',
        fontFamily: "'Yozai', serif",
        showTitle: true
    },
    content: {
        fontSize: 14,
        fontColor: '#666666',
        lineHeight: 1.5,
        paragraphSpacing: 12,
        textAlign: 'left',
        fontFamily: "'Yozai', serif"
    }
};

// 配色方案
const colorSchemes = {
    'apple-ios': {
        gradientColor1: '#FFFFFF',
        gradientColor2: '#F2F2F7',
        textColor: '#000000',
        secondaryTextColor: '#8E8E93',
        borderColor: '#C7C7CC',
        accentColor: '#007AFF'
    },
    'pastel-palette': {
        gradientColor1: '#FEFFFF',
        gradientColor2: '#F0F4C3',
        textColor: '#000000',
        secondaryTextColor: '#795548',
        borderColor: '#BDBDBD',
        accentColor: '#FFAB40'
    },
    'classic-blue-white': {
        gradientColor1: '#FFFFFF',
        gradientColor2: '#E3F2FD',
        textColor: '#1A237E',
        secondaryTextColor: '#64B5F6',
        borderColor: '#BBDEFB',
        accentColor: '#1976D2'
    },
    'macaron-garden': {
        gradientColor1: '#F5F5DC',
        gradientColor2: '#D1E8E2',
        textColor: '#343A40',
        secondaryTextColor: '#6C757D',
        borderColor: '#ADB5BD',
        accentColor: '#9CE7B5'
    },
    'macaron-lavender': {
        gradientColor1: '#E6E6FA',
        gradientColor2: '#F0FFF0',
        textColor: '#343A40',
        secondaryTextColor: '#6C757D',
        borderColor: '#ADB5BD',
        accentColor: '#DDA0DD'
    },
    'stationery-style': {
        gradientColor1: '#FFFFF0',
        gradientColor2: '#F5F5DC',
        textColor: '#343A40',
        secondaryTextColor: '#6C757D',
        borderColor: '#D2B48C',
        accentColor: '#8B4513'
    }
};

// 检测字体是否可用
function detectFontAvailability(fontName) {
    // 创建一个临时元素
    const testElement = document.createElement('span');
    testElement.style.fontFamily = fontName;
    testElement.style.fontSize = '72px';
    testElement.style.position = 'absolute';
    testElement.style.left = '-9999px';
    testElement.textContent = 'mmmmmmmmmmlli';
    document.body.appendChild(testElement);
    
    // 测量宽度
    const width = testElement.offsetWidth;
    
    // 移除临时元素
    document.body.removeChild(testElement);
    
    // 与通用字体比较
    const fallbackTestElement = document.createElement('span');
    fallbackTestElement.style.fontFamily = 'monospace';
    fallbackTestElement.style.fontSize = '72px';
    fallbackTestElement.style.position = 'absolute';
    fallbackTestElement.style.left = '-9999px';
    fallbackTestElement.textContent = 'mmmmmmmmmmlli';
    document.body.appendChild(fallbackTestElement);
    
    const fallbackWidth = fallbackTestElement.offsetWidth;
    document.body.removeChild(fallbackTestElement);
    
    // 如果宽度不同，说明字体可用
    return width !== fallbackWidth;
}

// 初始化系统字体选项
function initSystemFontOptions() {
    const coverFontSelect = document.getElementById('cover-font-family');
    const contentFontSelect = document.getElementById('font-family');
    
    // 为封面字体选择添加系统字体选项
    if (coverFontSelect) {
        systemFonts.forEach(font => {
            // 检测字体是否可用
            const isAvailable = detectFontAvailability(font.value);
            if (isAvailable) {
                const option = document.createElement('option');
                option.value = font.value;
                option.textContent = font.name;
                coverFontSelect.appendChild(option);
            }
        });
    }
    
    // 为内容字体选择添加系统字体选项
    if (contentFontSelect) {
        systemFonts.forEach(font => {
            // 检测字体是否可用
            const isAvailable = detectFontAvailability(font.value);
            if (isAvailable) {
                const option = document.createElement('option');
                option.value = font.value;
                option.textContent = font.name;
                contentFontSelect.appendChild(option);
            }
        });
    }
}

// 更新元素变换
function updateElementsTransform() {
    const coverTitle = document.getElementById('preview-cover-title');
    const coverSubtitle = document.getElementById('preview-cover-subtitle');
    const coverDescription = document.getElementById('preview-cover-description');
    const subtitleContainer = document.getElementById('subtitle-container');
    const titleContainer = document.getElementById('title-container');
    const descriptionContainer = document.getElementById('description-container');
    
    // 移动容器而不是内部元素
    if (titleContainer) {
        // 调整大标题位置，使其显示在画布上方区域
        titleContainer.style.transform = `translateX(-50%) translateY(-100px) translate(${coverElementsTransform.title.x}px, ${coverElementsTransform.title.y}px) rotate(${coverElementsTransform.title.rotate}deg)`;
        // 确保容器是可见的
        titleContainer.style.display = 'inline-block';
        titleContainer.style.opacity = '1';
    }
    
    if (subtitleContainer) {
        // 保持小标题位置
        subtitleContainer.style.transform = `translateX(-50%) translateY(-25px) translate(${coverElementsTransform.subtitle.x}px, ${coverElementsTransform.subtitle.y}px) rotate(${coverElementsTransform.subtitle.rotate}deg)`;
        // 确保容器是可见的
        subtitleContainer.style.display = 'inline-block';
        subtitleContainer.style.opacity = '1';
    }
    
    if (descriptionContainer) {
        // 调整内容简介位置，使其显示在画布下方区域
        descriptionContainer.style.transform = `translateX(-50%) translateY(120px) translate(${coverElementsTransform.description.x}px, ${coverElementsTransform.description.y}px) rotate(${coverElementsTransform.description.rotate}deg)`;
        // 确保容器是可见的
        descriptionContainer.style.display = 'inline-block';
        descriptionContainer.style.opacity = '1';
        // 确保z-index足够高，不会被其他元素遮挡
        descriptionContainer.style.zIndex = '10';
        // 确保容器有足够的宽度
        descriptionContainer.style.minWidth = '200px';
        // 确保容器有足够的高度
        descriptionContainer.style.minHeight = '80px';
        // 确保容器的位置是相对于卡片的中心
        descriptionContainer.style.position = 'absolute';
        descriptionContainer.style.top = '50%';
        descriptionContainer.style.left = '50%';
    }
    
    // 图片容器变换
    const imageContainer = document.getElementById('image-container');
    if (imageContainer) {
        // 应用图片变换，同时保持初始的居中位置
        imageContainer.style.transform = `translate(-50%, -50%) translate(${coverElementsTransform.image.x}px, ${coverElementsTransform.image.y}px) rotate(${coverElementsTransform.image.rotate}deg) scale(${coverElementsTransform.image.scale})`;
    }
    
    // 获取边界框元素
    const titleBoundingBox = document.getElementById('title-bounding-box');
    const descriptionBoundingBox = document.getElementById('description-bounding-box');
    const subtitleBoundingBox = document.getElementById('subtitle-bounding-box');
    const imageBoundingBox = document.getElementById('image-bounding-box');
    
    // 大标题边界框
    if (titleBoundingBox) {
        if (selectedElement === 'title') {
            titleBoundingBox.style.display = 'block';
            // 获取文本元素和容器
            const titleText = document.getElementById('preview-cover-title');
            const titleContainer = document.getElementById('title-container');
            if (titleText && titleContainer) {
                // 检查自动换行状态 - 使用元素独立状态
                const isAutoWrapEnabled = textElementStates.title.autoWrap || false;
                
                // 获取文本的实际尺寸
                const textWidth = titleText.offsetWidth;
                const textHeight = titleText.offsetHeight;
                
                // 计算容器的实际尺寸
                const containerWidth = titleContainer.offsetWidth;
                const containerHeight = titleContainer.offsetHeight;
                
                // 确定边界框的宽度和高度
                let boundingWidth, boundingHeight;
                
                if (isAutoWrapEnabled) {
                    // 自动换行开启时，直接使用容器宽度和文本高度
                    boundingWidth = containerWidth;
                    boundingHeight = Math.max(textHeight, containerHeight) + 10;
                } else {
                    // 自动换行关闭时，使用文本宽度和高度
                    boundingWidth = textWidth;
                    boundingHeight = textHeight + 10;
                }
                
                // 设置边界框尺寸和位置
                titleBoundingBox.style.width = boundingWidth + 'px';
                titleBoundingBox.style.height = boundingHeight + 'px';
                titleBoundingBox.style.top = '-5px';
                titleBoundingBox.style.left = '0';
                
                console.log('大标题边界框设置:', {
                    textWidth,
                    textHeight,
                    containerWidth,
                    containerHeight,
                    boundingWidth,
                    boundingHeight,
                    isAutoWrapEnabled
                });
            } else {
                titleBoundingBox.style.width = '100%';
                titleBoundingBox.style.height = '100%';
                titleBoundingBox.style.top = '0';
                titleBoundingBox.style.left = '0';
            }
        } else {
            titleBoundingBox.style.display = 'none';
        }
    }
    
    // 小标题边界框
    if (subtitleBoundingBox) {
        if (selectedElement === 'subtitle') {
            subtitleBoundingBox.style.display = 'block';
            // 获取文本元素和容器
            const subtitleText = document.getElementById('preview-cover-subtitle');
            const subtitleContainer = document.getElementById('subtitle-container');
            if (subtitleText && subtitleContainer) {
                // 检查自动换行状态 - 使用元素独立状态
                const isAutoWrapEnabled = textElementStates.subtitle.autoWrap || false;
                
                // 获取文本的实际尺寸
                const textWidth = subtitleText.offsetWidth;
                const textHeight = subtitleText.offsetHeight;
                
                // 计算容器的实际尺寸
                const containerWidth = subtitleContainer.offsetWidth;
                const containerHeight = subtitleContainer.offsetHeight;
                
                // 确定边界框的宽度和高度
                let boundingWidth, boundingHeight;
                
                if (isAutoWrapEnabled) {
                    // 自动换行开启时，直接使用容器宽度和文本高度
                    boundingWidth = containerWidth;
                    boundingHeight = Math.max(textHeight, containerHeight) + 10;
                } else {
                    // 自动换行关闭时，使用文本宽度和高度
                    boundingWidth = textWidth;
                    boundingHeight = textHeight + 10;
                }
                
                // 设置边界框尺寸和位置
                subtitleBoundingBox.style.width = boundingWidth + 'px';
                subtitleBoundingBox.style.height = boundingHeight + 'px';
                subtitleBoundingBox.style.top = '-5px';
                subtitleBoundingBox.style.left = '0';
                
                console.log('小标题边界框设置:', {
                    textWidth,
                    textHeight,
                    containerWidth,
                    containerHeight,
                    boundingWidth,
                    boundingHeight,
                    isAutoWrapEnabled
                });
            } else {
                subtitleBoundingBox.style.width = '100%';
                subtitleBoundingBox.style.height = '100%';
                subtitleBoundingBox.style.top = '0';
                subtitleBoundingBox.style.left = '0';
            }
        } else {
            subtitleBoundingBox.style.display = 'none';
        }
    }
    
    // 简介内容边界框
    if (descriptionBoundingBox) {
        if (selectedElement === 'description') {
            descriptionBoundingBox.style.display = 'block';
            // 获取文本元素和容器
            const descriptionText = document.getElementById('preview-cover-description');
            const descriptionContainer = document.getElementById('description-container');
            if (descriptionText && descriptionContainer) {
                // 检查自动换行状态 - 使用元素独立状态
                const isAutoWrapEnabled = textElementStates.description.autoWrap || false;
                
                // 获取文本的实际尺寸
                const textWidth = descriptionText.offsetWidth;
                const textHeight = descriptionText.offsetHeight;
                
                // 计算容器的实际尺寸
                const containerWidth = descriptionContainer.offsetWidth;
                const containerHeight = descriptionContainer.offsetHeight;
                
                // 确定边界框的宽度和高度
                let boundingWidth, boundingHeight;
                
                if (isAutoWrapEnabled) {
                    // 自动换行开启时，直接使用容器宽度和文本高度
                    boundingWidth = containerWidth;
                    boundingHeight = Math.max(textHeight, containerHeight) + 10;
                } else {
                    // 自动换行关闭时，使用文本宽度和高度
                    boundingWidth = textWidth;
                    boundingHeight = textHeight + 10;
                }
                
                // 设置边界框尺寸和位置
                descriptionBoundingBox.style.width = boundingWidth + 'px';
                descriptionBoundingBox.style.height = boundingHeight + 'px';
                descriptionBoundingBox.style.top = '-5px';
                descriptionBoundingBox.style.left = '0';
                
                console.log('简介内容边界框设置:', {
                    textWidth,
                    textHeight,
                    containerWidth,
                    containerHeight,
                    boundingWidth,
                    boundingHeight,
                    isAutoWrapEnabled
                });
            } else {
                descriptionBoundingBox.style.width = '100%';
                descriptionBoundingBox.style.height = '100%';
                descriptionBoundingBox.style.top = '0';
                descriptionBoundingBox.style.left = '0';
            }
        } else {
            descriptionBoundingBox.style.display = 'none';
        }
    }
    
    // 图片边界框
    if (imageBoundingBox) {
        if (selectedElement === 'image') {
            imageBoundingBox.style.display = 'block';
            imageBoundingBox.style.width = '100%';
            imageBoundingBox.style.height = '100%';
            imageBoundingBox.style.top = '0';
            imageBoundingBox.style.left = '0';
        } else {
            imageBoundingBox.style.display = 'none';
        }
    }
    
    // 显示/隐藏旋转控制点
    const titleRotateHandle = document.getElementById('title-rotate-handle');
    const subtitleRotateHandle = document.getElementById('subtitle-rotate-handle');
    const descriptionRotateHandle = document.getElementById('description-rotate-handle');
    const imageRotateHandle = document.getElementById('image-rotate-handle');
    
    // 大标题旋转控制点
    if (titleRotateHandle) {
        if (selectedElement === 'title') {
            titleRotateHandle.style.display = 'block';
            titleRotateHandle.style.top = '-10px';
            titleRotateHandle.style.right = '-10px';
            titleRotateHandle.style.left = 'auto';
            titleRotateHandle.style.bottom = 'auto';
        } else {
            titleRotateHandle.style.display = 'none';
        }
    }
    
    // 小标题旋转控制点
    if (subtitleRotateHandle) {
        if (selectedElement === 'subtitle') {
            subtitleRotateHandle.style.display = 'block';
            subtitleRotateHandle.style.top = '-10px';
            subtitleRotateHandle.style.right = '-10px';
            subtitleRotateHandle.style.left = 'auto';
            subtitleRotateHandle.style.bottom = 'auto';
        } else {
            subtitleRotateHandle.style.display = 'none';
        }
    }
    
    // 简介旋转控制点
    if (descriptionRotateHandle) {
        if (selectedElement === 'description') {
            descriptionRotateHandle.style.display = 'block';
            descriptionRotateHandle.style.top = '-10px';
            descriptionRotateHandle.style.right = '-10px';
            descriptionRotateHandle.style.left = 'auto';
            descriptionRotateHandle.style.bottom = 'auto';
        } else {
            descriptionRotateHandle.style.display = 'none';
        }
    }
    
    // 图片旋转控制点
    if (imageRotateHandle) {
        if (selectedElement === 'image') {
            imageRotateHandle.style.display = 'block';
            imageRotateHandle.style.top = '-10px';
            imageRotateHandle.style.right = '-10px';
            imageRotateHandle.style.left = 'auto';
            imageRotateHandle.style.bottom = 'auto';
        } else {
            imageRotateHandle.style.display = 'none';
        }
    }
    
    // 图片缩放控制点
    if (selectedElement === 'image') {
        const resizeHandles = document.querySelectorAll('.image-container .resize-handle');
        resizeHandles.forEach(handle => {
            handle.style.display = 'block';
        });
        
        // 设置缩放控制点位置
        const nwHandle = document.querySelector('.image-container .resize-handle-nw');
        const neHandle = document.querySelector('.image-container .resize-handle-ne');
        const swHandle = document.querySelector('.image-container .resize-handle-sw');
        const seHandle = document.querySelector('.image-container .resize-handle-se');
        
        if (nwHandle) { nwHandle.style.top = '-4px'; nwHandle.style.left = '-4px'; }
        if (neHandle) { neHandle.style.top = '-4px'; neHandle.style.right = '-4px'; }
        if (swHandle) { swHandle.style.bottom = '-4px'; swHandle.style.left = '-4px'; }
        if (seHandle) { seHandle.style.bottom = '-4px'; seHandle.style.right = '-4px'; }
    } else {
        const resizeHandles = document.querySelectorAll('.image-container .resize-handle');
        resizeHandles.forEach(handle => {
            handle.style.display = 'none';
        });
    }
}

// 更新预览
function updatePreview() {
    // 封面卡片预览更新
    const coverMainTitle = document.getElementById('cover-main-title');
    const coverSubTitle = document.getElementById('cover-sub-title');
    const coverDescription = document.getElementById('cover-description');
    const coverMainTitleColor = document.getElementById('cover-main-title-color');
    const coverSubTitleColor = document.getElementById('cover-sub-title-color');
    const coverDescriptionColor = document.getElementById('cover-description-color');
    const coverMainTitleSize = document.getElementById('cover-main-title-size');
    const coverSubTitleSize = document.getElementById('cover-sub-title-size');
    const coverDescriptionSize = document.getElementById('cover-description-size');
    const coverMainTitleFont = document.getElementById('cover-main-title-font');
    const coverSubTitleFont = document.getElementById('cover-sub-title-font');
    const coverDescriptionFont = document.getElementById('cover-description-font');
    const coverMainTitleBold = document.getElementById('cover-main-title-bold');
    const coverSubTitleBold = document.getElementById('cover-sub-title-bold');
    const coverDescriptionBold = document.getElementById('cover-description-bold');
    const coverMainTitleAlign = document.getElementById('cover-main-title-align');
    const coverSubTitleAlign = document.getElementById('cover-sub-title-align');
    const coverDescriptionAlign = document.getElementById('cover-description-align');
    const coverMainTitleLineHeight = document.getElementById('cover-main-title-line-height');
    const coverSubTitleLineHeight = document.getElementById('cover-sub-title-line-height');
    const coverDescriptionLineHeight = document.getElementById('cover-description-line-height');
    
    // 内容卡片预览更新
    const cardTitle = document.getElementById('card-title');
    const cardContent = document.getElementById('card-content');
    const titleFontSize = document.getElementById('title-font-size');
    const titleFontWeight = document.getElementById('title-font-weight');
    const titleFontColor = document.getElementById('title-font-color');
    const contentLineHeight = document.getElementById('content-line-height');
    const contentParagraphSpacing = document.getElementById('content-paragraph-spacing');
    const contentFontSize = document.getElementById('content-font-size');
    const contentFontColor = document.getElementById('content-font-color');
    const textAlign = document.getElementById('text-align');
    const titleTextAlign = document.getElementById('title-text-align');
    const showTitleCheckbox = document.getElementById('show-title-checkbox');
    const fontFamily = document.getElementById('font-family');
    
    // 更新封面卡片预览
    const previewCoverTitle = document.getElementById('preview-cover-title');
    const previewCoverSubtitle = document.getElementById('preview-cover-subtitle');
    const previewCoverDescription = document.getElementById('preview-cover-description');
    
    if (previewCoverTitle) {
        if (coverMainTitle) {
            previewCoverTitle.textContent = coverMainTitle.value || '大标题';
        }
        // 优先从textElementStates获取标题设置
        const titleColor = textElementStates.title.color || (coverMainTitleColor ? coverMainTitleColor.value : '#8B0000');
        const titleSize = textElementStates.title.size || (coverMainTitleSize ? parseInt(coverMainTitleSize.value) : 24);
        const titleFont = textElementStates.title.font || (coverMainTitleFont ? coverMainTitleFont.value : "'Yozai', serif");
        const titleBold = textElementStates.title.bold || (coverMainTitleBold ? coverMainTitleBold.checked : false);
        const titleAlign = textElementStates.title.alignment || (coverMainTitleAlign ? coverMainTitleAlign.value : 'center');
        const titleLineHeight = textElementStates.title.lineHeight || (coverMainTitleLineHeight ? parseFloat(coverMainTitleLineHeight.value) : 1.2);
        
        previewCoverTitle.style.color = titleColor;
        previewCoverTitle.style.fontSize = titleSize + 'px';
        previewCoverTitle.style.fontFamily = titleFont;
        previewCoverTitle.style.fontWeight = titleBold ? 'bold' : 'normal';
        previewCoverTitle.style.textAlign = titleAlign;
        previewCoverTitle.style.lineHeight = titleLineHeight;
    }
    
    if (previewCoverSubtitle) {
        if (coverSubTitle) {
            previewCoverSubtitle.textContent = coverSubTitle.value || '小标题';
        }
        // 优先从textElementStates获取小标题设置
        const subtitleColor = textElementStates.subtitle.color || (coverSubTitleColor ? coverSubTitleColor.value : '#b92727');
        const subtitleSize = textElementStates.subtitle.size || (coverSubTitleSize ? parseInt(coverSubTitleSize.value) : 22);
        const subtitleFont = textElementStates.subtitle.font || (coverSubTitleFont ? coverSubTitleFont.value : "'Yozai', serif");
        const subtitleBold = textElementStates.subtitle.bold || (coverSubTitleBold ? coverSubTitleBold.checked : false);
        const subtitleAlign = textElementStates.subtitle.alignment || (coverSubTitleAlign ? coverSubTitleAlign.value : 'center');
        const subtitleLineHeight = textElementStates.subtitle.lineHeight || (coverSubTitleLineHeight ? parseFloat(coverSubTitleLineHeight.value) : 1.2);
        
        previewCoverSubtitle.style.color = subtitleColor;
        previewCoverSubtitle.style.fontSize = subtitleSize + 'px';
        previewCoverSubtitle.style.fontFamily = subtitleFont;
        previewCoverSubtitle.style.fontWeight = subtitleBold ? 'bold' : 'normal';
        previewCoverSubtitle.style.textAlign = subtitleAlign;
        previewCoverSubtitle.style.lineHeight = subtitleLineHeight;
    }
    
    if (previewCoverDescription) {
        if (coverDescription) {
            previewCoverDescription.textContent = coverDescription.value || '内容简介';
        }
        // 优先从textElementStates获取描述设置
        const descriptionColor = textElementStates.description.color || (coverDescriptionColor ? coverDescriptionColor.value : '#8a460f');
        const descriptionSize = textElementStates.description.size || (coverDescriptionSize ? parseInt(coverDescriptionSize.value) : 18);
        const descriptionFont = textElementStates.description.font || (coverDescriptionFont ? coverDescriptionFont.value : "'Yozai', serif");
        const descriptionBold = textElementStates.description.bold || (coverDescriptionBold ? coverDescriptionBold.checked : false);
        const descriptionAlign = textElementStates.description.alignment || (coverDescriptionAlign ? coverDescriptionAlign.value : 'center');
        const descriptionLineHeight = textElementStates.description.lineHeight || (coverDescriptionLineHeight ? parseFloat(coverDescriptionLineHeight.value) : 1.2);
        
        previewCoverDescription.style.color = descriptionColor;
        previewCoverDescription.style.fontSize = descriptionSize + 'px';
        previewCoverDescription.style.fontFamily = descriptionFont;
        previewCoverDescription.style.fontWeight = descriptionBold ? 'bold' : 'normal';
        previewCoverDescription.style.textAlign = descriptionAlign;
        previewCoverDescription.style.lineHeight = descriptionLineHeight;
    }
    
    // 更新内容卡片预览
    const previewContentTitle = document.getElementById('preview-content-title');
    const previewContentBody = document.getElementById('preview-content-body');
    
    if (previewContentTitle) {
        if (cardTitle) {
            previewContentTitle.textContent = cardTitle.value || '内容卡片标题';
        }
        // 优先从contentCardTextSettings获取标题设置
        const titleFontSizeValue = contentCardTextSettings.title.fontSize || (titleFontSize ? titleFontSize.value : 24);
        const titleFontWeightValue = contentCardTextSettings.title.fontWeight || (titleFontWeight ? titleFontWeight.value : 'bold');
        const titleFontColorValue = contentCardTextSettings.title.fontColor || (titleFontColor ? titleFontColor.value : '#333333');
        const titleTextAlignValue = contentCardTextSettings.title.textAlign || (titleTextAlign ? titleTextAlign.value : 'left');
        const titleFontFamilyValue = contentCardTextSettings.title.fontFamily || (fontFamily ? fontFamily.value : "'Yozai', serif");
        const showTitleValue = contentCardTextSettings.title.showTitle || (showTitleCheckbox ? showTitleCheckbox.checked : true);
        
        previewContentTitle.style.fontSize = titleFontSizeValue + 'px';
        previewContentTitle.style.fontWeight = titleFontWeightValue;
        previewContentTitle.style.color = titleFontColorValue;
        previewContentTitle.style.textAlign = titleTextAlignValue;
        previewContentTitle.style.fontFamily = titleFontFamilyValue;
        previewContentTitle.style.display = showTitleValue ? 'block' : 'none';
    }
    
    if (previewContentBody) {
        if (cardContent) {
            // 处理段落间距，将\n\n替换为带有margin-bottom的p标签
            const content = cardContent.value || '请输入卡片内容';
            if (content.includes('\n\n')) {
                // 有多个段落，使用p标签
                const paragraphs = content.split('\n\n').filter(p => p.trim() !== '');
                previewContentBody.innerHTML = paragraphs.map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`).join('');
                // 应用段落间距、行间距和字体颜色
                const pElements = previewContentBody.querySelectorAll('p');
                pElements.forEach(p => {
                    const paragraphSpacingValue = contentCardTextSettings.content.paragraphSpacing || (contentParagraphSpacing ? contentParagraphSpacing.value : 12);
                    const lineHeightValue = contentCardTextSettings.content.lineHeight || (contentLineHeight ? contentLineHeight.value : 1.5);
                    const contentFontColorValue = contentCardTextSettings.content.fontColor || (contentFontColor ? contentFontColor.value : '#666666');
                    const contentTextAlignValue = contentCardTextSettings.content.textAlign || (textAlign ? textAlign.value : 'left');
                    const contentFontFamilyValue = contentCardTextSettings.content.fontFamily || (fontFamily ? fontFamily.value : "'Yozai', serif");
                    
                    p.style.marginBottom = paragraphSpacingValue + 'px';
                    p.style.lineHeight = lineHeightValue;
                    p.style.color = contentFontColorValue;
                    p.style.textAlign = contentTextAlignValue;
                    p.style.fontFamily = contentFontFamilyValue;
                });
            } else {
                // 只有一个段落，直接显示
                previewContentBody.innerHTML = content.replace(/\n/g, '<br>');
            }
        }
        // 优先从contentCardTextSettings获取内容设置
        const contentFontSizeValue = contentCardTextSettings.content.fontSize || (contentFontSize ? contentFontSize.value : 14);
        const contentFontColorValue = contentCardTextSettings.content.fontColor || (contentFontColor ? contentFontColor.value : '#666666');
        const lineHeightValue = contentCardTextSettings.content.lineHeight || (contentLineHeight ? contentLineHeight.value : 1.5);
        const contentTextAlignValue = contentCardTextSettings.content.textAlign || (textAlign ? textAlign.value : 'left');
        const contentFontFamilyValue = contentCardTextSettings.content.fontFamily || (fontFamily ? fontFamily.value : "'Yozai', serif");
        
        previewContentBody.style.fontSize = contentFontSizeValue + 'px';
        previewContentBody.style.color = contentFontColorValue;
        previewContentBody.style.lineHeight = lineHeightValue;
        previewContentBody.style.textAlign = contentTextAlignValue;
        previewContentBody.style.fontFamily = contentFontFamilyValue;
    }
    
    // 更新卡片样式
    const coverCard = document.getElementById('cover-card');
    const contentCard = document.getElementById('content-card');
    
    if (coverCard) {
        coverCard.style.borderWidth = cardStyleSettings.cover.borderWidth + 'px';
        coverCard.style.borderColor = cardStyleSettings.cover.borderColor;
        coverCard.style.borderStyle = 'solid';
        coverCard.style.borderRadius = cardStyleSettings.cover.borderRadius + 'px';
        
        // 应用渐变背景
        const coverGradient = document.querySelector('.cover-card .cover-gradient');
        if (coverGradient) {
            // 不要隐藏渐变背景，让它始终显示
            if (gradientSettings.cover.type === 'linear') {
                coverGradient.style.background = `linear-gradient(${gradientSettings.cover.angle}deg, ${gradientSettings.cover.color1}, ${gradientSettings.cover.color2})`;
            } else {
                coverGradient.style.background = `radial-gradient(circle, ${gradientSettings.cover.color1}, ${gradientSettings.cover.color2})`;
            }
        }
        
        // 应用背景图片
        if (backgroundImageData.cover.useImage && backgroundImageData.cover.image) {
            // 先移除现有的背景图片层
            let existingBgLayer = document.querySelector('.bg-image-layer');
            if (existingBgLayer) {
                existingBgLayer.remove();
            }
            
            // 创建专门的背景图片层
            let bgImageLayer = document.createElement('div');
            bgImageLayer.className = 'bg-image-layer';
            bgImageLayer.style.position = 'absolute';
            bgImageLayer.style.backgroundImage = `url(${backgroundImageData.cover.image})`;
            bgImageLayer.style.top = 0;
            bgImageLayer.style.left = 0;
            bgImageLayer.style.width = '100%';
            bgImageLayer.style.height = '100%';
            bgImageLayer.style.backgroundSize = 'cover';
            bgImageLayer.style.backgroundPosition = 'center';
            
            // 设置背景图片透明度
            bgImageLayer.style.opacity = backgroundImageData.cover.opacity / 100;
            
            // 设置z-index，确保在渐变背景之上但在文字之下
            bgImageLayer.style.zIndex = 1;
            
            // 添加到cover-card的开头，确保它在文字之下
            coverCard.insertBefore(bgImageLayer, coverCard.firstChild);
        } else {
            // 移除背景图片层
            let existingBgLayer = document.querySelector('.bg-image-layer');
            if (existingBgLayer) {
                existingBgLayer.remove();
            }
        }
        
        // 确保文字在最上层
        const textElements = coverCard.querySelectorAll('h3,p');
        textElements.forEach(text => {
            text.style.position = 'relative';
            text.style.zIndex = 10;
        });
        
        // 确保渐变背景在文字之下
        if (coverGradient) {
            coverGradient.style.zIndex = 0;
        }
    }
    
    if (contentCard) {
        contentCard.style.borderWidth = cardStyleSettings.content.borderWidth + 'px';
        contentCard.style.borderColor = cardStyleSettings.content.borderColor;
        contentCard.style.borderStyle = 'solid';
        contentCard.style.borderRadius = cardStyleSettings.content.borderRadius + 'px';
        
        // 移除现有的背景层
        let existingGradientLayer = document.querySelector('.content-gradient-layer');
        if (existingGradientLayer) {
            existingGradientLayer.remove();
        }
        let existingBgLayer = document.querySelector('.content-bg-image-layer');
        if (existingBgLayer) {
            existingBgLayer.remove();
        }
        
        // 创建渐变背景层
        let gradientLayer = document.createElement('div');
        gradientLayer.className = 'content-gradient-layer';
        gradientLayer.style.position = 'absolute';
        gradientLayer.style.top = 0;
        gradientLayer.style.left = 0;
        gradientLayer.style.width = '100%';
        gradientLayer.style.height = '100%';
        
        if (gradientSettings.content.type === 'linear') {
            gradientLayer.style.background = `linear-gradient(${gradientSettings.content.angle}deg, ${gradientSettings.content.color1}, ${gradientSettings.content.color2})`;
        } else {
            gradientLayer.style.background = `radial-gradient(circle, ${gradientSettings.content.color1}, ${gradientSettings.content.color2})`;
        }
        
        gradientLayer.style.zIndex = 0;
        contentCard.insertBefore(gradientLayer, contentCard.firstChild);
        
        // 应用背景图片
        if (backgroundImageData.content.useImage && backgroundImageData.content.image) {
            // 创建专门的背景图片层
            let bgImageLayer = document.createElement('div');
            bgImageLayer.className = 'content-bg-image-layer';
            bgImageLayer.style.position = 'absolute';
            bgImageLayer.style.backgroundImage = `url(${backgroundImageData.content.image})`;
            bgImageLayer.style.top = 0;
            bgImageLayer.style.left = 0;
            bgImageLayer.style.width = '100%';
            bgImageLayer.style.height = '100%';
            bgImageLayer.style.backgroundSize = 'cover';
            bgImageLayer.style.backgroundPosition = 'center';
            
            // 设置背景图片透明度
            bgImageLayer.style.opacity = backgroundImageData.content.opacity / 100;
            
            // 设置z-index，确保在渐变背景之上但在文字之下
            bgImageLayer.style.zIndex = 1;
            
            // 添加到content-card的开头，确保它在文字之下
            contentCard.insertBefore(bgImageLayer, contentCard.firstChild);
        }
        
        // 确保文字元素在背景图片之上
        const cardHeader = contentCard.querySelector('.card-header');
        const cardBody = contentCard.querySelector('.card-body');
        const cardFooter = contentCard.querySelector('.card-footer');
        
        if (cardHeader) {
            cardHeader.style.position = 'relative';
            cardHeader.style.zIndex = 5;
        }
        if (cardBody) {
            cardBody.style.position = 'relative';
            cardBody.style.zIndex = 5;
        }
        if (cardFooter) {
            cardFooter.style.position = 'relative';
            cardFooter.style.zIndex = 5;
        }
        
        // 确保文字在最上层
        const contentTextElements = contentCard.querySelectorAll('h3,p');
        contentTextElements.forEach(text => {
            text.style.position = 'relative';
            text.style.zIndex = 10;
        });
    }
    
    // 只有在自动换行关闭时才调整容器宽度
    const textAutoWrap = document.getElementById('text-auto-wrap');
    if (!textAutoWrap || !textAutoWrap.checked) {
        adjustAllTextContainerWidths();
    }
    
    // 更新图层视觉顺序，确保涂鸦画布在最前面
    updateLayerVisualOrder();
}

// 显示状态消息
function showStatus(message, type = 'info') {
    const statusMessage = document.getElementById('status-message');
    if (statusMessage) {
        statusMessage.textContent = message;
        statusMessage.style.display = 'block';
        
        // 设置消息样式
        switch (type) {
            case 'error':
                statusMessage.style.backgroundColor = '#f44336';
                break;
            case 'success':
                statusMessage.style.backgroundColor = '#4caf50';
                break;
            case 'warning':
                statusMessage.style.backgroundColor = '#ff9800';
                break;
            default:
                statusMessage.style.backgroundColor = '#2196f3';
        }
        
        // 3秒后自动隐藏
        setTimeout(() => {
            statusMessage.style.display = 'none';
        }, 3000);
    }
}

// 测试函数
function testFunction() {
    console.log('测试函数被调用');
    showStatus('测试函数执行成功', 'success');
}

// 应用配色方案
function applyColorScheme(schemeName, cardType) {
    const scheme = colorSchemes[schemeName];
    if (!scheme) return;
    
    // 更新配色方案设置
    gradientSettings[cardType].color1 = scheme.gradientColor1;
    gradientSettings[cardType].color2 = scheme.gradientColor2;
    
    // 更新卡片样式
    cardStyleSettings[cardType].borderColor = scheme.borderColor;
    
    // 更新UI控件
    const gradientColor1 = document.getElementById('gradient-color-1');
    const gradientColor2 = document.getElementById('gradient-color-2');
    const borderColor = document.getElementById('border-color');
    
    if (gradientColor1) {
        gradientColor1.value = scheme.gradientColor1;
    }
    if (gradientColor2) {
        gradientColor2.value = scheme.gradientColor2;
    }
    if (borderColor) {
        borderColor.value = scheme.borderColor;
    }
    
    // 更新预览
    updatePreview();
}

// 下载当前卡片
function downloadCurrentCard() {
    const cardToDownload = currentCardType === 'cover' ? document.getElementById('cover-card') : document.getElementById('content-card');
    if (cardToDownload) {
        showStatus('正在生成图片...', 'info');
        
        // 使用html2canvas库将卡片转换为图片
        if (typeof html2canvas === 'function') {
            html2canvas(cardToDownload, {
                backgroundColor: null,
                scale: 2, // 提高图片清晰度
                useCORS: true
            }).then(canvas => {
                // 将canvas转换为图片并下载
                const link = document.createElement('a');
                link.download = `${currentCardType === 'cover' ? 'cover' : 'content'}_card_${Date.now()}.png`;
                link.href = canvas.toDataURL('image/png');
                link.click();
                showStatus('下载成功！', 'success');
            }).catch(error => {
                console.error('生成图片失败:', error);
                showStatus('生成图片失败', 'error');
            });
        } else {
            showStatus('html2canvas库未加载', 'error');
        }
    }
}

// 批量下载卡片
async function batchDownloadCards() {
    if (!cardData || cardData.length === 0) {
        showStatus('没有可下载的卡片', 'error');
        return;
    }
    
    showStatus('正在批量下载卡片...', 'info');
    
    try {
        const textOnlyCheckbox = document.getElementById('text-only-checkbox');
        const textOnly = textOnlyCheckbox ? textOnlyCheckbox.checked : false;
        
        let downloadedCount = 0;
        const totalCards = cardData.length + 1; // 包括封面
        
        // 先下载封面卡片
        const coverCard = document.getElementById('cover-card');
        if (coverCard) {
            if (textOnly) {
                // 只下载文字内容
                const coverTitle = document.getElementById('text-input')?.value || '封面标题';
                const coverSubtitle = document.getElementById('cover-sub-title')?.value || '封面小标题';
                const coverDescription = document.getElementById('cover-description')?.value || '封面描述';
                
                const coverContent = `封面大标题: ${coverTitle}\n\n封面小标题: ${coverSubtitle}\n\n封面描述: ${coverDescription}`;
                const blob = new Blob([coverContent], { type: 'text/plain;charset=utf-8' });
                saveAs(blob, `00_封面.txt`);
            } else {
                // 下载图片
                if (typeof html2canvas === 'function') {
                    const canvas = await html2canvas(coverCard, {
                        backgroundColor: null,
                        scale: 2,
                        useCORS: true
                    });
                    
                    // 使用Promise包装canvas.toBlob，确保异步操作完成
                    await new Promise((resolve) => {
                        canvas.toBlob(function(blob) {
                            if (blob) {
                                saveAs(blob, `00_封面.png`);
                            }
                            resolve();
                        });
                    });
                }
            }
            downloadedCount++;
        }
        
        // 下载内容卡片
        for (let i = 0; i < cardData.length; i++) {
            const card = cardData[i];
            
            // 先更新当前卡片
            currentPage = i + 1;
            loadCurrentPageData();
            updatePreview();
            
            // 等待DOM更新
            await new Promise(resolve => setTimeout(resolve, 200));
            
            if (textOnly) {
                // 只下载文字内容
                const content = `标题: ${card.title}\n\n内容: ${card.content}`;
                const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                saveAs(blob, `${String(i + 1).padStart(2, '0')}_${card.title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '_')}.txt`);
            } else {
                // 下载图片
                const contentCard = document.getElementById('content-card');
                if (contentCard && typeof html2canvas === 'function') {
                    // 确保内容卡片可见
                    contentCard.style.display = 'block';
                    
                    const canvas = await html2canvas(contentCard, {
                        backgroundColor: null,
                        scale: 2,
                        useCORS: true
                    });
                    
                    // 使用Promise包装canvas.toBlob，确保异步操作完成
                    await new Promise((resolve) => {
                        canvas.toBlob(function(blob) {
                            if (blob) {
                                saveAs(blob, `${String(i + 1).padStart(2, '0')}_${card.title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '_')}.png`);
                            }
                            resolve();
                        });
                    });
                }
            }
            downloadedCount++;
            
            // 等待一段时间，避免浏览器阻塞
            if (i < cardData.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }
        
        showStatus(`成功下载 ${downloadedCount} 张卡片`, 'success');
    } catch (error) {
        console.error('批量下载失败:', error);
        showStatus('批量下载失败: ' + error.message, 'error');
    }
}

// 导入配置
function importConfig() {
    const configUpload = document.getElementById('config-upload');
    if (configUpload) {
        configUpload.click();
    }
}

// 导出配置
function exportConfig() {
    const config = {
        // 版本信息
        version: '1.0',
        exportDate: new Date().toISOString(),
        
        // 基本设置
        currentCardType,
        currentPage,
        totalPages,
        
        // 卡片数据
        cardData,
        
        // 视觉样式设置
        currentColorSchemes,
        gradientSettings,
        cardStyleSettings,
        backgroundImageData,
        
        // 封面元素设置
        coverElementsTransform,
        
        // 文本设置
        textElementAutoWrapState,
        textElementStates,
        
        // 内容卡片文字设置
        contentCardTextSettings,
        
        // 涂鸦功能设置
        doodleSettings: {
            brushSize,
            brushColor,
            brushOpacity,
            currentTool,
            drawMode,
            cornerRadius,
            waveAmplitude,
            waveFrequency
        }
    };
    
    const configBlob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.download = `card_generator_config_${Date.now()}.json`;
    link.href = URL.createObjectURL(configBlob);
    link.click();
    showStatus('配置导出成功！', 'success');
}

// 处理配置文件选择
function handleConfigFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const config = JSON.parse(e.target.result);
                console.log('开始导入配置，版本:', config.version);
                
                // 应用配置
                
                // 基本设置
                if (config.currentCardType) {
                    currentCardType = config.currentCardType;
                }
                if (config.currentPage) {
                    currentPage = config.currentPage;
                }
                if (config.totalPages) {
                    totalPages = config.totalPages;
                }
                
                // 卡片数据
                if (config.cardData) {
                    cardData = config.cardData;
                }
                
                // 视觉样式设置
                if (config.currentColorSchemes) {
                    currentColorSchemes = config.currentColorSchemes;
                }
                if (config.gradientSettings) {
                    gradientSettings = config.gradientSettings;
                }
                if (config.cardStyleSettings) {
                    cardStyleSettings = config.cardStyleSettings;
                }
                if (config.backgroundImageData) {
                    backgroundImageData = config.backgroundImageData;
                }
                
                // 封面元素设置
                if (config.coverElementsTransform) {
                    coverElementsTransform = config.coverElementsTransform;
                }
                
                // 文本设置
                if (config.textElementAutoWrapState) {
                    textElementAutoWrapState = config.textElementAutoWrapState;
                }
                if (config.textElementStates) {
                    textElementStates = config.textElementStates;
                }
                
                // 内容卡片文字设置
                if (config.contentCardTextSettings) {
                    contentCardTextSettings = config.contentCardTextSettings;
                }
                
                // 涂鸦功能设置
                if (config.doodleSettings) {
                    const doodleSettings = config.doodleSettings;
                    if (doodleSettings.brushSize !== undefined) brushSize = doodleSettings.brushSize;
                    if (doodleSettings.brushColor) brushColor = doodleSettings.brushColor;
                    if (doodleSettings.brushOpacity !== undefined) brushOpacity = doodleSettings.brushOpacity;
                    if (doodleSettings.currentTool) currentTool = doodleSettings.currentTool;
                    if (doodleSettings.drawMode) drawMode = doodleSettings.drawMode;
                    if (doodleSettings.cornerRadius !== undefined) cornerRadius = doodleSettings.cornerRadius;
                    if (doodleSettings.waveAmplitude !== undefined) waveAmplitude = doodleSettings.waveAmplitude;
                    if (doodleSettings.waveFrequency !== undefined) waveFrequency = doodleSettings.waveFrequency;
                }
                
                // 更新内容卡片的文字设置UI元素
                const titleFontSize = document.getElementById('title-font-size');
                const titleFontWeight = document.getElementById('title-font-weight');
                const titleFontColor = document.getElementById('title-font-color');
                const titleTextAlign = document.getElementById('title-text-align');
                const showTitleCheckbox = document.getElementById('show-title-checkbox');
                const fontFamily = document.getElementById('font-family');
                const contentFontSize = document.getElementById('content-font-size');
                const contentFontColor = document.getElementById('content-font-color');
                const contentLineHeight = document.getElementById('content-line-height');
                const contentParagraphSpacing = document.getElementById('content-paragraph-spacing');
                const textAlign = document.getElementById('text-align');
                
                if (titleFontSize) {
                    titleFontSize.value = contentCardTextSettings.title.fontSize || 24;
                }
                if (titleFontWeight) {
                    titleFontWeight.value = contentCardTextSettings.title.fontWeight || 'bold';
                }
                if (titleFontColor) {
                    titleFontColor.value = contentCardTextSettings.title.fontColor || '#333333';
                }
                if (titleTextAlign) {
                    titleTextAlign.value = contentCardTextSettings.title.textAlign || 'left';
                }
                if (showTitleCheckbox) {
                    showTitleCheckbox.checked = contentCardTextSettings.title.showTitle || true;
                }
                if (fontFamily) {
                    fontFamily.value = contentCardTextSettings.title.fontFamily || "'Yozai', serif";
                }
                if (contentFontSize) {
                    contentFontSize.value = contentCardTextSettings.content.fontSize || 14;
                }
                if (contentFontColor) {
                    contentFontColor.value = contentCardTextSettings.content.fontColor || '#666666';
                }
                if (contentLineHeight) {
                    contentLineHeight.value = contentCardTextSettings.content.lineHeight || 1.5;
                }
                if (contentParagraphSpacing) {
                    contentParagraphSpacing.value = contentCardTextSettings.content.paragraphSpacing || 12;
                }
                if (textAlign) {
                    textAlign.value = contentCardTextSettings.content.textAlign || 'left';
                }
                
                // 更新UI
                switchCardType(currentCardType);
                
                // 更新封面卡片的文字设置UI元素
                const coverMainTitleFont = document.getElementById('cover-main-title-font');
                const coverSubTitleFont = document.getElementById('cover-sub-title-font');
                const coverDescriptionFont = document.getElementById('cover-description-font');
                const coverMainTitleColor = document.getElementById('cover-main-title-color');
                const coverSubTitleColor = document.getElementById('cover-sub-title-color');
                const coverDescriptionColor = document.getElementById('cover-description-color');
                const coverMainTitleSize = document.getElementById('cover-main-title-size');
                const coverSubTitleSize = document.getElementById('cover-sub-title-size');
                const coverDescriptionSize = document.getElementById('cover-description-size');
                const coverMainTitleBold = document.getElementById('cover-main-title-bold');
                const coverSubTitleBold = document.getElementById('cover-sub-title-bold');
                const coverDescriptionBold = document.getElementById('cover-description-bold');
                const coverMainTitleAlign = document.getElementById('cover-main-title-align');
                const coverSubTitleAlign = document.getElementById('cover-sub-title-align');
                const coverDescriptionAlign = document.getElementById('cover-description-align');
                const coverMainTitleLineHeight = document.getElementById('cover-main-title-line-height');
                const coverSubTitleLineHeight = document.getElementById('cover-sub-title-line-height');
                const coverDescriptionLineHeight = document.getElementById('cover-description-line-height');
                
                if (coverMainTitleFont) {
                    coverMainTitleFont.value = textElementStates.title.font || "'Yozai', serif";
                }
                if (coverSubTitleFont) {
                    coverSubTitleFont.value = textElementStates.subtitle.font || "'Yozai', serif";
                }
                if (coverDescriptionFont) {
                    coverDescriptionFont.value = textElementStates.description.font || "'Yozai', serif";
                }
                if (coverMainTitleColor) {
                    coverMainTitleColor.value = textElementStates.title.color || '#8B0000';
                }
                if (coverSubTitleColor) {
                    coverSubTitleColor.value = textElementStates.subtitle.color || '#b92727';
                }
                if (coverDescriptionColor) {
                    coverDescriptionColor.value = textElementStates.description.color || '#8a460f';
                }
                if (coverMainTitleSize) {
                    coverMainTitleSize.value = textElementStates.title.size || 24;
                }
                if (coverSubTitleSize) {
                    coverSubTitleSize.value = textElementStates.subtitle.size || 22;
                }
                if (coverDescriptionSize) {
                    coverDescriptionSize.value = textElementStates.description.size || 18;
                }
                if (coverMainTitleBold) {
                    coverMainTitleBold.checked = textElementStates.title.bold || false;
                }
                if (coverSubTitleBold) {
                    coverSubTitleBold.checked = textElementStates.subtitle.bold || false;
                }
                if (coverDescriptionBold) {
                    coverDescriptionBold.checked = textElementStates.description.bold || false;
                }
                if (coverMainTitleAlign) {
                    coverMainTitleAlign.value = textElementStates.title.alignment || 'center';
                }
                if (coverSubTitleAlign) {
                    coverSubTitleAlign.value = textElementStates.subtitle.alignment || 'center';
                }
                if (coverDescriptionAlign) {
                    coverDescriptionAlign.value = textElementStates.description.alignment || 'center';
                }
                if (coverMainTitleLineHeight) {
                    coverMainTitleLineHeight.value = textElementStates.title.lineHeight || 1.2;
                }
                if (coverSubTitleLineHeight) {
                    coverSubTitleLineHeight.value = textElementStates.subtitle.lineHeight || 1.2;
                }
                if (coverDescriptionLineHeight) {
                    coverDescriptionLineHeight.value = textElementStates.description.lineHeight || 1.2;
                }
                
                updatePreview();
                updatePageInfo();
                showStatus('配置导入成功！', 'success');
                console.log('配置导入完成');
            } catch (error) {
                console.error('解析配置文件失败:', error);
                showStatus('解析配置文件失败', 'error');
            }
        };
        reader.readAsText(file);
    }
}

// 加载背景图片
function loadBackgroundImage(input, cardType) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            backgroundImageData[cardType].image = e.target.result;
            backgroundImageData[cardType].useImage = true;
            updatePreview();
            showStatus('背景图片加载成功！', 'success');
        };
        reader.readAsDataURL(file);
    }
}

// 更新页面信息
function updatePageInfo() {
    const currentPageElement = document.getElementById('current-page');
    const pageInput = document.getElementById('page-input');
    const pageNumberElement = document.getElementById('page-number');
    
    if (currentPageElement) currentPageElement.textContent = currentPage;
    if (pageInput) pageInput.value = currentPage;
    if (pageNumberElement) pageNumberElement.textContent = `第${currentPage}页`;
}

// 加载当前页面数据
function loadCurrentPageData() {
    if (currentCardType === 'content' && currentPage <= totalPages) {
        const cardDataItem = cardData[currentPage - 1];
        if (cardDataItem) {
            const cardTitle = document.getElementById('card-title');
            const cardContent = document.getElementById('card-content');
            
            if (cardTitle) {
                cardTitle.value = cardDataItem.title;
            }
            if (cardContent) {
                cardContent.value = cardDataItem.content;
            }
            
            // 更新预览
            updatePreview();
        }
    }
    
    // 更新页码显示
    updatePageInfo();
}

// 初始化
async function init() {
    try {
        console.log('开始初始化...');
        
        // 等待DOM完全加载
        await new Promise(resolve => {
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                resolve();
            } else {
                document.addEventListener('DOMContentLoaded', resolve);
            }
        });
        
        console.log('DOM完全加载完成');
        
        // 加载卡片数据
        await loadCardData();
        console.log('卡片数据加载完成');
        
        // 初始化事件监听器
        initEventListeners();
        console.log('事件监听器初始化完成');
        
        // 初始化内容编辑区显示状态
        if (currentCardType === 'cover') {
            document.getElementById('cover-edit-section').style.display = 'block';
            document.getElementById('content-edit-section').style.display = 'none';
            // 隐藏分页导航
            document.getElementById('pagination-section').style.display = 'none';
        } else {
            document.getElementById('content-edit-section').style.display = 'block';
            document.getElementById('cover-edit-section').style.display = 'none';
            // 显示分页导航
            document.getElementById('pagination-section').style.display = 'block';
        }
        
        // 应用默认配色方案（Apple iOS）
        applyColorScheme('apple-ios', 'cover');
        applyColorScheme('apple-ios', 'content');
        console.log('配色方案应用完成');
        
        // 设置默认字体为悠哉字体
        const coverFontFamily = document.getElementById('cover-font-family');
        const contentFontFamily = document.getElementById('font-family');
        if (coverFontFamily) {
            coverFontFamily.value = "'Yozai', serif";
        }
        if (contentFontFamily) {
            contentFontFamily.value = "'Yozai', serif";
        }
        
        // 设置默认文字颜色
        const coverMainTitleColor = document.getElementById('cover-main-title-color');
        const coverSubTitleColor = document.getElementById('cover-sub-title-color');
        const coverDescriptionColor = document.getElementById('cover-description-color');
        if (coverMainTitleColor) {
            coverMainTitleColor.value = '#8B0000'; // 深红色
        }
        if (coverSubTitleColor) {
            coverSubTitleColor.value = '#00008B'; // 深蓝色
        }
        if (coverDescriptionColor) {
            coverDescriptionColor.value = '#FF8C00'; // 深橙色
        }
        
        // 初始化系统字体选项
        initSystemFontOptions();
        console.log('系统字体选项初始化完成');
        
        // 初始化UI上的渐变背景设置，显示当前卡片类型的设置
        const gradientType = document.getElementById('gradient-type');
        const gradientAngle = document.getElementById('gradient-angle');
        const gradientAngleValue = document.getElementById('gradient-angle-value');
        const gradientColor1 = document.getElementById('gradient-color-1');
        const gradientColor2 = document.getElementById('gradient-color-2');
        
        if (gradientType) {
            gradientType.value = gradientSettings[currentCardType].type;
        }
        if (gradientAngle) {
            gradientAngle.value = gradientSettings[currentCardType].angle;
        }
        if (gradientAngleValue) {
            gradientAngleValue.textContent = gradientSettings[currentCardType].angle + '°';
        }
        if (gradientColor1) {
            gradientColor1.value = gradientSettings[currentCardType].color1;
        }
        if (gradientColor2) {
            gradientColor2.value = gradientSettings[currentCardType].color2;
        }
        
        // 初始化UI上的卡片样式设置，显示当前卡片类型的设置
        const borderWidth = document.getElementById('border-width');
        const borderWidthValue = document.getElementById('border-width-value');
        const borderColor = document.getElementById('border-color');
        const cardRadius = document.getElementById('card-radius');
        const cardRadiusValue = document.getElementById('card-radius-value');
        
        if (borderWidth) {
            borderWidth.value = cardStyleSettings[currentCardType].borderWidth;
        }
        if (borderWidthValue) {
            borderWidthValue.textContent = cardStyleSettings[currentCardType].borderWidth + 'px';
        }
        if (borderColor) {
            borderColor.value = cardStyleSettings[currentCardType].borderColor;
        }
        if (cardRadius) {
            cardRadius.value = cardStyleSettings[currentCardType].borderRadius;
        }
        if (cardRadiusValue) {
            cardRadiusValue.textContent = cardStyleSettings[currentCardType].borderRadius + 'px';
        }
        
        // 更新配色方案区域的激活状态
        updateColorSchemeSelection();
        
        // 加载当前页面数据
        loadCurrentPageData();
        
        // 更新预览
        updatePreview();
        
        // 初始化涂鸦功能
        initDoodleCanvas();
        bindToolEvents();
        
        // 初始化图层视觉顺序
        updateLayerVisualOrder();
        
        // 延迟调整所有文本容器宽度，确保DOM完全渲染
        setTimeout(() => {
            console.log('开始调整文本容器宽度');
            
            // 先确保所有文本元素都有正确的内容
            const titleText = document.getElementById('preview-cover-title');
            const subtitleText = document.getElementById('preview-cover-subtitle');
            const descriptionText = document.getElementById('preview-cover-description');
            
            // 确保文本内容存在
            if (titleText && !titleText.textContent) {
                titleText.textContent = '腊八卡片生成器';
            }
            if (subtitleText && !subtitleText.textContent) {
                subtitleText.textContent = '编程使我快乐\n制作了这个卡片生成器\n希望大家能喜欢';
            }
            if (descriptionText && !descriptionText.textContent) {
                descriptionText.textContent = '作者小红书号：4212737469\n作者哔哩哔哩账号： 乂海狸';
            }
            
            // 强制重排
            document.body.offsetWidth;
            
            // 调整所有文本容器宽度
            adjustAllTextContainerWidths();
            
            console.log('预览初始化完成');
        }, 1000);
        
        console.log('初始化完成！');
    } catch (error) {
        console.error('初始化失败:', error);
        showStatus('初始化失败', 'error');
    }
}

// 加载卡片数据
async function loadCardData() {
    try {
        // 模拟从txt文件加载数据
        cardData = [
            {
                title: "本世纪第二晚的腊八节",
                content: "2026年1月26日的腊八节特别引人关注，因为它是本世纪第二晚的腊八节，仅仅比2084年1月27日的腊八节早一天。我查了一下资料，发现这种现象其实和咱们老祖宗传下来的农历置闰规则密切相关。\n\n你知道吗，2025年农历有一个闰十月，这就把整个农历年拉长了，结果腊月（也就是农历十二月）就跟着往后推迟了，腊八节作为农历十二月初八，对应的公历日期自然也就延后了。"
            },
            {
                title: "置闰：传统历法的智慧",
                content: "说到农历，咱们都知道它是阴阳合历，既要跟着月亮的阴晴圆缺走，又要兼顾太阳公转的周期。可你知道吗，月亮绕地球一圈大概是29.5天，12个月下来也就354天左右，比太阳公转的365天少了11天左右。\n\n为了让这两个周期对上，古人就发明了置闰法，差不多每19年要加7个闰月。我觉得这置闰规则特别有意思，就像大自然的时间调节器一样。"
            },
            {
                title: "腊八节的传统习俗",
                content: "腊八节的习俗可丰富了，我最熟悉的就是喝腊八粥。我记得小时候，每到腊八节，我妈一大早就起来熬粥，锅里放着大米、小米、红豆、绿豆、花生、枣子等好多食材，整个家里都飘着香味。\n\n民间还有句俗语叫\"腊八腊八，冻掉下巴\"，意思是说腊八前后天气特别冷，喝碗热乎的腊八粥正好暖和暖和。"
            },
            {
                title: "传统节日的现代意义",
                content: "现在大家平时都挺忙的，每天跟着公历的节奏跑，很少有时间停下来想想生活的意义。我觉得传统节日就像一个个锚点，提醒我们慢下来，陪陪家人，感受一下生活的仪式感。\n\n就拿腊八节来说，不管多忙，我都会抽空自己熬一锅粥，哪怕简单点，也觉得心里踏实。"
            },
            {
                title: "节日的文化温度",
                content: "我觉得节日的真正意义不在于它具体在哪一天，而在于它所承载的文化温度。今年的腊八节虽然来得特别晚，但那份温暖的感觉一点都没少。早上我给家里打电话，我妈说她又熬了腊八粥，还说等我回家的时候再给我做。\n\n你看，这就是节日的力量——不管相隔多远，它总能把家人的心连在一起。"
            }
        ];
        
        totalPages = cardData.length;
        const totalPagesElement = document.getElementById('total-pages');
        const pageInputElement = document.getElementById('page-input');
        if (totalPagesElement) {
            totalPagesElement.textContent = totalPages;
        }
        if (pageInputElement) {
            pageInputElement.max = totalPages;
        }
        
    } catch (error) {
        console.error('加载卡片数据失败:', error);
        showStatus('加载卡片数据失败', 'error');
    }
}

// 初始化事件监听器
function initEventListeners() {
    // 文本编辑器元素
    const textInput = document.getElementById('text-input');
    const textColor = document.getElementById('text-color');
    const textBold = document.getElementById('text-bold');
    const textSize = document.getElementById('text-size');
    const textFont = document.getElementById('text-font');
    const textLineHeight = document.getElementById('text-line-height');
    const textAlignment = document.getElementById('text-align-editor');
    
    // 图层管理事件监听
    const layerItems = document.querySelectorAll('.layer-item');
    let draggedItem = null;
    
    layerItems.forEach(item => {
        // 点击事件
        item.addEventListener('click', function(e) {
            e.stopPropagation();
            const layerType = this.dataset.layer;
            
            // 更新图层选中状态
            document.querySelectorAll('.layer-item').forEach(layer => {
                layer.classList.remove('selected');
                layer.classList.remove('doodle-active');
                layer.classList.remove('locked');
                // 恢复所有图层的可点击性
                layer.style.pointerEvents = 'auto';
                layer.style.opacity = '1';
            });
            this.classList.add('selected');
            
            // 显示/隐藏涂鸦工具栏
            const doodleSettings = document.getElementById('doodle-settings');
            if (doodleSettings) {
                if (layerType === 'doodle') {
                    doodleSettings.style.display = 'block';
                    this.classList.add('doodle-active');
                    // 激活涂鸦画布
                    toggleDoodleLayer(true);
                    
                    // 不锁定其他图层，只添加视觉锁定效果
                    document.querySelectorAll('.layer-item:not([data-layer="doodle"])').forEach(layer => {
                        layer.classList.add('locked');
                        // 保留pointer-events，确保可以点击其他图层退出涂鸦模式
                        // layer.style.pointerEvents = 'none';
                        layer.style.opacity = '0.5';
                    });
                    
                    // 设置涂鸦层激活状态
                    isDoodleLayerActive = true;
                    
                    // 更新涂鸦画布尺寸，确保覆盖整个画布
                    updateDoodleCanvasSize();
                    
                    console.log('选中涂鸦层，已添加视觉锁定效果，保留点击其他图层的能力');
                } else {
                    doodleSettings.style.display = 'none';
                    // 禁用涂鸦画布
                    toggleDoodleLayer(false);
                    
                    // 解锁所有图层
                    isDoodleLayerActive = false;
                    
                    console.log('选中非涂鸦层，已解锁所有图层，启用其他图层脚本');
                }
            }
            
            // 更新画板选中状态
            selectedElement = layerType;
            updateElementsTransform();
            
            // 更新文本编辑器内容和设置
            if (layerType === 'title' || layerType === 'subtitle' || layerType === 'description') {
                updateTextEditor(layerType);
            }
        });
        
        // 拖拽开始事件
        item.addEventListener('dragstart', function(e) {
            draggedItem = this;
            this.style.opacity = '0.5';
            e.dataTransfer.effectAllowed = 'move';
            console.log('开始拖拽图层:', this.dataset.layer);
        });
        
        // 拖拽结束事件
        item.addEventListener('dragend', function(e) {
            this.style.opacity = '1';
            draggedItem = null;
            console.log('结束拖拽图层');
        });
        
        // 拖拽经过事件
        item.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            return false;
        });
        
        // 拖拽进入事件
        item.addEventListener('dragenter', function(e) {
            e.preventDefault();
            if (draggedItem !== this) {
                this.style.backgroundColor = '#f0f8ff';
            }
        });
        
        // 拖拽离开事件
        item.addEventListener('dragleave', function(e) {
            this.style.backgroundColor = '';
        });
        
        // 拖拽放下事件
        item.addEventListener('drop', function(e) {
            e.preventDefault();
            this.style.backgroundColor = '';
            
            if (draggedItem !== this) {
                const layerList = document.getElementById('layer-list');
                const children = Array.from(layerList.children);
                const draggedIndex = children.indexOf(draggedItem);
                const dropIndex = children.indexOf(this);
                
                console.log('拖拽图层从索引', draggedIndex, '到索引', dropIndex);
                
                // 调整图层顺序
                if (draggedIndex < dropIndex) {
                    layerList.insertBefore(draggedItem, this.nextSibling);
                } else {
                    layerList.insertBefore(draggedItem, this);
                }
                
                // 更新图层视觉顺序
                updateLayerVisualOrder();
                
                console.log('图层顺序已更新');
            }
        });
    });
    
    // 添加按ESC键退出涂鸦模式的功能
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isDoodleLayerActive) {
            console.log('按ESC键退出涂鸦模式');
            
            // 重置图层选中状态
            document.querySelectorAll('.layer-item').forEach(layer => {
                layer.classList.remove('selected');
                layer.classList.remove('doodle-active');
                layer.classList.remove('locked');
                layer.style.pointerEvents = 'auto';
                layer.style.opacity = '1';
            });
            
            // 隐藏涂鸦工具栏
            const doodleSettings = document.getElementById('doodle-settings');
            if (doodleSettings) {
                doodleSettings.style.display = 'none';
            }
            
            // 禁用涂鸦画布
            toggleDoodleLayer(false);
            
            // 解锁所有图层
            isDoodleLayerActive = false;
            
            // 取消选中状态
            selectedElement = null;
            updateElementsTransform();
        }
    });
    
    // 添加点击画布空白区域退出涂鸦模式的功能
    const coverCard = document.getElementById('cover-card');
    if (coverCard) {
        coverCard.addEventListener('click', function(e) {
            // 检查是否点击的是画布空白区域
            if (isDoodleLayerActive && e.target === coverCard) {
                console.log('点击画布空白区域退出涂鸦模式');
                
                // 重置图层选中状态
                document.querySelectorAll('.layer-item').forEach(layer => {
                    layer.classList.remove('selected');
                    layer.classList.remove('doodle-active');
                    layer.classList.remove('locked');
                    layer.style.pointerEvents = 'auto';
                    layer.style.opacity = '1';
                });
                
                // 隐藏涂鸦工具栏
                const doodleSettings = document.getElementById('doodle-settings');
                if (doodleSettings) {
                    doodleSettings.style.display = 'none';
                }
                
                // 禁用涂鸦画布
                toggleDoodleLayer(false);
                
                // 解锁所有图层
                isDoodleLayerActive = false;
                
                // 取消选中状态
                selectedElement = null;
                updateElementsTransform();
            }
        });
    }
    
    // 图层可见性控制
    const layerVisibilityElements = document.querySelectorAll('.layer-visibility');
    layerVisibilityElements.forEach(element => {
        element.addEventListener('click', function(e) {
            e.stopPropagation();
            const layerItem = this.closest('.layer-item');
            const layerType = layerItem.dataset.layer;
            
            // 切换可见性状态
            this.classList.toggle('hidden');
            
            // 获取对应元素
            let targetElement;
            switch (layerType) {
                case 'title':
                    targetElement = document.getElementById('title-container');
                    break;
                case 'subtitle':
                    targetElement = document.getElementById('subtitle-container');
                    break;
                case 'description':
                    targetElement = document.getElementById('description-container');
                    break;
                case 'image':
                    targetElement = document.getElementById('image-container');
                    break;
                case 'doodle':
                    targetElement = document.getElementById('doodle-canvas');
                    break;
                default:
                    return;
            }
            
            // 切换元素可见性
            if (targetElement) {
                if (this.classList.contains('hidden')) {
                    targetElement.style.display = 'none';
                    this.textContent = '❌';
                } else {
                    if (layerType === 'image') {
                        // 图片容器只有在有图片时才显示
                        const coverImage = document.getElementById('cover-image');
                        if (coverImage && coverImage.src) {
                            targetElement.style.display = 'block';
                        }
                    } else if (layerType === 'doodle') {
                        targetElement.style.display = 'block';
                        // 重新绘制画布内容，确保显示后内容可见
                        redrawCanvas();
                        // 强制浏览器重绘，解决显示问题
                        setTimeout(() => {
                            targetElement.style.display = 'none';
                            void targetElement.offsetWidth;
                            targetElement.style.display = 'block';
                            redrawCanvas();
                        }, 10);
                        setTimeout(() => {
                            redrawCanvas();
                        }, 50);
                    } else {
                        targetElement.style.display = 'inline-block';
                    }
                    this.textContent = '👁️';
                }
            }
            
            console.log('切换图层可见性:', layerType, !this.classList.contains('hidden'));
        });
    });
    
    // 文档选择和加载
    const documentUploadBtn = document.getElementById('load-document-btn');
    const documentUploadInput = document.getElementById('document-upload');
    
    // 点击按钮触发文件选择对话框
    if (documentUploadBtn && documentUploadInput) {
        documentUploadBtn.addEventListener('click', () => {
            documentUploadInput.click();
        });
        
        // 文件选择后自动加载文档
    documentUploadInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const content = e.target.result;
                console.log('文档内容加载完成:', content.substring(0, 100) + '...');
                // 解析文档内容并生成卡片
                parseDocumentContent(content);
            };
            reader.readAsText(file);
        }
    });
    }
    
    // 卡片类型切换
    const coverCardBtn = document.getElementById('cover-card-btn');
    const contentCardBtn = document.getElementById('content-card-btn');
    
    if (coverCardBtn) {
        coverCardBtn.addEventListener('click', () => {
            console.log('点击封面卡片按钮');
            switchCardType('cover');
        });
    }
    
    if (contentCardBtn) {
        contentCardBtn.addEventListener('click', () => {
            console.log('点击内容卡片按钮');
            switchCardType('content');
        });
    }
    
    // 分页控制
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const jumpPageBtn = document.getElementById('jump-page-btn');
    
    if (prevPageBtn) {
        prevPageBtn.addEventListener('click', () => {
            console.log('点击上一页按钮');
            if (currentPage > 1) {
                currentPage--;
                updatePageInfo();
                loadCurrentPageData();
                updatePreview();
            }
        });
    }
    
    if (nextPageBtn) {
        nextPageBtn.addEventListener('click', () => {
            console.log('点击下一页按钮');
            if (currentPage < totalPages) {
                currentPage++;
                updatePageInfo();
                loadCurrentPageData();
                updatePreview();
            }
        });
    }
    
    if (jumpPageBtn) {
        jumpPageBtn.addEventListener('click', () => {
            console.log('点击跳转按钮');
            const pageInput = document.getElementById('page-input');
            if (pageInput) {
                const pageNum = parseInt(pageInput.value);
                if (pageNum >= 1 && pageNum <= totalPages) {
                    currentPage = pageNum;
                    updatePageInfo();
                    loadCurrentPageData();
                    updatePreview();
                }
            }
        });
    }
    
    // 内容编辑
    const coverMainTitle = document.getElementById('cover-main-title');
    const coverSubTitle = document.getElementById('cover-sub-title');
    const coverDescription = document.getElementById('cover-description');
    const coverMainTitleColor = document.getElementById('cover-main-title-color');
    const coverSubTitleColor = document.getElementById('cover-sub-title-color');
    const coverDescriptionColor = document.getElementById('cover-description-color');
    
    if (coverMainTitle) {
        coverMainTitle.addEventListener('input', updatePreview);
    }
    
    if (coverSubTitle) {
        coverSubTitle.addEventListener('input', updatePreview);
    }
    
    if (coverDescription) {
        coverDescription.addEventListener('input', updatePreview);
    }
    
    if (coverMainTitleColor) {
        coverMainTitleColor.addEventListener('input', function() {
            // 更新textElementStates
            textElementStates.title.color = this.value;
            updatePreview();
        });
    }
    
    if (coverSubTitleColor) {
        coverSubTitleColor.addEventListener('input', function() {
            // 更新textElementStates
            textElementStates.subtitle.color = this.value;
            updatePreview();
        });
    }
    
    if (coverDescriptionColor) {
        coverDescriptionColor.addEventListener('input', function() {
            // 更新textElementStates
            textElementStates.description.color = this.value;
            updatePreview();
        });
    }
    
    // 封面卡片文字大小设置
    const coverMainTitleSize = document.getElementById('cover-main-title-size');
    const coverSubTitleSize = document.getElementById('cover-sub-title-size');
    const coverDescriptionSize = document.getElementById('cover-description-size');
    
    if (coverMainTitleSize) {
        coverMainTitleSize.addEventListener('input', function() {
            const sizeValue = document.getElementById('cover-main-title-size-value');
            if (sizeValue) {
                sizeValue.textContent = this.value + 'px';
            }
            // 更新textElementStates
            textElementStates.title.size = parseInt(this.value);
            updatePreview();
        });
    }
    
    if (coverSubTitleSize) {
        coverSubTitleSize.addEventListener('input', function() {
            const sizeValue = document.getElementById('cover-sub-title-size-value');
            if (sizeValue) {
                sizeValue.textContent = this.value + 'px';
            }
            // 更新textElementStates
            textElementStates.subtitle.size = parseInt(this.value);
            updatePreview();
        });
    }
    
    if (coverDescriptionSize) {
        coverDescriptionSize.addEventListener('input', function() {
            const sizeValue = document.getElementById('cover-description-size-value');
            if (sizeValue) {
                sizeValue.textContent = this.value + 'px';
            }
            // 更新textElementStates
            textElementStates.description.size = parseInt(this.value);
            updatePreview();
        });
    }
    
    // 封面文字字体选择
    const coverMainTitleFont = document.getElementById('cover-main-title-font');
    const coverSubTitleFont = document.getElementById('cover-sub-title-font');
    const coverDescriptionFont = document.getElementById('cover-description-font');
    
    if (coverMainTitleFont) {
        coverMainTitleFont.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.title.font = this.value;
            updatePreview();
        });
    }
    
    if (coverSubTitleFont) {
        coverSubTitleFont.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.subtitle.font = this.value;
            updatePreview();
        });
    }
    
    if (coverDescriptionFont) {
        coverDescriptionFont.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.description.font = this.value;
            updatePreview();
        });
    }
    
    // 封面文字加粗设置
    const coverMainTitleBold = document.getElementById('cover-main-title-bold');
    const coverSubTitleBold = document.getElementById('cover-sub-title-bold');
    const coverDescriptionBold = document.getElementById('cover-description-bold');
    
    if (coverMainTitleBold) {
        coverMainTitleBold.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.title.bold = this.checked;
            updatePreview();
        });
    }
    
    if (coverSubTitleBold) {
        coverSubTitleBold.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.subtitle.bold = this.checked;
            updatePreview();
        });
    }
    
    if (coverDescriptionBold) {
        coverDescriptionBold.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.description.bold = this.checked;
            updatePreview();
        });
    }
    
    // 封面文字对齐方式设置
    const coverMainTitleAlign = document.getElementById('cover-main-title-align');
    const coverSubTitleAlign = document.getElementById('cover-sub-title-align');
    const coverDescriptionAlign = document.getElementById('cover-description-align');
    
    if (coverMainTitleAlign) {
        coverMainTitleAlign.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.title.alignment = this.value;
            updatePreview();
        });
    }
    
    if (coverSubTitleAlign) {
        coverSubTitleAlign.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.subtitle.alignment = this.value;
            updatePreview();
        });
    }
    
    if (coverDescriptionAlign) {
        coverDescriptionAlign.addEventListener('change', function() {
            // 更新textElementStates
            textElementStates.description.alignment = this.value;
            updatePreview();
        });
    }
    
    // 封面文字行间距设置
    const coverMainTitleLineHeight = document.getElementById('cover-main-title-line-height');
    const coverSubTitleLineHeight = document.getElementById('cover-sub-title-line-height');
    const coverDescriptionLineHeight = document.getElementById('cover-description-line-height');
    
    if (coverMainTitleLineHeight) {
        coverMainTitleLineHeight.addEventListener('input', function() {
            const lineHeightValue = document.getElementById('cover-main-title-line-height-value');
            if (lineHeightValue) {
                lineHeightValue.textContent = this.value;
            }
            // 更新textElementStates
            textElementStates.title.lineHeight = parseFloat(this.value);
            updatePreview();
        });
    }
    
    if (coverSubTitleLineHeight) {
        coverSubTitleLineHeight.addEventListener('input', function() {
            const lineHeightValue = document.getElementById('cover-sub-title-line-height-value');
            if (lineHeightValue) {
                lineHeightValue.textContent = this.value;
            }
            // 更新textElementStates
            textElementStates.subtitle.lineHeight = parseFloat(this.value);
            updatePreview();
        });
    }
    
    if (coverDescriptionLineHeight) {
        coverDescriptionLineHeight.addEventListener('input', function() {
            const lineHeightValue = document.getElementById('cover-description-line-height-value');
            if (lineHeightValue) {
                lineHeightValue.textContent = this.value;
            }
            // 更新textElementStates
            textElementStates.description.lineHeight = parseFloat(this.value);
            updatePreview();
        });
    }
    
    // 文本编辑器事件监听器
    if (textInput) {
        textInput.addEventListener('input', function() {
            updateSelectedElement();
        });
    }
    
    if (textColor) {
        textColor.addEventListener('input', function() {
            updateSelectedElement();
        });
    }
    
    if (textBold) {
        textBold.addEventListener('change', function() {
            updateSelectedElement();
        });
    }
    
    if (textSize) {
        textSize.addEventListener('input', function() {
            const textSizeValue = document.getElementById('text-size-value');
            if (textSizeValue) {
                textSizeValue.textContent = this.value + 'px';
            }
            updateSelectedElement();
        });
    }
    
    if (textFont) {
        textFont.addEventListener('change', function() {
            updateSelectedElement();
        });
    }
    
    if (textLineHeight) {
        textLineHeight.addEventListener('input', function() {
            const textLineHeightValue = document.getElementById('text-line-height-value');
            if (textLineHeightValue) {
                textLineHeightValue.textContent = this.value;
            }
            updateSelectedElement();
        });
    }
    
    if (textAlignment) {
        textAlignment.addEventListener('change', function() {
            updateSelectedElement();
        });
    }
    
    // 自动换行复选框事件监听
    const textAutoWrap = document.getElementById('text-auto-wrap');
    if (textAutoWrap) {
        textAutoWrap.addEventListener('change', function() {
            updateSelectedElement();
            // 无论自动换行状态如何，都调整容器宽度
            adjustAllTextContainerWidths();
        });
    }
    
    // 内容编辑
    const cardTitle = document.getElementById('card-title');
    const cardContent = document.getElementById('card-content');
    
    if (cardTitle) {
        cardTitle.addEventListener('input', updatePreview);
    }
    
    if (cardContent) {
        cardContent.addEventListener('input', updatePreview);
    }

    // 内容卡片文字设置
    const titleFontSize = document.getElementById('title-font-size');
    const titleFontWeight = document.getElementById('title-font-weight');
    const titleFontColor = document.getElementById('title-font-color');
    const titleTextAlign = document.getElementById('title-text-align');
    const contentLineHeight = document.getElementById('content-line-height');
    const contentFontSize = document.getElementById('content-font-size');
    const contentFontColor = document.getElementById('content-font-color');
    const textAlign = document.getElementById('text-align');
    const showTitleCheckbox = document.getElementById('show-title-checkbox');
    
    if (titleFontSize) {
        titleFontSize.addEventListener('input', function() {
            const sizeValue = document.getElementById('title-font-size-value');
            if (sizeValue) {
                sizeValue.textContent = this.value + 'px';
            }
            // 更新contentCardTextSettings
            contentCardTextSettings.title.fontSize = parseInt(this.value);
            updatePreview();
        });
    }
    
    if (titleFontWeight) {
        titleFontWeight.addEventListener('change', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.title.fontWeight = this.value;
            updatePreview();
        });
    }
    
    if (titleFontColor) {
        titleFontColor.addEventListener('input', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.title.fontColor = this.value;
            updatePreview();
        });
    }
    
    if (titleTextAlign) {
        titleTextAlign.addEventListener('change', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.title.textAlign = this.value;
            updatePreview();
        });
    }
    
    if (contentLineHeight) {
        contentLineHeight.addEventListener('input', function() {
            const lineHeightValue = document.getElementById('content-line-height-value');
            if (lineHeightValue) {
                lineHeightValue.textContent = this.value;
            }
            // 更新contentCardTextSettings
            contentCardTextSettings.content.lineHeight = parseFloat(this.value);
            updatePreview();
        });
    }
    
    if (contentFontSize) {
        contentFontSize.addEventListener('input', function() {
            const sizeValue = document.getElementById('content-font-size-value');
            if (sizeValue) {
                sizeValue.textContent = this.value + 'px';
            }
            // 更新contentCardTextSettings
            contentCardTextSettings.content.fontSize = parseInt(this.value);
            updatePreview();
        });
    }
    
    if (contentFontColor) {
        contentFontColor.addEventListener('input', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.content.fontColor = this.value;
            updatePreview();
        });
    }
    
    // 段落间距设置事件监听器
    const contentParagraphSpacing = document.getElementById('content-paragraph-spacing');
    if (contentParagraphSpacing) {
        contentParagraphSpacing.addEventListener('input', function() {
            const spacingValue = document.getElementById('content-paragraph-spacing-value');
            if (spacingValue) {
                spacingValue.textContent = this.value + 'px';
            }
            // 更新contentCardTextSettings
            contentCardTextSettings.content.paragraphSpacing = parseInt(this.value);
            updatePreview();
        });
    }
    
    if (textAlign) {
        textAlign.addEventListener('change', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.content.textAlign = this.value;
            updatePreview();
        });
    }
    
    if (showTitleCheckbox) {
        showTitleCheckbox.addEventListener('change', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.title.showTitle = this.checked;
            updatePreview();
        });
    }
    
    // 字体选择
    const fontFamily = document.getElementById('font-family');
    if (fontFamily) {
        fontFamily.addEventListener('change', function() {
            // 更新contentCardTextSettings
            contentCardTextSettings.title.fontFamily = this.value;
            contentCardTextSettings.content.fontFamily = this.value;
            updatePreview();
        });
    }
    
    // 视觉样式设置
    const borderWidth = document.getElementById('border-width');
    const borderColor = document.getElementById('border-color');
    const cardRadius = document.getElementById('card-radius');
    
    if (borderWidth) {
        borderWidth.addEventListener('input', function() {
            cardStyleSettings[currentCardType].borderWidth = parseInt(this.value);
            const widthValue = document.getElementById('border-width-value');
            if (widthValue) {
                widthValue.textContent = this.value + 'px';
            }
            updatePreview();
        });
    }
    
    if (borderColor) {
        borderColor.addEventListener('input', function() {
            cardStyleSettings[currentCardType].borderColor = this.value;
            updatePreview();
        });
    }
    
    if (cardRadius) {
        cardRadius.addEventListener('input', function() {
            cardStyleSettings[currentCardType].borderRadius = parseInt(this.value);
            const radiusValue = document.getElementById('card-radius-value');
            if (radiusValue) {
                radiusValue.textContent = this.value + 'px';
            }
            updatePreview();
        });
    }
    
    // 渐变背景事件监听
    const gradientType = document.getElementById('gradient-type');
    const gradientAngle = document.getElementById('gradient-angle');
    const gradientColor1 = document.getElementById('gradient-color-1');
    const gradientColor2 = document.getElementById('gradient-color-2');
    
    if (gradientType) {
        gradientType.addEventListener('change', function() {
            gradientSettings[currentCardType].type = this.value;
            updatePreview();
        });
    }
    
    if (gradientAngle) {
        gradientAngle.addEventListener('input', function() {
            gradientSettings[currentCardType].angle = parseInt(this.value);
            const angleValue = document.getElementById('gradient-angle-value');
            if (angleValue) {
                angleValue.textContent = this.value + '°';
            }
            updatePreview();
        });
    }
    
    if (gradientColor1) {
        gradientColor1.addEventListener('input', function() {
            gradientSettings[currentCardType].color1 = this.value;
            updatePreview();
        });
    }
    
    if (gradientColor2) {
        gradientColor2.addEventListener('input', function() {
            gradientSettings[currentCardType].color2 = this.value;
            updatePreview();
        });
    }
    
    // 配色方案
    const colorSchemesElements = document.querySelectorAll('#color-schemes .color-scheme');
    colorSchemesElements.forEach(scheme => {
        scheme.addEventListener('click', function() {
            document.querySelectorAll('#color-schemes .color-scheme').forEach(s => s.classList.remove('active'));
            this.classList.add('active');
            const schemeName = this.dataset.scheme;
            // 保存当前卡片类型的配色方案
            currentColorSchemes[currentCardType] = schemeName;
            applyColorScheme(schemeName, currentCardType);
        });
    });
    
    // 下载功能
    const downloadCurrentBtn = document.getElementById('download-current-btn');
    if (downloadCurrentBtn) {
        downloadCurrentBtn.addEventListener('click', downloadCurrentCard);
    }
    
    const batchDownloadBtn = document.getElementById('batch-download-btn');
    if (batchDownloadBtn) {
        batchDownloadBtn.addEventListener('click', batchDownloadCards);
    }
    
    // 配置导入导出功能
    const importConfigBtn = document.getElementById('import-config-btn');
    const exportConfigBtn = document.getElementById('export-config-btn');
    const configUpload = document.getElementById('config-upload');
    
    if (importConfigBtn) {
        importConfigBtn.addEventListener('click', importConfig);
    }
    
    if (exportConfigBtn) {
        exportConfigBtn.addEventListener('click', exportConfig);
    }
    
    if (configUpload) {
        configUpload.addEventListener('change', handleConfigFileSelect);
    }
    
    // 封面背景图片设置
    const coverBackgroundImageUploadBtn = document.getElementById('load-cover-background-image-btn');
    const coverBackgroundImageUploadInput = document.getElementById('cover-background-image-upload');
    console.log('绑定封面背景图片上传事件监听器:', coverBackgroundImageUploadBtn, coverBackgroundImageUploadInput);
    if (coverBackgroundImageUploadBtn && coverBackgroundImageUploadInput) {
        // 点击按钮触发文件选择对话框
        coverBackgroundImageUploadBtn.addEventListener('click', () => {
            console.log('点击封面背景图片按钮');
            coverBackgroundImageUploadInput.click();
        });
        
        // 文件选择后加载封面背景图片
        coverBackgroundImageUploadInput.addEventListener('change', function() {
            console.log('选择封面背景图片文件:', this.files);
            loadBackgroundImage(this, 'cover');
        });
    }
    
    // 使用封面背景图片复选框
    const useCoverBackgroundImageCheckbox = document.getElementById('use-cover-background-image-checkbox');
    if (useCoverBackgroundImageCheckbox) {
        useCoverBackgroundImageCheckbox.addEventListener('change', function() {
            backgroundImageData.cover.useImage = this.checked;
            updatePreview();
        });
    }
    
    // 封面背景图片透明度滑块
    const coverBackgroundImageOpacity = document.getElementById('cover-background-image-opacity');
    if (coverBackgroundImageOpacity) {
        coverBackgroundImageOpacity.addEventListener('input', function() {
            backgroundImageData.cover.opacity = parseInt(this.value);
            const opacityValue = document.getElementById('cover-background-image-opacity-value');
            if (opacityValue) {
                opacityValue.textContent = this.value + '%';
            }
            updatePreview();
        });
    }
    
    // 内容背景图片设置
    const contentBackgroundImageUploadBtn = document.getElementById('load-content-background-image-btn');
    const contentBackgroundImageUploadInput = document.getElementById('content-background-image-upload');
    console.log('绑定内容背景图片上传事件监听器:', contentBackgroundImageUploadBtn, contentBackgroundImageUploadInput);
    if (contentBackgroundImageUploadBtn && contentBackgroundImageUploadInput) {
        // 点击按钮触发文件选择对话框
        contentBackgroundImageUploadBtn.addEventListener('click', () => {
            console.log('点击内容背景图片按钮');
            contentBackgroundImageUploadInput.click();
        });
        
        // 文件选择后加载内容背景图片
        contentBackgroundImageUploadInput.addEventListener('change', function() {
            console.log('选择内容背景图片文件:', this.files);
            loadBackgroundImage(this, 'content');
        });
    }
    
    // 使用内容背景图片复选框
    const useContentBackgroundImageCheckbox = document.getElementById('use-content-background-image-checkbox');
    if (useContentBackgroundImageCheckbox) {
        useContentBackgroundImageCheckbox.addEventListener('change', function() {
            backgroundImageData.content.useImage = this.checked;
            updatePreview();
        });
    }
    
    // 内容背景图片透明度滑块
    const contentBackgroundImageOpacity = document.getElementById('content-background-image-opacity');
    if (contentBackgroundImageOpacity) {
        contentBackgroundImageOpacity.addEventListener('input', function() {
            backgroundImageData.content.opacity = parseInt(this.value);
            const opacityValue = document.getElementById('content-background-image-opacity-value');
            if (opacityValue) {
                opacityValue.textContent = this.value + '%';
            }
            updatePreview();
        });
    }
    
    // 封面图片上传功能
    const coverImageUploadBtn = document.getElementById('load-cover-image-btn');
    const coverImageUploadInput = document.getElementById('cover-image-upload');
    console.log('绑定封面图片上传事件监听器:', coverImageUploadBtn, coverImageUploadInput);
    if (coverImageUploadBtn && coverImageUploadInput) {
        // 点击按钮触发文件选择对话框
        coverImageUploadBtn.addEventListener('click', () => {
            console.log('点击选择图片按钮');
            coverImageUploadInput.click();
        });
        
        // 使用容差值判断黑色像素并设置透明效果
        function removeBlackBackground(imageSrc, callback) {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const img = new Image();
            img.crossOrigin = 'anonymous';
            
            img.onload = function() {
                canvas.width = img.width;
                canvas.height = img.height;
                
                // 绘制图片
                ctx.drawImage(img, 0, 0);
                
                // 获取图片数据
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imageData.data;
                
                // 获取容差值
                const blackToleranceSlider = document.getElementById('black-tolerance');
                const tolerance = blackToleranceSlider ? parseInt(blackToleranceSlider.value) : 0;
                
                // 处理每个像素，根据容差值判断黑色像素
                for (let i = 0; i < data.length; i += 4) {
                    const r = data[i];
                    const g = data[i + 1];
                    const b = data[i + 2];
                    
                    // 判断是否为黑色（RGB值都小于等于容差值）
                    if (r <= tolerance && g <= tolerance && b <= tolerance) {
                        // 黑色像素设为完全透明
                        data[i + 3] = 0;
                    } else {
                        // 非黑色像素设为完全不透明
                        data[i + 3] = 255;
                    }
                }
                
                // 放回到canvas
                ctx.putImageData(imageData, 0, 0);
                
                // 转换为base64
                const transparentImageSrc = canvas.toDataURL('image/png');
                callback(transparentImageSrc);
            };
            
            img.onerror = function() {
                console.error('图片加载失败');
                callback(imageSrc); // 失败时返回原图
            };
            
            img.src = imageSrc;
        }

        // 保存原始图片数据
        let originalImageSrc = null;

        // 为容差值滑块添加事件监听器
        const blackToleranceSlider = document.getElementById('black-tolerance');
        const blackToleranceValue = document.getElementById('black-tolerance-value');
        if (blackToleranceSlider && blackToleranceValue) {
            blackToleranceSlider.addEventListener('input', function() {
                blackToleranceValue.textContent = this.value;
                
                // 当容差值变化时，如果透明黑底功能已开启，重新处理图片
                const transparentBlackBgCheckbox = document.getElementById('transparent-black-bg-checkbox');
                const coverImage = document.getElementById('cover-image');
                const imageContainer = document.getElementById('image-container');
                
                if (transparentBlackBgCheckbox && transparentBlackBgCheckbox.checked && coverImage && imageContainer && originalImageSrc) {
                    removeBlackBackground(originalImageSrc, function(processedImageSrc) {
                        coverImage.src = processedImageSrc;
                    });
                }
            });
        }

        // 为透明黑底复选框添加点击事件监听器
        const transparentBlackBgCheckbox = document.getElementById('transparent-black-bg-checkbox');
        if (transparentBlackBgCheckbox) {
            transparentBlackBgCheckbox.addEventListener('change', function() {
                const coverImage = document.getElementById('cover-image');
                const imageContainer = document.getElementById('image-container');
                
                if (coverImage && imageContainer && originalImageSrc) {
                    if (this.checked) {
                        // 开启透明效果
                        console.log('开启透明黑底效果');
                        removeBlackBackground(originalImageSrc, function(processedImageSrc) {
                            coverImage.src = processedImageSrc;
                        });
                    } else {
                        // 关闭透明效果，恢复原图
                        console.log('关闭透明黑底效果，恢复原图');
                        coverImage.src = originalImageSrc;
                    }
                }
            });
        }

        // 文件选择后加载图片
        coverImageUploadInput.addEventListener('change', function(e) {
            console.log('选择图片文件:', e.target.files);
            const file = e.target.files[0];
            if (file) {
                console.log('开始加载图片:', file.name);
                const reader = new FileReader();
                reader.onload = function(e) {
                    console.log('图片加载完成:', e.target.result.substring(0, 50) + '...');
                    const coverImage = document.getElementById('cover-image');
                    const imageContainer = document.getElementById('image-container');
                    const transparentBlackBgCheckbox = document.getElementById('transparent-black-bg-checkbox');
                    console.log('获取图片元素:', coverImage, imageContainer);
                    if (coverImage && imageContainer) {
                        // 保存原始图片数据
                        originalImageSrc = e.target.result;
                        
                        // 保存当前文字元素的位置状态
                        const titleTransform = {...coverElementsTransform.title};
                        const subtitleTransform = {...coverElementsTransform.subtitle};
                        const descriptionTransform = {...coverElementsTransform.description};
                        
                        // 重置图片变换状态
                        coverElementsTransform.image = {
                            x: 0,
                            y: 0,
                            rotate: 0,
                            scale: 1
                        };
                        
                        // 设置图片容器为绝对定位，避免影响其他元素布局
                        imageContainer.style.position = 'absolute';
                        // 设置初始位置，避免图片出现在奇怪的地方
                        imageContainer.style.left = '50%';
                        imageContainer.style.top = '50%';
                        imageContainer.style.transform = 'translate(-50%, -50%)';
                        
                        // 检查是否需要透明黑底处理
                        if (transparentBlackBgCheckbox && transparentBlackBgCheckbox.checked) {
                            console.log('应用透明黑底处理');
                            removeBlackBackground(originalImageSrc, function(processedImageSrc) {
                                coverImage.src = processedImageSrc;
                                imageContainer.style.display = 'block';
                                
                                // 恢复文字元素的位置状态
                                coverElementsTransform.title = titleTransform;
                                coverElementsTransform.subtitle = subtitleTransform;
                                coverElementsTransform.description = descriptionTransform;
                                
                                selectedElement = 'image';
                                // 调用updateElementsTransform()应用变换
                                updateElementsTransform();
                                console.log('图片显示完成，选中图片元素');
                            });
                        } else {
                            // 直接显示原图
                            coverImage.src = originalImageSrc;
                            imageContainer.style.display = 'block';
                            
                            // 恢复文字元素的位置状态
                            coverElementsTransform.title = titleTransform;
                            coverElementsTransform.subtitle = subtitleTransform;
                            coverElementsTransform.description = descriptionTransform;
                            
                            selectedElement = 'image';
                            // 调用updateElementsTransform()应用变换
                            updateElementsTransform();
                            console.log('图片显示完成，选中图片元素');
                        }
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // 封面元素交互功能
    const titleContainer = document.getElementById('title-container');
    const subtitleContainer = document.getElementById('subtitle-container');
    const descriptionContainer = document.getElementById('description-container');
    const imageContainer = document.getElementById('image-container');
    const titleRotateHandle = document.getElementById('title-rotate-handle');
    const subtitleRotateHandle = document.getElementById('subtitle-rotate-handle');
    const descriptionRotateHandle = document.getElementById('description-rotate-handle');
    const imageRotateHandle = document.getElementById('image-rotate-handle');
    
    if (titleContainer && subtitleContainer && descriptionContainer) {
        // 移除所有图层元素的默认点击事件，统一由全局点击事件处理
        // 这样可以确保点击时按照图层的z-index顺序进行选择
        
        // 为文字元素本身添加点击事件监听器，确保可以直接点击文字选中
        const previewCoverTitle = document.getElementById('preview-cover-title');
        const previewCoverSubtitle = document.getElementById('preview-cover-subtitle');
        const previewCoverDescription = document.getElementById('preview-cover-description');
        
        // 移除默认的点击事件监听器，避免冲突
        if (previewCoverTitle) {
            // 移除现有的点击事件监听器
            const newTitle = previewCoverTitle.cloneNode(true);
            previewCoverTitle.parentNode.replaceChild(newTitle, previewCoverTitle);
        }
        
        if (previewCoverSubtitle) {
            // 移除现有的点击事件监听器
            const newSubtitle = previewCoverSubtitle.cloneNode(true);
            previewCoverSubtitle.parentNode.replaceChild(newSubtitle, previewCoverSubtitle);
        }
        
        if (previewCoverDescription) {
            // 移除现有的点击事件监听器
            const newDescription = previewCoverDescription.cloneNode(true);
            previewCoverDescription.parentNode.replaceChild(newDescription, previewCoverDescription);
        }
        
        // 保留图片容器的事件监听器，只移除点击事件监听器
        if (imageContainer) {
            // 移除点击事件监听器，但保留拖拽、缩放和旋转事件监听器
            const originalOnClick = imageContainer.onclick;
            imageContainer.onclick = null;
            
            // 重新添加鼠标按下事件监听器，确保图片可以正常拖拽
            imageContainer.addEventListener('mousedown', function(e) {
                // 涂鸦层激活时不处理其他图层的拖拽
                if (isDoodleLayerActive) {
                    console.log('涂鸦层激活，忽略图片容器拖拽');
                    return;
                }
                
                // 检查是否点击的是旋转控制点
                const imageRotateHandle = document.getElementById('image-rotate-handle');
                if (imageRotateHandle && imageRotateHandle.contains(e.target)) {
                    e.stopPropagation(); // 防止触发拖拽
                    isRotating = true;
                    activeElement = 'image';
                    selectedElement = 'image';
                    
                    // 计算初始角度
                    const containerRect = imageContainer.getBoundingClientRect();
                    const centerX = containerRect.left + containerRect.width / 2;
                    const centerY = containerRect.top + containerRect.height / 2;
                    
                    rotationStartAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI - coverElementsTransform.image.rotate;
                    return;
                }
                
                // 检查是否点击的是缩放控制点
                const resizeHandles = imageContainer.querySelectorAll('.resize-handle:not(.rotate-handle)');
                let isResizeHandle = false;
                let clickedHandle = null;
                resizeHandles.forEach(handle => {
                    if (handle.contains(e.target)) {
                        isResizeHandle = true;
                        clickedHandle = handle;
                    }
                });
                
                if (isResizeHandle && clickedHandle) {
                    e.stopPropagation(); // 防止触发拖拽
                    isScaling = true;
                    activeElement = 'image-scale';
                    selectedElement = 'image';
                    
                    const containerRect = imageContainer.getBoundingClientRect();
                    const centerX = containerRect.left + containerRect.width / 2;
                    const centerY = containerRect.top + containerRect.height / 2;
                    
                    // 计算初始距离
                    const initialDistance = Math.sqrt(
                        Math.pow(e.clientX - centerX, 2) + Math.pow(e.clientY - centerY, 2)
                    );
                    const initialScale = coverElementsTransform.image.scale;
                    
                    // 鼠标移动事件 - 缩放中
                    function handleMouseMove(e) {
                        if (isScaling && activeElement === 'image-scale') {
                            const newDistance = Math.sqrt(
                                Math.pow(e.clientX - centerX, 2) + Math.pow(e.clientY - centerY, 2)
                            );
                            const scaleFactor = newDistance / initialDistance;
                            coverElementsTransform.image.scale = Math.max(0.1, Math.min(5, initialScale * scaleFactor));
                            updateElementsTransform();
                        }
                    }
                    
                    // 鼠标释放事件 - 结束缩放
                    function handleMouseUp(e) {
                        if (isScaling && activeElement === 'image-scale') {
                            isScaling = false;
                            activeElement = null;
                        }
                        document.removeEventListener('mousemove', handleMouseMove);
                        document.removeEventListener('mouseup', handleMouseUp);
                    }
                    
                    // 添加临时事件监听器
                    document.addEventListener('mousemove', handleMouseMove);
                    document.addEventListener('mouseup', handleMouseUp);
                    return;
                }
                
                // 普通拖拽
                startDrag('image', e);
            });
        }
        
        // 统一的画布点击事件处理
        coverCard.addEventListener('click', function(e) {
            // 涂鸦层激活时不处理其他图层的点击
            if (isDoodleLayerActive) {
                console.log('涂鸦层激活，忽略画布点击');
                return;
            }
            
            // 检查是否点击的是画布空白区域
            if (e.target === coverCard) {
                console.log('点击画布空白区域，取消选择');
                selectedElement = null;
                updateElementsTransform();
                return;
            }
            
            // 按照图层在图层管理中的顺序（从上到下）检查点击位置
            // 获取图层列表中的所有图层项
            const layerList = document.getElementById('layer-list');
            const layerItems = layerList.querySelectorAll('.layer-item');
            
            // 按照图层管理中的顺序（从上到下）创建图层元素列表
            const layerElements = [];
            layerItems.forEach(item => {
                const layerType = item.dataset.layer;
                const element = document.getElementById(`${layerType}-container`) || document.getElementById('doodle-canvas');
                if (element) {
                    layerElements.push({ type: layerType, element: element });
                }
            });
            
            // 过滤掉不存在的元素
            const existingLayers = layerElements.filter(layer => layer.element !== null);
            
            console.log('图层检查顺序:', existingLayers.map(layer => layer.type));
            
            // 按照图层管理中的顺序（从上到下）检查点击位置
            // 这样当图层有重叠时，会优先选择图层管理中更往上的图层（视觉上更前面的图层）
            
            // 检查点击位置是否在某个图层元素内
            for (const layer of existingLayers) {
                if (layer.element && layer.element.contains(e.target)) {
                    console.log('点击位置在图层', layer.type, '内');
                    
                    // 选择该图层
                    selectedElement = layer.type;
                    
                    // 调整容器宽度，确保容器宽度正确
                    if (layer.type !== 'doodle' && layer.type !== 'image') {
                        adjustAllTextContainerWidths();
                    }
                    
                    updateElementsTransform();
                    // 更新图层管理选中状态
                    updateLayerSelection(layer.type);
                    // 更新文本编辑器内容和设置
                    if (layer.type !== 'doodle' && layer.type !== 'image') {
                        updateTextEditor(layer.type);
                    }
                    
                    // 阻止事件冒泡
                    e.stopPropagation();
                    return;
                }
            }
            
            // 如果没有点击到任何图层元素，取消选择
            console.log('点击位置不在任何图层元素内，取消选择');
            selectedElement = null;
            updateElementsTransform();
        });
        
        // 点击其他地方 - 取消选择
        document.addEventListener('click', function(e) {
            // 在事件触发时获取文本编辑器相关元素，确保即使DOM结构变化也能正确识别
            const unifiedTextControl = document.querySelector('.unified-text-control');
            
            // 检查点击的是否是文本编辑器相关元素
            const isTextEditorElement = unifiedTextControl && unifiedTextControl.contains(e.target);
            
            // 只有当不在拖拽或旋转状态，且点击的不是文本编辑器相关元素时才取消选择
            if (!isDragging && !isRotating &&
                !titleContainer.contains(e.target) && 
                !subtitleContainer.contains(e.target) && 
                !descriptionContainer.contains(e.target) &&
                !imageContainer.contains(e.target) &&
                !titleRotateHandle.contains(e.target) &&
                !subtitleRotateHandle.contains(e.target) &&
                !descriptionRotateHandle.contains(e.target) &&
                !imageRotateHandle.contains(e.target) &&
                !isTextEditorElement) {
                selectedElement = null;
                updateElementsTransform();
            }
        });
        
        // 鼠标按下事件 - 开始拖拽
        function startDrag(element, e) {
            isDragging = true;
            activeElement = element;
            selectedElement = element;
            dragStartX = e.clientX - coverElementsTransform[element].x;
            dragStartY = e.clientY - coverElementsTransform[element].y;
            
            // 更新鼠标样式
            if (element === 'title') {
                titleContainer.style.cursor = 'grabbing';
            } else if (element === 'subtitle') {
                subtitleContainer.style.cursor = 'grabbing';
            } else if (element === 'description') {
                descriptionContainer.style.cursor = 'grabbing';
            } else if (element === 'image') {
                imageContainer.style.cursor = 'grabbing';
            }
            
            updateElementsTransform();
        }
        
        titleContainer.addEventListener('mousedown', function(e) {
            // 涂鸦层激活时不处理其他图层的拖拽
            if (isDoodleLayerActive) {
                console.log('涂鸦层激活，忽略大标题容器拖拽');
                return;
            }
            startDrag('title', e);
        });
        
        subtitleContainer.addEventListener('mousedown', function(e) {
            // 涂鸦层激活时不处理其他图层的拖拽
            if (isDoodleLayerActive) {
                console.log('涂鸦层激活，忽略小标题容器拖拽');
                return;
            }
            // 如果点击的是旋转控制点，不开始拖拽
            if (e.target === subtitleRotateHandle) return;
            startDrag('subtitle', e);
        });
        
        descriptionContainer.addEventListener('mousedown', function(e) {
            // 涂鸦层激活时不处理其他图层的拖拽
            if (isDoodleLayerActive) {
                console.log('涂鸦层激活，忽略内容简介容器拖拽');
                return;
            }
            startDrag('description', e);
        });
        
        // 图片容器鼠标按下事件 - 开始拖拽
        if (imageContainer) {
            imageContainer.addEventListener('mousedown', function(e) {
                // 涂鸦层激活时不处理其他图层的拖拽
                if (isDoodleLayerActive) {
                    console.log('涂鸦层激活，忽略图片容器拖拽');
                    return;
                }
                startDrag('image', e);
            });
        }
        
        // 鼠标移动事件 - 拖拽中
        document.addEventListener('mousemove', function(e) {
            if (!isScaling && isDragging && selectedElement && activeElement === selectedElement) {
                // 标记进行了实际的拖拽操作
                hasDragged = true;
                coverElementsTransform[selectedElement].x = e.clientX - dragStartX;
                coverElementsTransform[selectedElement].y = e.clientY - dragStartY;
                updateElementsTransform();
            } else if (!isScaling && isRotating && selectedElement && activeElement === selectedElement) {
                // 标记进行了实际的旋转操作
                hasDragged = true;
                // 计算旋转角度
                let containerRect;
                if (selectedElement === 'title') {
                    containerRect = titleContainer.getBoundingClientRect();
                } else if (selectedElement === 'subtitle') {
                    containerRect = subtitleContainer.getBoundingClientRect();
                } else if (selectedElement === 'description') {
                    containerRect = descriptionContainer.getBoundingClientRect();
                } else if (selectedElement === 'image') {
                    containerRect = imageContainer.getBoundingClientRect();
                }
                
                if (containerRect) {
                    const centerX = containerRect.left + containerRect.width / 2;
                    const centerY = containerRect.top + containerRect.height / 2;
                    
                    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI;
                    coverElementsTransform[selectedElement].rotate = angle - rotationStartAngle;
                    updateElementsTransform();
                }
            }
        });
        
        // 鼠标释放事件 - 结束拖拽
        document.addEventListener('mouseup', function(e) {
            if (isDragging) {
                isDragging = false;
                
                // 恢复鼠标样式
                titleContainer.style.cursor = 'move';
                subtitleContainer.style.cursor = 'move';
                descriptionContainer.style.cursor = 'move';
                if (imageContainer) {
                    imageContainer.style.cursor = 'move';
                }
            }
            if (isRotating) {
                isRotating = false;
            }
            if (isScaling) {
                isScaling = false;
            }
            // 重置当前操作的元素
            activeElement = null;
            // 重置拖拽标志
            hasDragged = false;
            // 如果选中了任何元素，确保边界框保持显示
            if (selectedElement) {
                updateElementsTransform();
            }
        });
        
        // 旋转控制点鼠标按下事件 - 开始旋转
        const titleRotateHandle = document.getElementById('title-rotate-handle');
        const subtitleRotateHandle = document.getElementById('subtitle-rotate-handle');
        const descriptionRotateHandle = document.getElementById('description-rotate-handle');
        
        // 大标题旋转控制点
        if (titleRotateHandle) {
            titleRotateHandle.addEventListener('mousedown', function(e) {
                e.stopPropagation(); // 防止触发拖拽
                isRotating = true;
                activeElement = 'title';
                selectedElement = 'title';
                
                // 计算初始角度
                const containerRect = titleContainer.getBoundingClientRect();
                const centerX = containerRect.left + containerRect.width / 2;
                const centerY = containerRect.top + containerRect.height / 2;
                
                rotationStartAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI - coverElementsTransform.title.rotate;
            });
        }
        
        // 小标题旋转控制点
        if (subtitleRotateHandle) {
            subtitleRotateHandle.addEventListener('mousedown', function(e) {
                e.stopPropagation(); // 防止触发拖拽
                isRotating = true;
                activeElement = 'subtitle';
                selectedElement = 'subtitle';
                
                // 计算初始角度
                const containerRect = subtitleContainer.getBoundingClientRect();
                const centerX = containerRect.left + containerRect.width / 2;
                const centerY = containerRect.top + containerRect.height / 2;
                
                rotationStartAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI - coverElementsTransform.subtitle.rotate;
            });
        }
        
        // 简介旋转控制点
        if (descriptionRotateHandle) {
            descriptionRotateHandle.addEventListener('mousedown', function(e) {
                e.stopPropagation(); // 防止触发拖拽
                isRotating = true;
                activeElement = 'description';
                selectedElement = 'description';
                
                // 计算初始角度
                const containerRect = descriptionContainer.getBoundingClientRect();
                const centerX = containerRect.left + containerRect.width / 2;
                const centerY = containerRect.top + containerRect.height / 2;
                
                rotationStartAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI - coverElementsTransform.description.rotate;
            });
        }
        
        // 图片旋转控制点
        const imageRotateHandle = document.getElementById('image-rotate-handle');
        if (imageRotateHandle) {
            imageRotateHandle.addEventListener('mousedown', function(e) {
                e.stopPropagation(); // 防止触发拖拽
                isRotating = true;
                activeElement = 'image';
                selectedElement = 'image';
                
                // 计算初始角度
                const containerRect = imageContainer.getBoundingClientRect();
                const centerX = containerRect.left + containerRect.width / 2;
                const centerY = containerRect.top + containerRect.height / 2;
                
                rotationStartAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * 180 / Math.PI - coverElementsTransform.image.rotate;
            });
        }
        
        // 图片缩放控制点
        if (imageContainer) {
            const resizeHandles = imageContainer.querySelectorAll('.resize-handle:not(.rotate-handle)');
            resizeHandles.forEach(handle => {
                handle.addEventListener('mousedown', function(e) {
                    e.stopPropagation(); // 防止触发拖拽
                    isScaling = true;
                    activeElement = 'image-scale';
                    selectedElement = 'image';
                    
                    const containerRect = imageContainer.getBoundingClientRect();
                    const centerX = containerRect.left + containerRect.width / 2;
                    const centerY = containerRect.top + containerRect.height / 2;
                    
                    // 计算初始距离
                    const initialDistance = Math.sqrt(
                        Math.pow(e.clientX - centerX, 2) + Math.pow(e.clientY - centerY, 2)
                    );
                    const initialScale = coverElementsTransform.image.scale;
                    
                    // 鼠标移动事件 - 缩放中
                    function handleMouseMove(e) {
                        if (isScaling && activeElement === 'image-scale') {
                            const newDistance = Math.sqrt(
                                Math.pow(e.clientX - centerX, 2) + Math.pow(e.clientY - centerY, 2)
                            );
                            const scaleFactor = newDistance / initialDistance;
                            coverElementsTransform.image.scale = Math.max(0.1, Math.min(5, initialScale * scaleFactor));
                            updateElementsTransform();
                        }
                    }
                    
                    // 鼠标释放事件 - 结束缩放
                    function handleMouseUp(e) {
                        if (isScaling && activeElement === 'image-scale') {
                            isScaling = false;
                            activeElement = null;
                        }
                        document.removeEventListener('mousemove', handleMouseMove);
                        document.removeEventListener('mouseup', handleMouseUp);
                    }
                    
                    // 添加临时事件监听器
                    document.addEventListener('mousemove', handleMouseMove);
                    document.addEventListener('mouseup', handleMouseUp);
                });
            });
        }
        
        // 双击事件 - 重置变换
        function resetTransform(element) {
            if (element === 'title') {
                coverElementsTransform.title = {
                    x: 0,
                    y: 0,
                    rotate: 0
                };
            } else if (element === 'subtitle') {
                coverElementsTransform.subtitle = {
                    x: 0,
                    y: 0,
                    rotate: 0
                };
            } else if (element === 'description') {
                coverElementsTransform.description = {
                    x: 0,
                    y: 0,
                    rotate: 0
                };
            } else if (element === 'image') {
                coverElementsTransform.image = {
                    x: 0,
                    y: 0,
                    rotate: 0,
                    scale: 1
                };
            }
            updateElementsTransform();
        }
        
        subtitleContainer.addEventListener('dblclick', function(e) {
            e.stopPropagation();
            // 双击取消选择
            if (selectedElement === 'subtitle') {
                selectedElement = null;
                updateElementsTransform();
            }
        });
        
        // 图片容器双击事件 - 重置变换
        if (imageContainer) {
            imageContainer.addEventListener('dblclick', function(e) {
                e.stopPropagation();
                resetTransform('image');
            });
        }
    }
}

// 切换卡片类型
function switchCardType(type) {
    currentCardType = type;
    
    // 更新按钮状态
    const coverCardBtn = document.getElementById('cover-card-btn');
    const contentCardBtn = document.getElementById('content-card-btn');
    
    if (coverCardBtn && contentCardBtn) {
        if (type === 'cover') {
            coverCardBtn.classList.remove('btn-secondary');
            coverCardBtn.classList.add('btn-primary');
            contentCardBtn.classList.remove('btn-primary');
            contentCardBtn.classList.add('btn-secondary');
            
            // 显示封面卡片，隐藏内容卡片
            const coverCard = document.getElementById('cover-card');
            const contentCard = document.getElementById('content-card');
            
            if (coverCard) {
                coverCard.style.display = 'flex';
                
                // 确保涂鸦画布在封面卡片显示后也显示
                setTimeout(() => {
                    const doodleCanvas = document.getElementById('doodle-canvas');
                    if (doodleCanvas) {
                        // 检查涂鸦图层是否被用户手动隐藏
                        const doodleLayerItem = document.querySelector('.layer-item[data-layer="doodle"]');
                        const doodleVisibility = doodleLayerItem.querySelector('.layer-visibility');
                        if (!doodleVisibility || !doodleVisibility.classList.contains('hidden')) {
                            doodleCanvas.style.display = 'block';
                            // 重新计算图层顺序，确保涂鸦画布的z-index由图层管理系统控制
                            updateLayerVisualOrder();
                            // 重新绘制画布内容，确保切换卡片后内容可见
                            redrawCanvas();
                        }
                    }
                }, 100);
            }
            
            if (contentCard) {
                contentCard.style.display = 'none';
            }
            
            // 显示封面编辑区，隐藏内容编辑区
            const coverEditSection = document.getElementById('cover-edit-section');
            const contentEditSection = document.getElementById('content-edit-section');
            const paginationSection = document.getElementById('pagination-section');
            
            if (coverEditSection) {
                coverEditSection.style.display = 'block';
            }
            
            if (contentEditSection) {
                contentEditSection.style.display = 'none';
            }
            
            // 隐藏分页导航
            if (paginationSection) {
                paginationSection.style.display = 'none';
            }
        } else {
            contentCardBtn.classList.remove('btn-secondary');
            contentCardBtn.classList.add('btn-primary');
            coverCardBtn.classList.remove('btn-primary');
            coverCardBtn.classList.add('btn-secondary');
            
            // 显示内容卡片，隐藏封面卡片
            const coverCard = document.getElementById('cover-card');
            const contentCard = document.getElementById('content-card');
            
            if (contentCard) {
                contentCard.style.display = 'flex';
            }
            
            if (coverCard) {
                coverCard.style.display = 'none';
            }
            
            // 显示内容编辑区，隐藏封面编辑区
            const contentEditSection = document.getElementById('content-edit-section');
            const coverEditSection = document.getElementById('cover-edit-section');
            const paginationSection = document.getElementById('pagination-section');
            
            if (contentEditSection) {
                contentEditSection.style.display = 'block';
            }
            
            if (coverEditSection) {
                coverEditSection.style.display = 'none';
            }
            
            // 显示分页导航
            if (paginationSection) {
                paginationSection.style.display = 'block';
            }
        }
    }
    
    // 更新配色方案区域的激活状态
    updateColorSchemeSelection();
    
    // 更新UI上的渐变背景设置，显示当前卡片类型的设置
    const gradientType = document.getElementById('gradient-type');
    const gradientAngle = document.getElementById('gradient-angle');
    const gradientAngleValue = document.getElementById('gradient-angle-value');
    const gradientColor1 = document.getElementById('gradient-color-1');
    const gradientColor2 = document.getElementById('gradient-color-2');
    
    if (gradientType) {
        gradientType.value = gradientSettings[currentCardType].type;
    }
    if (gradientAngle) {
        gradientAngle.value = gradientSettings[currentCardType].angle;
    }
    if (gradientAngleValue) {
        gradientAngleValue.textContent = gradientSettings[currentCardType].angle + '°';
    }
    if (gradientColor1) {
        gradientColor1.value = gradientSettings[currentCardType].color1;
    }
    if (gradientColor2) {
        gradientColor2.value = gradientSettings[currentCardType].color2;
    }
    
    // 更新UI上的卡片样式设置，显示当前卡片类型的设置
    const borderWidth = document.getElementById('border-width');
    const borderWidthValue = document.getElementById('border-width-value');
    const borderColor = document.getElementById('border-color');
    const cardRadius = document.getElementById('card-radius');
    const cardRadiusValue = document.getElementById('card-radius-value');
    
    if (borderWidth) {
        borderWidth.value = cardStyleSettings[currentCardType].borderWidth;
    }
    if (borderWidthValue) {
        borderWidthValue.textContent = cardStyleSettings[currentCardType].borderWidth + 'px';
    }
    if (borderColor) {
        borderColor.value = cardStyleSettings[currentCardType].borderColor;
    }
    if (cardRadius) {
        cardRadius.value = cardStyleSettings[currentCardType].borderRadius;
    }
    if (cardRadiusValue) {
        cardRadiusValue.textContent = cardStyleSettings[currentCardType].borderRadius + 'px';
    }
    
    // 加载当前页面数据
    loadCurrentPageData();
    
    // 更新预览
    updatePreview();
}

// 更新图层选择
function updateLayerSelection(layerType) {
    document.querySelectorAll('.layer-item').forEach(layer => {
        layer.classList.remove('selected');
        if (layer.dataset.layer === layerType) {
            layer.classList.add('selected');
        }
    });
}

// 更新文本编辑器基于选中元素
// RGB颜色转换为十六进制
function rgbToHex(rgb) {
    // 从"rgb(r, g, b)"格式中提取r, g, b值
    const match = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    if (!match) return rgb;
    
    function hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + hex(match[1]) + hex(match[2]) + hex(match[3]);
}

function updateTextEditor(elementType) {
    // 获取文本编辑器元素
    const textInput = document.getElementById('text-input');
    const textColor = document.getElementById('text-color');
    const textBold = document.getElementById('text-bold');
    const textSize = document.getElementById('text-size');
    const textFont = document.getElementById('text-font');
    const textLineHeight = document.getElementById('text-line-height');
    const textAlignment = document.getElementById('text-align-editor');
    const textAutoWrap = document.getElementById('text-auto-wrap');
    
    // 获取预览元素
    let previewElement;
    if (elementType === 'title') {
        previewElement = document.getElementById('preview-cover-title');
    } else if (elementType === 'subtitle') {
        previewElement = document.getElementById('preview-cover-subtitle');
    } else if (elementType === 'description') {
        previewElement = document.getElementById('preview-cover-description');
    }
    
    if (previewElement && textInput) {
        // 更新文本内容，将<br>标签转换为换行符
        textInput.value = previewElement.innerHTML.replace(/<br>/g, '\n').replace(/&nbsp;/g, ' ');
        
        // 更新颜色
        if (textColor) {
            const computedColor = getComputedStyle(previewElement).color;
            textColor.value = rgbToHex(computedColor);
        }
        
        // 更新加粗状态
        if (textBold) {
            const fontWeight = getComputedStyle(previewElement).fontWeight;
            textBold.checked = fontWeight === 'bold' || parseInt(fontWeight) >= 700;
        }
        
        // 更新字体大小
        if (textSize) {
            const fontSize = getComputedStyle(previewElement).fontSize;
            const fontSizeValue = parseInt(fontSize);
            textSize.value = fontSizeValue || 24; // 默认值24px
            // 更新显示值
            const textSizeValueEl = document.getElementById('text-size-value');
            if (textSizeValueEl) {
                textSizeValueEl.textContent = fontSizeValue + 'px';
            }
        }
        
        // 更新字体
        if (textFont) {
            // 从元素状态中读取字体设置
            textFont.value = textElementStates[elementType].font || "'Yozai', serif";
        }
        
        // 更新行间距
        if (textLineHeight) {
            // 从元素状态中读取行间距设置
            const lineHeightValue = textElementStates[elementType].lineHeight || 1.2;
            textLineHeight.value = lineHeightValue;
            // 更新显示值
            const textLineHeightValueEl = document.getElementById('text-line-height-value');
            if (textLineHeightValueEl) {
                textLineHeightValueEl.textContent = lineHeightValue;
            }
        }
        
        // 更新对齐方式
        if (textAlignment) {
            const textAlign = getComputedStyle(previewElement).textAlign;
            textAlignment.value = textAlign || 'left'; // 默认值left
        }
        
        // 更新自动换行状态
        if (textAutoWrap) {
            // 根据当前元素的存储状态设置自动换行复选框
            textAutoWrap.checked = textElementStates[elementType].autoWrap || false;
            console.log('更新自动换行状态为:', textElementStates[elementType].autoWrap || false, '对于元素:', elementType);
        }
    }
}

// 更新选中元素基于文本编辑器设置
function updateSelectedElement() {
    if (!selectedElement || (selectedElement !== 'title' && selectedElement !== 'subtitle' && selectedElement !== 'description')) {
        return;
    }
    
    // 获取文本编辑器元素
    const textInput = document.getElementById('text-input');
    const textColor = document.getElementById('text-color');
    const textBold = document.getElementById('text-bold');
    const textSize = document.getElementById('text-size');
    const textFont = document.getElementById('text-font');
    const textLineHeight = document.getElementById('text-line-height');
    const textAlignment = document.getElementById('text-align-editor');
    const textAutoWrap = document.getElementById('text-auto-wrap');
    
    // 获取预览元素
    let previewElement;
    if (selectedElement === 'title') {
        previewElement = document.getElementById('preview-cover-title');
    } else if (selectedElement === 'subtitle') {
        previewElement = document.getElementById('preview-cover-subtitle');
    } else if (selectedElement === 'description') {
        previewElement = document.getElementById('preview-cover-description');
    }
    
    if (previewElement) {
        // 更新文本内容
        if (textInput) {
            // 将换行符替换为<br>标签，确保换行正确显示
            // 将空格替换为&nbsp;，确保多个连续空格不会被HTML合并
            previewElement.innerHTML = textInput.value.replace(/\n/g, '<br>').replace(/ /g, '&nbsp;');
            // 保存内容
            textElementStates[selectedElement].content = textInput.value;
        }
        
        // 更新颜色
        if (textColor) {
            previewElement.style.color = textColor.value;
            // 保存颜色
            textElementStates[selectedElement].color = textColor.value;
        }
        
        // 更新加粗状态
        if (textBold) {
            previewElement.style.fontWeight = textBold.checked ? 'bold' : 'normal';
            // 保存加粗状态
            textElementStates[selectedElement].bold = textBold.checked;
        }
        
        // 更新字体大小
        if (textSize) {
            previewElement.style.fontSize = textSize.value + 'px';
            // 保存字体大小
            textElementStates[selectedElement].size = parseInt(textSize.value);
        }
        
        // 更新字体
        if (textFont) {
            previewElement.style.fontFamily = textFont.value;
            // 保存字体
            textElementStates[selectedElement].font = textFont.value;
        }
        
        // 更新行间距
        if (textLineHeight) {
            previewElement.style.lineHeight = textLineHeight.value;
            // 保存行间距
            textElementStates[selectedElement].lineHeight = parseFloat(textLineHeight.value);
        }
        
        // 更新对齐方式
        if (textAlignment) {
            previewElement.style.textAlign = textAlignment.value;
            // 保存对齐方式
            textElementStates[selectedElement].alignment = textAlignment.value;
        }
        
        // 更新自动换行
        if (textAutoWrap) {
            // 保存当前的文本对齐方式
            const currentTextAlign = textAlignment ? textAlignment.value : 'center';
            
            // 使用当前元素的独立自动换行状态
            const isAutoWrapEnabled = textAutoWrap.checked;
            
            // 保存当前元素的自动换行状态
            textElementStates[selectedElement].autoWrap = isAutoWrapEnabled;
            
            console.log('更新元素自动换行状态:', selectedElement, isAutoWrapEnabled);
            
            if (isAutoWrapEnabled) {
                previewElement.style.whiteSpace = 'normal';
                previewElement.style.wordBreak = 'break-word';
                // 保持文本对齐方式
                previewElement.style.textAlign = currentTextAlign;
            } else {
                // 自动换行关闭时，根据元素类型设置不同的whiteSpace样式
                if (selectedElement === 'title') {
                    // 大标题使用nowrap
                    previewElement.style.whiteSpace = 'nowrap';
                } else {
                    // 小标题和内容简介保持原始的whiteSpace样式（pre）
                    previewElement.style.whiteSpace = 'pre';
                }
                previewElement.style.wordBreak = 'normal';
                // 保持文本对齐方式
                previewElement.style.textAlign = currentTextAlign;
                
                // 重置容器宽度，让它根据内容自动调整 - 只影响当前选中的元素
                if (selectedElement === 'title') {
                    const titleContainer = document.getElementById('title-container');
                    if (titleContainer) {
                        // 先移除所有宽度限制，让文本完全展开
                        titleContainer.style.width = 'auto';
                        titleContainer.style.maxWidth = 'none';
                        titleContainer.style.minWidth = '100px';
                        titleContainer.style.textAlign = currentTextAlign;
                        
                        // 强制重排，确保获取最新的宽度值
                        void titleContainer.offsetWidth;
                        
                        // 获取文本完全展开的宽度
                        let textWidth = previewElement.offsetWidth;
                        
                        // 再次强制重排，确保宽度值是最新的
                        void titleContainer.offsetWidth;
                        textWidth = previewElement.offsetWidth;
                        
                        // 设置容器宽度
                        titleContainer.style.width = textWidth + 'px';
                        titleContainer.style.maxWidth = textWidth + 'px';
                        
                        // 然后恢复nowrap
                        previewElement.style.whiteSpace = 'nowrap';
                        
                        // 再次强制重排，确保容器宽度已应用
                        void titleContainer.offsetWidth;
                        void titleContainer.offsetWidth;
                    }
                } else if (selectedElement === 'subtitle') {
                    const subtitleContainer = document.getElementById('subtitle-container');
                    if (subtitleContainer) {
                        // 先移除所有宽度限制，让文本完全展开
                        subtitleContainer.style.width = 'auto';
                        subtitleContainer.style.maxWidth = 'none';
                        subtitleContainer.style.minWidth = '100px';
                        subtitleContainer.style.textAlign = currentTextAlign;
                        
                        // 强制重排，确保获取最新的宽度值
                        void subtitleContainer.offsetWidth;
                        
                        // 获取文本实际宽度
                        let textWidth = previewElement.offsetWidth;
                        
                        // 再次强制重排，确保宽度值是最新的
                        void subtitleContainer.offsetWidth;
                        textWidth = previewElement.offsetWidth;
                        
                        // 设置容器宽度
                        subtitleContainer.style.width = textWidth + 'px';
                        subtitleContainer.style.maxWidth = textWidth + 'px';
                        
                        // 保持pre样式
                        previewElement.style.whiteSpace = 'pre';
                        
                        // 再次强制重排，确保容器宽度已应用
                        void subtitleContainer.offsetWidth;
                        void subtitleContainer.offsetWidth;
                    }
                } else if (selectedElement === 'description') {
                    const descriptionContainer = document.getElementById('description-container');
                    if (descriptionContainer) {
                        // 先移除所有宽度限制，让文本完全展开
                        descriptionContainer.style.width = 'auto';
                        descriptionContainer.style.maxWidth = 'none';
                        descriptionContainer.style.minWidth = '100px';
                        descriptionContainer.style.textAlign = currentTextAlign;
                        
                        // 强制重排，确保获取最新的宽度值
                        void descriptionContainer.offsetWidth;
                        
                        // 获取文本实际宽度
                        let textWidth = previewElement.offsetWidth;
                        
                        // 再次强制重排，确保宽度值是最新的
                        void descriptionContainer.offsetWidth;
                        textWidth = previewElement.offsetWidth;
                        
                        // 设置容器宽度
                        descriptionContainer.style.width = textWidth + 'px';
                        descriptionContainer.style.maxWidth = textWidth + 'px';
                        
                        // 保持pre样式
                        previewElement.style.whiteSpace = 'pre';
                        
                        // 再次强制重排，确保容器宽度已应用
                        void descriptionContainer.offsetWidth;
                        void descriptionContainer.offsetWidth;
                    }
                }
            }
        }
    }
    
    // 只有在自动换行关闭时才调整容器宽度
    if (!textAutoWrap || !textAutoWrap.checked) {
        adjustAllTextContainerWidths();
    }
}

// 更新配色方案区域的激活状态
function updateColorSchemeSelection() {
    // 移除所有激活状态
    document.querySelectorAll('#color-schemes .color-scheme').forEach(scheme => {
        scheme.classList.remove('active');
    });
    
    // 根据当前卡片类型设置激活状态
    const currentScheme = currentColorSchemes[currentCardType];
    const schemeElement = document.querySelector(`#color-schemes .color-scheme[data-scheme="${currentScheme}"]`);
    if (schemeElement) {
        schemeElement.classList.add('active');
    }
}

// 调整内容简介容器宽度以适配文字实际宽度
function adjustDescriptionContainerWidth() {
    const descriptionContainer = document.getElementById('description-container');
    const descriptionText = document.getElementById('preview-cover-description');
    
    if (descriptionContainer && descriptionText) {
        // 重置容器宽度，让它根据内容自动调整
        descriptionContainer.style.width = 'auto';
        descriptionContainer.style.minWidth = '100px';
        descriptionContainer.style.maxWidth = '350px';
        
        // 获取文字实际宽度
        const textWidth = descriptionText.offsetWidth;
        
        // 设置容器宽度为文字实际宽度
        descriptionContainer.style.width = textWidth + 'px';
        
        console.log('调整内容简介容器宽度:', textWidth + 'px');
    }
}

// 为每个文本元素添加独立的状态存储
let textElementStates = {
    title: {
        content: '腊八卡片生成器',
        color: '#8B0000',
        bold: false,
        size: 24,
        font: "'Yozai', serif",
        lineHeight: 1.2,
        alignment: 'center',
        autoWrap: false
    },
    subtitle: {
        content: '编程使我快乐\n制作了这个卡片生成器\n希望大家能喜欢',
        color: '#b92727',
        bold: false,
        size: 22,
        font: "'Yozai', serif",
        lineHeight: 1.2,
        alignment: 'center',
        autoWrap: false
    },
    description: {
        content: '作者小红书号：4212737469\n作者哔哩哔哩账号： 乂海狸',
        color: '#8a460f',
        bold: false,
        size: 18,
        font: "'Yozai', serif",
        lineHeight: 1.2,
        alignment: 'center',
        autoWrap: false
    }
};

// 调整所有文本容器宽度以适配文字实际宽度
function adjustAllTextContainerWidths() {
    // 直接计算宽度，不使用setTimeout，因为我们已经在调用时添加了延迟
    
    // 获取画布宽度
    const coverCard = document.getElementById('cover-card');
    const canvasWidth = coverCard ? coverCard.offsetWidth : 600; // 默认画布宽度
    
    console.log('开始调整文本容器宽度，画布宽度:', canvasWidth + 'px', '选中元素:', selectedElement);
    
    // 调整大标题容器宽度
    const titleContainer = document.getElementById('title-container');
    const titleText = document.getElementById('preview-cover-title');
    if (titleContainer && titleText) {
        // 确保文本对齐方式 - 使用元素独立的对齐方式
        const titleAlign = textElementStates.title.alignment || 'center';
        titleContainer.style.textAlign = titleAlign;
        titleText.style.textAlign = titleAlign;
        
        // 只在选中title时调整宽度
        if (selectedElement === 'title') {
            // 移除所有可能的宽度限制
            titleContainer.style.width = 'auto';
            titleContainer.style.minWidth = '100px';
            titleContainer.style.maxWidth = 'none';
            
            // 检查自动换行状态 - 使用元素独立状态
            const isAutoWrapEnabled = textElementStates.title.autoWrap || false;
            
            if (isAutoWrapEnabled) {
                // 自动换行开启时，设置最大宽度为画布宽度-30，与边界框宽度一致
                const maxWidth = canvasWidth - 30;
                titleContainer.style.width = maxWidth + 'px';
                titleContainer.style.maxWidth = maxWidth + 'px';
                console.log('大标题容器宽度设置为:', maxWidth + 'px' , '(自动换行开启)');
            } else {
                // 自动换行关闭时，直接获取文本实际宽度，大标题使用nowrap是正确的
                // 强制重排，确保获取最新的宽度值
                // 使用一个更可靠的方法来强制重排
                void titleContainer.offsetWidth;
                
                // 计算文本实际宽度
                let textWidth = titleText.offsetWidth;
                
                // 再次强制重排，确保宽度值是最新的
                void titleContainer.offsetWidth;
                textWidth = titleText.offsetWidth;
                
                console.log('大标题文本宽度:', textWidth + 'px');
                
                // 添加一些额外的空间以确保完全覆盖
                textWidth += 10;
                
                // 根据文字宽度设置容器宽度
                titleContainer.style.width = textWidth + 'px';
                titleContainer.style.maxWidth = textWidth + 'px';
                
                // 再次强制重排，确保容器宽度已应用
                void titleContainer.offsetWidth;
                
                console.log('大标题容器宽度设置为:', textWidth + 'px' , '(自动换行关闭)');
            }
        } else {
            console.log('跳过调整大标题容器宽度，因为未选中');
        }
    }
    
    // 调整小标题容器宽度
    const subtitleContainer = document.getElementById('subtitle-container');
    const subtitleText = document.getElementById('preview-cover-subtitle');
    if (subtitleContainer && subtitleText) {
        // 确保文本对齐方式 - 使用元素独立的对齐方式
        const subtitleAlign = textElementStates.subtitle.alignment || 'center';
        subtitleContainer.style.textAlign = subtitleAlign;
        subtitleText.style.textAlign = subtitleAlign;
        
        // 只在选中subtitle时调整宽度
        if (selectedElement === 'subtitle') {
            // 移除所有可能的宽度限制
            subtitleContainer.style.width = 'auto';
            subtitleContainer.style.minWidth = '100px';
            subtitleContainer.style.maxWidth = 'none';
            
            // 检查自动换行状态 - 使用元素独立状态
            const isAutoWrapEnabled = textElementStates.subtitle.autoWrap || false;
            
            if (isAutoWrapEnabled) {
                // 自动换行开启时，设置最大宽度为画布宽度-30，与边界框宽度一致
                const maxWidth = canvasWidth - 30;
                subtitleContainer.style.width = maxWidth + 'px';
                subtitleContainer.style.maxWidth = maxWidth + 'px';
                console.log('小标题容器宽度设置为:', maxWidth + 'px' , '(自动换行开启)');
            } else {
                // 自动换行关闭时，直接获取文本实际宽度，小标题使用pre样式，不应该使用nowrap
                // 强制重排，确保获取最新的宽度值
                // 使用一个更可靠的方法来强制重排
                void subtitleContainer.offsetWidth;
                
                // 计算文本实际宽度
                let textWidth = subtitleText.offsetWidth;
                
                // 再次强制重排，确保宽度值是最新的
                void subtitleContainer.offsetWidth;
                textWidth = subtitleText.offsetWidth;
                
                console.log('小标题文本宽度:', textWidth + 'px');
                
                // 添加一些额外的空间以确保完全覆盖
                textWidth += 10;
                
                // 根据文字宽度设置容器宽度
                subtitleContainer.style.width = textWidth + 'px';
                subtitleContainer.style.maxWidth = textWidth + 'px';
                
                // 再次强制重排，确保容器宽度已应用
                void subtitleContainer.offsetWidth;
                
                console.log('小标题容器宽度设置为:', textWidth + 'px' , '(自动换行关闭)');
            }
        } else {
            console.log('跳过调整小标题容器宽度，因为未选中');
        }
    }
    
    // 调整内容简介容器宽度
    const descriptionContainer = document.getElementById('description-container');
    const descriptionText = document.getElementById('preview-cover-description');
    if (descriptionContainer && descriptionText) {
        // 确保文本对齐方式 - 使用元素独立的对齐方式
        const descriptionAlign = textElementStates.description.alignment || 'center';
        descriptionContainer.style.textAlign = descriptionAlign;
        descriptionText.style.textAlign = descriptionAlign;
        
        // 只在选中description时调整宽度
        if (selectedElement === 'description') {
            // 移除所有可能的宽度限制
            descriptionContainer.style.width = 'auto';
            descriptionContainer.style.minWidth = '100px';
            descriptionContainer.style.maxWidth = 'none';
            
            // 检查自动换行状态 - 使用元素独立状态
            const isAutoWrapEnabled = textElementStates.description.autoWrap || false;
            
            if (isAutoWrapEnabled) {
                // 自动换行开启时，设置最大宽度为画布宽度-30，与边界框宽度一致
                const maxWidth = canvasWidth - 30;
                descriptionContainer.style.width = maxWidth + 'px';
                descriptionContainer.style.maxWidth = maxWidth + 'px';
                console.log('内容简介容器宽度设置为:', maxWidth + 'px' , '(自动换行开启)');
            } else {
                // 自动换行关闭时，直接获取文本实际宽度，内容简介使用pre样式，不应该使用nowrap
                // 强制重排，确保获取最新的宽度值
                // 使用一个更可靠的方法来强制重排
                void descriptionContainer.offsetWidth;
                
                // 计算文本实际宽度
                let textWidth = descriptionText.offsetWidth;
                
                // 再次强制重排，确保宽度值是最新的
                void descriptionContainer.offsetWidth;
                textWidth = descriptionText.offsetWidth;
                
                console.log('内容简介文本宽度:', textWidth + 'px');
                
                // 添加一些额外的空间以确保完全覆盖
                textWidth += 10;
                
                // 根据文字宽度设置容器宽度
                descriptionContainer.style.width = textWidth + 'px';
                descriptionContainer.style.maxWidth = textWidth + 'px';
                
                // 再次强制重排，确保容器宽度已应用
                void descriptionContainer.offsetWidth;
                
                console.log('内容简介容器宽度设置为:', textWidth + 'px' , '(自动换行关闭)');
            }
        } else {
            console.log('跳过调整内容简介容器宽度，因为未选中');
        }
    }
    
    // 调整边界框大小
    updateElementsTransform();
    
    console.log('文本容器宽度调整完成');
    console.log('各元素自动换行状态:', {
        title: textElementStates.title.autoWrap,
        subtitle: textElementStates.subtitle.autoWrap,
        description: textElementStates.description.autoWrap
    });
}

// 涂鸦功能相关变量
let doodleCanvas = null;
let doodleCtx = null;
let isDrawing = false;
let currentTool = 'brush';
let startX = 0;
let startY = 0;
let currentPath = [];
let drawHistory = [];
let historyIndex = -1;
let brushSize = 5; // 默认画笔大小为5px
let brushColor = '#00ff00'; // 默认画笔颜色为绿色
let brushOpacity = 1;
let drawMode = 'stroke';
let cornerRadius = 10;
let waveAmplitude = 15; // 默认波浪振幅
let waveFrequency = 5; // 默认波浪频率
let isDoodleLayerActive = false;

// 初始化涂鸦画布
function initDoodleCanvas() {
    doodleCanvas = document.getElementById('doodle-canvas');
    if (doodleCanvas) {
        const coverCard = document.getElementById('cover-card');
        if (coverCard) {
            // 强制计算cover-card的实际尺寸
            coverCard.style.position = 'relative';
            coverCard.style.display = 'block';
            
            // 获取cover-card的实际尺寸
            const rect = coverCard.getBoundingClientRect();
            console.log('cover-card尺寸:', rect.width, 'x', rect.height);
            
            // 设置涂鸦画布尺寸和样式
            doodleCanvas.width = rect.width;
            doodleCanvas.height = rect.height;
            doodleCanvas.style.width = rect.width + 'px';
            doodleCanvas.style.height = rect.height + 'px';
            doodleCanvas.style.position = 'absolute';
            doodleCanvas.style.top = '0';
            doodleCanvas.style.left = '0';
            doodleCanvas.style.pointerEvents = 'none';
            // 不设置固定的z-index，让图层管理系统来控制
            doodleCanvas.style.display = 'block'; // 确保画布始终显示
            
            // 确保cover-content容器的尺寸足够大
            const coverContent = document.querySelector('.cover-content');
            if (coverContent) {
                coverContent.style.width = '100%';
                coverContent.style.height = '100%';
                coverContent.style.minHeight = rect.height + 'px';
                coverContent.style.position = 'relative';
                coverContent.style.zIndex = '1';
            }
        }
        
        doodleCtx = doodleCanvas.getContext('2d');
        if (doodleCtx) {
            doodleCtx.lineCap = 'round';
            doodleCtx.lineJoin = 'round';
            
            // 绑定画布事件
            bindDoodleEvents();
            console.log('涂鸦画布初始化完成');
        }
    }
}

// 更新涂鸦画布尺寸
function updateDoodleCanvasSize() {
    if (!doodleCanvas) return;
    
    const coverCard = document.getElementById('cover-card');
    if (coverCard) {
        const rect = coverCard.getBoundingClientRect();
        console.log('更新涂鸦画布尺寸:', rect.width, 'x', rect.height);
        
        doodleCanvas.width = rect.width;
        doodleCanvas.height = rect.height;
        doodleCanvas.style.width = rect.width + 'px';
        doodleCanvas.style.height = rect.height + 'px';
        
        // 确保cover-content容器的尺寸足够大
        const coverContent = document.querySelector('.cover-content');
        if (coverContent) {
            coverContent.style.width = '100%';
            coverContent.style.height = '100%';
            coverContent.style.minHeight = rect.height + 'px';
        }
    }
}

// 绑定涂鸦事件
function bindDoodleEvents() {
    if (!doodleCanvas) return;
    
    // 鼠标按下事件
    doodleCanvas.addEventListener('mousedown', startDrawing);
    
    // 鼠标移动事件
    doodleCanvas.addEventListener('mousemove', draw);
    
    // 鼠标释放事件
    doodleCanvas.addEventListener('mouseup', stopDrawing);
    
    // 鼠标离开事件
    doodleCanvas.addEventListener('mouseout', stopDrawing);
}

// 开始绘制
function startDrawing(e) {
    // 只响应鼠标左键
    if (e.button !== 0) return;
    
    if (!doodleCanvas || !doodleCtx) return;
    
    // 阻止事件冒泡，防止触发全局拖拽逻辑
    e.stopPropagation();
    e.preventDefault();
    
    // 确保全局拖拽状态为false
    isDragging = false;
    isRotating = false;
    isScaling = false;
    
    isDrawing = true;
    const rect = doodleCanvas.getBoundingClientRect();
    startX = e.clientX - rect.left;
    startY = e.clientY - rect.top;
    currentPath = [{ x: startX, y: startY }];
    
    console.log('开始绘制，鼠标位置:', startX, startY);
}

// 绘制中
function draw(e) {
    if (!isDrawing || !doodleCanvas || !doodleCtx) return;
    
    // 阻止事件冒泡，防止触发全局拖拽逻辑
    e.stopPropagation();
    e.preventDefault();
    
    const rect = doodleCanvas.getBoundingClientRect();
    const currentX = e.clientX - rect.left;
    const currentY = e.clientY - rect.top;
    
    currentPath.push({ x: currentX, y: currentY });
    
    // 画笔模式不需要重绘路径，直接绘制
    if (currentTool === 'brush') {
        // 画笔模式 - 直接绘制
        doodleCtx.globalAlpha = brushOpacity;
        doodleCtx.strokeStyle = brushColor;
        doodleCtx.lineWidth = brushSize;
        
        doodleCtx.beginPath();
        doodleCtx.moveTo(startX, startY);
        doodleCtx.lineTo(currentX, currentY);
        doodleCtx.stroke();
        
        startX = currentX;
        startY = currentY;
    } else {
        // 图形模式 - 预览绘制
        drawShapePreview(currentX, currentY);
    }
}

// 停止绘制
function stopDrawing(e) {
    if (!isDrawing || !doodleCanvas || !doodleCtx) return;
    
    // 阻止事件冒泡，防止触发全局拖拽逻辑
    if (e) {
        e.stopPropagation();
        e.preventDefault();
    }
    
    isDrawing = false;
    
    if (currentTool !== 'brush' && e) {
        const rect = doodleCanvas.getBoundingClientRect();
        const endX = e.clientX - rect.left;
        const endY = e.clientY - rect.top;
        
        // 保存当前画布状态
        saveCanvasState();
        
        // 绘制最终图形
        drawFinalShape(endX, endY);
    } else {
        // 保存画笔绘制状态
        saveCanvasState();
    }
    
    currentPath = [];
}

// 绘制图形预览
function drawShapePreview(endX, endY) {
    if (!doodleCtx) return;
    
    // 保存当前画布状态
    redrawCanvas();
    
    doodleCtx.globalAlpha = brushOpacity;
    
    if (drawMode === 'stroke') {
        doodleCtx.strokeStyle = brushColor;
        doodleCtx.fillStyle = 'transparent';
    } else {
        doodleCtx.fillStyle = brushColor;
        doodleCtx.strokeStyle = 'transparent';
    }
    
    doodleCtx.lineWidth = brushSize;
    
    const width = Math.abs(endX - startX);
    const height = Math.abs(endY - startY);
    const x = Math.min(startX, endX);
    const y = Math.min(startY, endY);
    
    switch (currentTool) {
        case 'circle':
            doodleCtx.beginPath();
            const radius = Math.min(width, height) / 2;
            doodleCtx.arc(startX, startY, radius, 0, 2 * Math.PI);
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'ellipse':
            doodleCtx.beginPath();
            doodleCtx.ellipse(
                startX, startY, 
                width / 2, height / 2, 
                0, 0, 2 * Math.PI
            );
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'rectangle':
            doodleCtx.beginPath();
            doodleCtx.roundRect(x, y, width, height, cornerRadius);
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'triangle':
            // 绘制从中心往外拖动的等边三角形
            const triangleSize = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            const angle = Math.atan2(endY - startY, endX - startX);
            
            doodleCtx.beginPath();
            // 第一个顶点
            const x1 = startX + triangleSize * Math.cos(angle);
            const y1 = startY + triangleSize * Math.sin(angle);
            // 第二个顶点
            const x2 = startX + triangleSize * Math.cos(angle + 2 * Math.PI / 3);
            const y2 = startY + triangleSize * Math.sin(angle + 2 * Math.PI / 3);
            // 第三个顶点
            const x3 = startX + triangleSize * Math.cos(angle - 2 * Math.PI / 3);
            const y3 = startY + triangleSize * Math.sin(angle - 2 * Math.PI / 3);
            
            doodleCtx.moveTo(x1, y1);
            doodleCtx.lineTo(x2, y2);
            doodleCtx.lineTo(x3, y3);
            doodleCtx.closePath();
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'star':
            drawStar(startX, startY, Math.min(width, height) / 2);
            break;
            
        case 'wave':
            // 绘制波浪线
            drawWave(startX, startY, endX, endY);
            break;
    }
}

// 绘制最终图形
function drawFinalShape(endX, endY) {
    if (!doodleCtx) return;
    
    doodleCtx.globalAlpha = brushOpacity;
    
    if (drawMode === 'stroke') {
        doodleCtx.strokeStyle = brushColor;
        doodleCtx.fillStyle = 'transparent';
    } else {
        doodleCtx.fillStyle = brushColor;
        doodleCtx.strokeStyle = 'transparent';
    }
    
    doodleCtx.lineWidth = brushSize;
    
    const width = Math.abs(endX - startX);
    const height = Math.abs(endY - startY);
    const x = Math.min(startX, endX);
    const y = Math.min(startY, endY);
    
    switch (currentTool) {
        case 'circle':
            doodleCtx.beginPath();
            const radius = Math.min(width, height) / 2;
            doodleCtx.arc(startX, startY, radius, 0, 2 * Math.PI);
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'ellipse':
            doodleCtx.beginPath();
            doodleCtx.ellipse(
                startX, startY, 
                width / 2, height / 2, 
                0, 0, 2 * Math.PI
            );
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'rectangle':
            doodleCtx.beginPath();
            doodleCtx.roundRect(x, y, width, height, cornerRadius);
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'triangle':
            // 绘制从中心往外拖动的等边三角形
            const triangleSize = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            const angle = Math.atan2(endY - startY, endX - startX);
            
            doodleCtx.beginPath();
            // 第一个顶点
            const x1 = startX + triangleSize * Math.cos(angle);
            const y1 = startY + triangleSize * Math.sin(angle);
            // 第二个顶点
            const x2 = startX + triangleSize * Math.cos(angle + 2 * Math.PI / 3);
            const y2 = startY + triangleSize * Math.sin(angle + 2 * Math.PI / 3);
            // 第三个顶点
            const x3 = startX + triangleSize * Math.cos(angle - 2 * Math.PI / 3);
            const y3 = startY + triangleSize * Math.sin(angle - 2 * Math.PI / 3);
            
            doodleCtx.moveTo(x1, y1);
            doodleCtx.lineTo(x2, y2);
            doodleCtx.lineTo(x3, y3);
            doodleCtx.closePath();
            if (drawMode === 'stroke') doodleCtx.stroke();
            else doodleCtx.fill();
            break;
            
        case 'star':
            drawStar(startX, startY, Math.min(width, height) / 2);
            break;
    }
}

// 绘制五角星
function drawStar(cx, cy, radius) {
    if (!doodleCtx) return;
    
    doodleCtx.beginPath();
    for (let i = 0; i < 5; i++) {
        const angle = (i * 2 * Math.PI / 5) - Math.PI / 2;
        const x = cx + radius * Math.cos(angle);
        const y = cy + radius * Math.sin(angle);
        
        if (i === 0) {
            doodleCtx.moveTo(x, y);
        } else {
            doodleCtx.lineTo(x, y);
        }
        
        // 内点
        const innerAngle = ((i + 0.5) * 2 * Math.PI / 5) - Math.PI / 2;
        const innerX = cx + (radius / 2) * Math.cos(innerAngle);
        const innerY = cy + (radius / 2) * Math.sin(innerAngle);
        doodleCtx.lineTo(innerX, innerY);
    }
    
    doodleCtx.closePath();
    if (drawMode === 'stroke') {
        doodleCtx.stroke();
    } else {
        doodleCtx.fill();
    }
}

// 绘制波浪线
function drawWave(startX, startY, endX, endY) {
    if (!doodleCtx) return;
    
    doodleCtx.beginPath();
    
    const length = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
    // 使用全局变量作为波浪振幅和频率
    const amplitude = Math.min(waveAmplitude, length / 4); // 限制振幅最大为长度的1/4
    const frequency = waveFrequency;
    
    // 计算方向向量
    const dx = endX - startX;
    const dy = endY - startY;
    
    // 绘制波浪线
    for (let t = 0; t <= 1; t += 0.01) {
        const x = startX + t * dx;
        const y = startY + t * dy + amplitude * Math.sin(t * frequency * Math.PI * 2);
        
        if (t === 0) {
            doodleCtx.moveTo(x, y);
        } else {
            doodleCtx.lineTo(x, y);
        }
    }
    
    if (drawMode === 'stroke') {
        doodleCtx.stroke();
    } else {
        // 波浪线不支持填充模式
        doodleCtx.stroke();
    }
}

// 重绘画布
function redrawCanvas() {
    if (!doodleCanvas || !doodleCtx) return;
    
    // 确保画布是可见的
    if (doodleCanvas.style.display === 'none') {
        // 检查涂鸦图层是否被用户手动隐藏
        const doodleLayerItem = document.querySelector('.layer-item[data-layer="doodle"]');
        const doodleVisibility = doodleLayerItem.querySelector('.layer-visibility');
        if (!doodleVisibility || !doodleVisibility.classList.contains('hidden')) {
            doodleCanvas.style.display = 'block';
        }
    }
    
    // 清空画布
    doodleCtx.clearRect(0, 0, doodleCanvas.width, doodleCanvas.height);
    
    // 重绘历史记录
    if (drawHistory.length > 0 && historyIndex >= 0) {
        const currentState = drawHistory[historyIndex];
        const img = new Image();
        img.onload = function() {
            // 绘制图片
            doodleCtx.drawImage(img, 0, 0);
            // 强制浏览器重绘
            doodleCanvas.style.display = 'none';
            void doodleCanvas.offsetWidth; // 触发重排
            doodleCanvas.style.display = 'block';
            // 再次强制重绘，确保内容显示
            doodleCanvas.style.transform = 'translateZ(0)';
            void doodleCanvas.offsetWidth;
            doodleCanvas.style.transform = '';
        };
        img.onerror = function() {
            console.error('无法加载画布历史记录图片');
            // 即使加载失败也确保画布可见
            doodleCanvas.style.display = 'block';
            doodleCanvas.style.transform = 'translateZ(0)';
            void doodleCanvas.offsetWidth;
        };
        img.src = currentState;
    } else {
        // 如果没有历史记录，确保画布是空的
        doodleCtx.clearRect(0, 0, doodleCanvas.width, doodleCanvas.height);
        // 强制浏览器重绘
        doodleCanvas.style.display = 'none';
        void doodleCanvas.offsetWidth;
        doodleCanvas.style.display = 'block';
    }
    
    // 确保画布的z-index正确，防止被其他元素遮挡
    setTimeout(() => {
        if (doodleCanvas.style.display !== 'none') {
            // 再次确保画布可见
            doodleCanvas.style.display = 'block';
            // 强制浏览器重绘
            doodleCanvas.style.transform = 'translateZ(0)';
            void doodleCanvas.offsetWidth;
            doodleCanvas.style.transform = '';
        }
    }, 10);
}

// 保存画布状态
function saveCanvasState() {
    if (!doodleCanvas) return;
    
    const state = doodleCanvas.toDataURL('image/png');
    
    // 截断历史记录
    if (historyIndex < drawHistory.length - 1) {
        drawHistory = drawHistory.slice(0, historyIndex + 1);
    }
    
    // 添加新状态
    drawHistory.push(state);
    
    // 限制历史记录长度
    if (drawHistory.length > 20) {
        drawHistory.shift();
    } else {
        historyIndex++;
    }
}

// 清空涂鸦
function clearDoodle() {
    if (!doodleCanvas || !doodleCtx) return;
    
    saveCanvasState();
    doodleCtx.clearRect(0, 0, doodleCanvas.width, doodleCanvas.height);
    drawHistory = [];
    historyIndex = -1;
}

// 撤销操作
function undoDoodle() {
    if (historyIndex > 0) {
        historyIndex--;
        redrawCanvas();
    }
}

// 重做操作
function redoDoodle() {
    if (historyIndex < drawHistory.length - 1) {
        historyIndex++;
        redrawCanvas();
    }
}

// 绑定工具选择事件
function bindToolEvents() {
    // 工具选择按钮
    const toolButtons = document.querySelectorAll('[data-tool]');
    toolButtons.forEach(button => {
        button.addEventListener('click', function() {
            // 更新按钮状态
            toolButtons.forEach(btn => {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-secondary');
            });
            this.classList.remove('btn-secondary');
            this.classList.add('btn-primary');
            
            // 设置当前工具
            currentTool = this.dataset.tool;
            console.log('选择工具:', currentTool);
        });
    });
    
    // 画笔大小调整
    const brushSizeInput = document.getElementById('brush-size');
    const brushSizeValue = document.getElementById('brush-size-value');
    if (brushSizeInput && brushSizeValue) {
        brushSizeInput.addEventListener('input', function() {
            brushSize = parseInt(this.value);
            brushSizeValue.textContent = brushSize + 'px';
        });
    }
    
    // 画笔颜色选择
    const brushColorInput = document.getElementById('brush-color');
    if (brushColorInput) {
        brushColorInput.addEventListener('input', function() {
            brushColor = this.value;
        });
    }
    
    // 画笔透明度调整
    const brushOpacityInput = document.getElementById('brush-opacity');
    const brushOpacityValue = document.getElementById('brush-opacity-value');
    if (brushOpacityInput && brushOpacityValue) {
        brushOpacityInput.addEventListener('input', function() {
            brushOpacity = parseInt(this.value) / 100;
            brushOpacityValue.textContent = this.value + '%';
        });
    }
    
    // 绘制模式切换
    const drawModeSelect = document.getElementById('draw-mode');
    if (drawModeSelect) {
        drawModeSelect.addEventListener('change', function() {
            drawMode = this.value;
        });
    }
    
    // 圆角大小调整
    const cornerRadiusInput = document.getElementById('corner-radius');
    const cornerRadiusValue = document.getElementById('corner-radius-value');
    if (cornerRadiusInput && cornerRadiusValue) {
        cornerRadiusInput.addEventListener('input', function() {
            cornerRadius = parseInt(this.value);
            cornerRadiusValue.textContent = cornerRadius + 'px';
        });
    }
    
    // 波浪振幅调整
    const waveAmplitudeInput = document.getElementById('wave-amplitude');
    const waveAmplitudeValue = document.getElementById('wave-amplitude-value');
    if (waveAmplitudeInput && waveAmplitudeValue) {
        waveAmplitudeInput.addEventListener('input', function() {
            waveAmplitude = parseInt(this.value);
            waveAmplitudeValue.textContent = waveAmplitude + 'px';
        });
    }
    
    // 波浪波长调整
    const waveFrequencyInput = document.getElementById('wave-frequency');
    const waveFrequencyValue = document.getElementById('wave-frequency-value');
    if (waveFrequencyInput && waveFrequencyValue) {
        waveFrequencyInput.addEventListener('input', function() {
            waveFrequency = parseFloat(this.value);
            waveFrequencyValue.textContent = waveFrequency;
        });
    }
    
    // 清空涂鸦按钮
    const clearDoodleBtn = document.getElementById('clear-doodle');
    if (clearDoodleBtn) {
        clearDoodleBtn.addEventListener('click', clearDoodle);
    }
    
    // 撤销按钮
    const undoDoodleBtn = document.getElementById('undo-doodle');
    if (undoDoodleBtn) {
        undoDoodleBtn.addEventListener('click', undoDoodle);
    }
    
    // 重做按钮
    const redoDoodleBtn = document.getElementById('redo-doodle');
    if (redoDoodleBtn) {
        redoDoodleBtn.addEventListener('click', redoDoodle);
    }
}

// 切换涂鸦层激活状态
function toggleDoodleLayer(active) {
    const doodleCanvas = document.getElementById('doodle-canvas');
    if (doodleCanvas) {
        if (active) {
            doodleCanvas.classList.add('active');
            doodleCanvas.style.pointerEvents = 'auto';
        } else {
            doodleCanvas.classList.remove('active');
            doodleCanvas.style.pointerEvents = 'none';
        }
    }
}

// 解析文档内容并生成卡片
function parseDocumentContent(content) {
    // 解析逻辑：
    // 1. 封面内容格式1：##大标题｜小标题｜内容简介##
    // 2. 封面内容格式2：# 大标题
    // 3. 卡片内容格式：## 卡片1：卡片标题
    // 4. 卡片内容：从卡片标题后到下一个卡片标签前的所有内容
    
    console.log('开始解析文档内容:', content.substring(0, 100) + '...');
    
    // 提取封面信息
    let cover = null;
    
    // 尝试匹配格式1：##大标题｜小标题｜内容简介##
    const coverMatch1 = content.match(/^##(.*?)##/s);
    if (coverMatch1) {
        const coverContent = coverMatch1[1].trim();
        const coverParts = coverContent.split('｜').map(part => part.trim());
        
        if (coverParts.length >= 3) {
            cover = {
                mainTitle: coverParts[0],
                subTitle: coverParts[1],
                description: coverParts[2]
            };
            console.log('识别到封面信息（格式1）:', cover);
        } else {
            showStatus('封面格式不正确，需要包含大标题｜小标题｜内容简介', 'error');
            return;
        }
    } else {
        // 尝试匹配格式2：# 大标题
        const coverMatch2 = content.match(/^#\s*(.*)$/m);
        if (coverMatch2) {
            const mainTitle = coverMatch2[1].trim();
            cover = {
                mainTitle: mainTitle,
                subTitle: '',
                description: ''
            };
            console.log('识别到封面信息（格式2）:', cover);
        } else {
            showStatus('未识别到封面内容，请检查文档格式', 'error');
            return;
        }
    }
    
    // 提取卡片信息
    const cards = [];
    let currentCard = null;
    let currentContent = [];
    
    // 按行分割内容
    const lines = content.split('\n');
    
    // 从第一行开始解析卡片
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmedLine = line.trim();
        
        // 匹配卡片标签：## 卡片1：卡片标题
        const cardMatch = trimmedLine.match(/^##\s*卡片(\d+)[：:]\s*(.*)$/);
        
        if (cardMatch) {
            // 如果已经有当前卡片，保存它
            if (currentCard) {
                currentCard.content = currentContent.join('\n').trim();
                cards.push(currentCard);
                console.log('保存卡片:', currentCard.title);
            }
            
            // 创建新卡片
            currentCard = {
                title: cardMatch[2].trim(), // 标签后面的内容作为标题
                content: ''
            };
            currentContent = [];
            console.log('识别到卡片:', cardMatch[1], '标题:', currentCard.title);
        } else if (currentCard) {
            // 如果有当前卡片，添加内容（包括空行以保留段落结构）
            currentContent.push(line);
        }
    }
    
    // 保存最后一张卡片
    if (currentCard) {
        currentCard.content = currentContent.join('\n').trim();
        cards.push(currentCard);
        console.log('保存最后一张卡片:', currentCard.title);
    }
    
    // 检查是否有卡片
    if (cards.length === 0) {
        showStatus('未识别到卡片内容，请检查文档格式', 'error');
        return;
    }
    
    console.log('解析完成，共识别到', cards.length, '张卡片:', cards.map(card => card.title));
    
    // 导入生成的卡片和封面内容
    importCards(cards, cover);
    
    showStatus(`成功从文档导入 ${cards.length} 张卡片和封面内容`, 'success');
}

// 解析transform字符串获取x和y偏移值
function parseTransform(transformString) {
    // 匹配translate值的正则表达式
    const translateMatch = transformString.match(/translate\(([^)]+)\)/);
    if (translateMatch) {
        const translateValues = translateMatch[1].split(',').map(val => parseFloat(val.trim()));
        return {
            x: translateValues[0] || 0,
            y: translateValues[1] || 0
        };
    }
    return { x: 0, y: 0 };
}

// 获取并更新文字元素的默认位置
function updateDefaultTextPositions() {
    const titleContainer = document.getElementById('title-container');
    const subtitleContainer = document.getElementById('subtitle-container');
    const descriptionContainer = document.getElementById('description-container');
    
    // 获取计算样式并更新默认位置
    if (titleContainer) {
        const titleStyle = getComputedStyle(titleContainer);
        const titleTransform = parseTransform(titleStyle.transform);
        // 更新默认位置值
        coverElementsTransform.title.x = titleTransform.x;
        coverElementsTransform.title.y = titleTransform.y;
        console.log('大标题默认位置已更新:', coverElementsTransform.title);
    }
    
    if (subtitleContainer) {
        const subtitleStyle = getComputedStyle(subtitleContainer);
        const subtitleTransform = parseTransform(subtitleStyle.transform);
        // 更新默认位置值
        coverElementsTransform.subtitle.x = subtitleTransform.x;
        coverElementsTransform.subtitle.y = subtitleTransform.y;
        console.log('小标题默认位置已更新:', coverElementsTransform.subtitle);
    }
    
    if (descriptionContainer) {
        const descriptionStyle = getComputedStyle(descriptionContainer);
        const descriptionTransform = parseTransform(descriptionStyle.transform);
        // 更新默认位置值
        coverElementsTransform.description.x = descriptionTransform.x;
        coverElementsTransform.description.y = descriptionTransform.y;
        console.log('内容简介默认位置已更新:', coverElementsTransform.description);
    }
    
    console.log('默认位置已更新为当前预览位置');
}

// AI助手相关功能

// 全局变量存储API设置
let llmApiSettings = {
    provider: 'openai',
    apiKey: '',
    isConnected: false
};

// 从localStorage加载API设置
function loadApiSettings() {
    try {
        const savedSettings = localStorage.getItem('llmApiSettings');
        if (savedSettings) {
            llmApiSettings = JSON.parse(savedSettings);
            console.log('已加载保存的API设置');
            // 更新UI
            updateApiSettingsUI();
        }
    } catch (error) {
        console.error('加载API设置失败:', error);
    }
}

// 保存API设置到localStorage
function saveApiSettings() {
    try {
        localStorage.setItem('llmApiSettings', JSON.stringify(llmApiSettings));
        console.log('API设置已保存');
    } catch (error) {
        console.error('保存API设置失败:', error);
    }
}

// 更新API设置UI
function updateApiSettingsUI() {
    const apiProvider = document.getElementById('api-provider');
    const apiKey = document.getElementById('api-key');
    if (apiProvider) {
        apiProvider.value = llmApiSettings.provider;
    }
    if (apiKey) {
        apiKey.value = llmApiSettings.apiKey;
    }
}

// 验证API连接
async function validateApiConnection() {
    const statusElement = document.getElementById('parse-status');
    if (statusElement) {
        statusElement.textContent = '正在验证API连接...';
        statusElement.style.color = '#007bff';
    }
    
    if (!llmApiSettings.apiKey) {
        if (statusElement) {
            statusElement.textContent = '请输入API Key';
            statusElement.style.color = '#dc3545';
        }
        return false;
    }
    
    try {
        let response;
        
        switch (llmApiSettings.provider) {
            case 'openai':
                // 验证OpenAI API
                response = await fetch('https://api.openai.com/v1/models', {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${llmApiSettings.apiKey}`,
                        'Content-Type': 'application/json'
                    }
                });
                break;
            case 'anthropic':
                // 验证Anthropic API
                response = await fetch('https://api.anthropic.com/v1/models', {
                    method: 'GET',
                    headers: {
                        'x-api-key': llmApiSettings.apiKey,
                        'Content-Type': 'application/json',
                        'anthropic-version': '2023-06-01'
                    }
                });
                break;
            case 'google':
                // 验证Google Gemini API
                response = await fetch('https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash-lite:generateContent', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'x-goog-api-key': llmApiSettings.apiKey
                    },
                    body: JSON.stringify({
                        contents: [{
                            parts: [{
                                text: 'Hello'
                            }]
                        }]
                    })
                });
                break;
            case 'deepseek':
                // 验证DeepSeek API
                response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${llmApiSettings.apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        model: 'deepseek-chat',
                        messages: [
                            {
                                role: 'user',
                                content: 'Hello'
                            }
                        ],
                        max_tokens: 10
                    })
                });
                break;
            default:
                throw new Error('不支持的API提供商');
        }
        
        if (response.ok) {
            llmApiSettings.isConnected = true;
            if (statusElement) {
                statusElement.textContent = 'API连接成功';
                statusElement.style.color = '#28a745';
            }
            console.log('API连接验证成功');
            return true;
        } else {
            llmApiSettings.isConnected = false;
            const errorText = await response.text();
            if (statusElement) {
                statusElement.textContent = 'API连接失败: ' + errorText;
                statusElement.style.color = '#dc3545';
            }
            console.error('API连接验证失败:', errorText);
            return false;
        }
    } catch (error) {
        llmApiSettings.isConnected = false;
        if (statusElement) {
            statusElement.textContent = 'API连接错误: ' + error.message;
            statusElement.style.color = '#dc3545';
        }
        console.error('API连接验证错误:', error);
        return false;
    }
}

// 显示加载状态
function showLoading() {
    const parseBtnText = document.getElementById('parse-btn-text');
    const parseBtnLoading = document.getElementById('parse-btn-loading');
    const parseNewsBtn = document.getElementById('parse-news-btn');
    
    if (parseBtnText) parseBtnText.style.display = 'none';
    if (parseBtnLoading) parseBtnLoading.style.display = 'inline-block';
    if (parseNewsBtn) parseNewsBtn.disabled = true;
}

// 隐藏加载状态
function hideLoading() {
    const parseBtnText = document.getElementById('parse-btn-text');
    const parseBtnLoading = document.getElementById('parse-btn-loading');
    const parseNewsBtn = document.getElementById('parse-news-btn');
    
    if (parseBtnText) parseBtnText.style.display = 'inline-block';
    if (parseBtnLoading) parseBtnLoading.style.display = 'none';
    if (parseNewsBtn) parseNewsBtn.disabled = false;
}

// 抓取新闻内容函数已移除，改为直接使用文本框内容

// 生成卡片
async function parseNews() {
    const newsContent = document.getElementById('news-content').value;
    const statusElement = document.getElementById('parse-status');
    
    if (!newsContent) {
        if (statusElement) {
            statusElement.textContent = '请输入新闻内容';
            statusElement.style.color = '#dc3545';
        }
        return;
    }
    
    // 显示加载状态
    showLoading();
    
    // 验证API连接
    const isConnected = await validateApiConnection();
    if (!isConnected) {
        hideLoading();
        return;
    }
    
    if (statusElement) {
        statusElement.textContent = '正在生成卡片...';
        statusElement.style.color = '#007bff';
    }
    
    try {
        console.log('开始生成卡片，新闻内容长度:', newsContent.length);
        
        // 调用大语言模型API来生成卡片
        const result = await generateCardsFromNews(newsContent);
        
        // 检查result是否有效
        if (!result || !Array.isArray(result.cards)) {
            throw new Error('API返回的数据格式不正确');
        }
        
        // 导入生成的卡片和封面内容
        importCards(result.cards, result.cover);
        
        if (statusElement) {
            statusElement.textContent = `成功生成 ${result.cards.length} 张卡片和封面内容`;
            statusElement.style.color = '#28a745';
        }
        console.log('卡片生成完成，生成了', result.cards.length, '张卡片和封面内容');
    } catch (error) {
        if (statusElement) {
            statusElement.textContent = '生成失败: ' + error.message;
            statusElement.style.color = '#dc3545';
        }
        console.error('卡片生成错误:', error);
    } finally {
        // 隐藏加载状态
        hideLoading();
    }
}

// 初始化AI助手功能
function initAiAssistant() {
    // 加载保存的API设置
    loadApiSettings();
    
    // API提供商选择事件
    const apiProvider = document.getElementById('api-provider');
    if (apiProvider) {
        apiProvider.addEventListener('change', function() {
            llmApiSettings.provider = this.value;
            saveApiSettings();
        });
    }
    
    // API Key输入事件
    const apiKey = document.getElementById('api-key');
    if (apiKey) {
        apiKey.addEventListener('input', function() {
            llmApiSettings.apiKey = this.value;
            saveApiSettings();
        });
    }
    
    // 解析新闻按钮点击事件
    const parseNewsBtn = document.getElementById('parse-news-btn');
    if (parseNewsBtn) {
        parseNewsBtn.addEventListener('click', parseNews);
    }
    
    console.log('AI助手功能已初始化');
}

// 导入卡片到卡片生成器
function importCards(cards, cover) {
    // 检查cards是否有效
    if (!cards || !Array.isArray(cards) || cards.length === 0) {
        console.error('没有可导入的卡片');
        return;
    }
    
    // 处理封面内容
    if (cover) {
        // 更新封面大标题
        const coverMainTitle = document.getElementById('text-input');
        const previewCoverTitle = document.getElementById('preview-cover-title');
        if (coverMainTitle) {
            coverMainTitle.value = cover.mainTitle || '大标题';
        }
        if (previewCoverTitle) {
            previewCoverTitle.textContent = cover.mainTitle || '大标题';
        }
        
        // 更新封面小标题
        const coverSubTitle = document.getElementById('cover-sub-title');
        const previewCoverSubtitle = document.getElementById('preview-cover-subtitle');
        if (coverSubTitle) {
            coverSubTitle.value = cover.subTitle || '小标题';
        }
        if (previewCoverSubtitle) {
            previewCoverSubtitle.textContent = cover.subTitle || '小标题';
        }
        
        // 更新封面内容简介
        const coverDescription = document.getElementById('cover-description');
        const previewCoverDescription = document.getElementById('preview-cover-description');
        if (coverDescription) {
            coverDescription.value = cover.description || '内容简介';
        }
        if (previewCoverDescription) {
            previewCoverDescription.textContent = cover.description || '内容简介';
        }
        
        console.log('成功导入封面内容:', cover);
    }
    
    // 清空现有的卡片数据
    cardData = [];
    
    // 将生成的卡片添加到cardData数组
    cards.forEach((card, index) => {
        cardData.push({
            title: card.title || `卡片 ${index + 1}`,
            content: card.content || ''
        });
    });
    
    // 更新总页数
    totalPages = cardData.length;
    
    // 重置当前页码为第一页
    currentPage = 1;
    
    // 更新页码显示
    updatePageInfo();
    
    // 加载第一页数据
    loadCurrentPageData();
    
    // 切换到内容卡片模式
    currentCardType = 'content';
    const contentCardBtn = document.getElementById('content-card-btn');
    if (contentCardBtn) {
        contentCardBtn.click();
    }
    
    console.log('成功导入', cards.length, '张卡片');
}

// 从新闻内容生成卡片
async function generateCardsFromNews(newsContent) {
    // 获取用户额外要求
    const userRequirementsElement = document.getElementById('user-requirements');
    const userRequirements = userRequirementsElement ? userRequirementsElement.value.trim() : '';
    
    // 设计提示词模板，处理用户直接输入的新闻内容
    let prompt = `请严格按照以下步骤处理新闻内容：

步骤1：仔细阅读以下新闻内容
步骤2：基于你阅读的新闻内容，创建一个封面和多张卡片
步骤3：封面必须包含以下内容：
1. 一个引人注目的大标题（使用新闻中的关键信息）
2. 一个简洁的小标题（概括新闻的核心内容）
3. 一个具有争议性或话题性的内容简介（基于新闻事实，引发读者讨论）

步骤4：每张卡片必须满足以下要求：
1. 每张卡片必须有一个清晰、准确的标题
2. 每张卡片的内容字数不超过300字
3. 内容必须直接来自新闻原文，不要添加任何额外的分析、评论或个人观点
4. 内容应该简洁明了，适合在卡片中展示
5. 请按照新闻的逻辑结构，将内容分成合理的卡片

步骤5：请返回JSON格式的数据，格式如下：

{
  "originalContent": "${newsContent}",
  "cover": {
    "mainTitle": "封面大标题",
    "subTitle": "封面小标题",
    "description": "具有争议性的内容简介"
  },
  "cards": [
    {
      "title": "卡片标题1",
      "content": "卡片内容1"
    },
    {
      "title": "卡片标题2",
      "content": "卡片内容2"
    }
  ]
}

重要要求：
- 只使用新闻中的实际内容，不要编造任何信息
- 确保封面和卡片内容与新闻原文完全对应
- 保持新闻的事实性和准确性
- 封面的内容简介应该具有争议性或话题性，引发读者讨论
- 不要添加任何引言或开场白
`;
    
    // 添加用户额外要求
    if (userRequirements) {
        prompt += `
用户额外要求：
${userRequirements}
`;
    }
    
    prompt += `
新闻内容：
${newsContent}`;
    
    try {
        let response, data;
        
        switch (llmApiSettings.provider) {
            case 'openai':
                // 构建请求参数
                const openaiRequest = {
                    model: 'gpt-3.5-turbo',
                    messages: [
                        {
                            role: 'system',
                            content: '你是一个专业的新闻分析助手，擅长将新闻内容转换为结构化的卡片形式。'
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    response_format: {
                        type: 'json_object'
                    }
                };
                
                // 打印请求参数
                console.log('发送给OpenAI API的请求:', JSON.stringify(openaiRequest, null, 2));
                
                // 调用OpenAI API
                response = await fetch('https://api.openai.com/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${llmApiSettings.apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(openaiRequest)
                });
                
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error('OpenAI API请求失败: ' + errorText);
                }
                
                data = await response.json();
                
                // 检查返回的数据结构
                if (!data || !data.choices || !Array.isArray(data.choices) || data.choices.length === 0 || 
                    !data.choices[0].message || !data.choices[0].message.content) {
                    throw new Error('OpenAI API返回的数据格式不正确');
                }
                
                const content = data.choices[0].message.content;
                
                // 检查content是否包含cards数组
                if (content.cards && Array.isArray(content.cards)) {
                    // 打印返回的原始内容，包括原文和网址
                    console.log('OpenAI API返回的完整内容:', JSON.stringify(content, null, 2));
                    
                    // 提取并打印原文内容
                    if (content.originalContent) {
                        console.log('OpenAI API返回的原文内容:', content.originalContent);
                    }
                    
                    // 提取并打印原始网址
                    if (content.originalUrl) {
                        console.log('OpenAI API返回的原始网址:', content.originalUrl);
                    }
                    
                    return content;
                } else {
                    throw new Error('OpenAI API返回的数据中没有cards数组');
                }
                
            case 'anthropic':
                // 构建请求参数
                const anthropicRequest = {
                    model: 'claude-3-opus-20240229',
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    max_tokens: 4096,
                    temperature: 0
                };
                
                // 打印请求参数
                console.log('发送给Anthropic API的请求:', JSON.stringify(anthropicRequest, null, 2));
                
                // 调用Anthropic API
                response = await fetch('https://api.anthropic.com/v1/messages', {
                    method: 'POST',
                    headers: {
                        'x-api-key': llmApiSettings.apiKey,
                        'Content-Type': 'application/json',
                        'anthropic-version': '2023-06-01'
                    },
                    body: JSON.stringify(anthropicRequest)
                });
                
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error('Anthropic API请求失败: ' + errorText);
                }
                
                data = await response.json();
                
                // 检查返回的数据结构
                if (!data || !data.content || !Array.isArray(data.content) || data.content.length === 0 || 
                    !data.content[0].text) {
                    throw new Error('Anthropic API返回的数据格式不正确');
                }
                
                // 解析Claude返回的JSON字符串
                const claudeContent = data.content[0].text;
                const parsedContent = JSON.parse(claudeContent);
                
                // 检查解析后的数据结构
                if (!parsedContent || !parsedContent.cards || !Array.isArray(parsedContent.cards)) {
                    throw new Error('Anthropic API返回的卡片数据格式不正确');
                }
                
                // 打印返回的原始内容，包括原文和网址
                console.log('Anthropic API返回的完整内容:', JSON.stringify(parsedContent, null, 2));
                
                // 提取并打印原文内容
                if (parsedContent.originalContent) {
                    console.log('Anthropic API返回的原文内容:', parsedContent.originalContent);
                }
                
                // 提取并打印原始网址
                if (parsedContent.originalUrl) {
                    console.log('Anthropic API返回的原始网址:', parsedContent.originalUrl);
                }
                
                return parsedContent;
                
            case 'google':
                // 构建请求参数
                const googleRequest = {
                    contents: [{
                        parts: [{
                            text: prompt
                        }]
                    }],
                    generationConfig: {
                        responseMimeType: 'application/json'
                    }
                };
                
                // 打印请求参数
                console.log('发送给Google Gemini API的请求:', JSON.stringify(googleRequest, null, 2));
                
                // 调用Google Gemini API
                response = await fetch('https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash-lite:generateContent', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'x-goog-api-key': llmApiSettings.apiKey
                    },
                    body: JSON.stringify(googleRequest)
                });
                
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error('Google Gemini API请求失败: ' + errorText);
                }
                
                data = await response.json();
                
                // 检查返回的数据结构
                if (!data || !data.candidates || !Array.isArray(data.candidates) || data.candidates.length === 0 || 
                    !data.candidates[0].content || !data.candidates[0].content.parts || 
                    !Array.isArray(data.candidates[0].content.parts) || data.candidates[0].content.parts.length === 0 || 
                    !data.candidates[0].content.parts[0].text) {
                    throw new Error('Google Gemini API返回的数据格式不正确');
                }
                
                const geminiContent = data.candidates[0].content.parts[0].text;
                const parsedGeminiContent = JSON.parse(geminiContent);
                
                // 检查解析后的数据结构
                if (!parsedGeminiContent || !parsedGeminiContent.cards || !Array.isArray(parsedGeminiContent.cards)) {
                    throw new Error('Google Gemini API返回的卡片数据格式不正确');
                }
                
                // 打印返回的原始内容，包括原文和网址
                console.log('Google Gemini API返回的完整内容:', JSON.stringify(parsedGeminiContent, null, 2));
                
                // 提取并打印原文内容
                if (parsedGeminiContent.originalContent) {
                    console.log('Google Gemini API返回的原文内容:', parsedGeminiContent.originalContent);
                }
                
                // 提取并打印原始网址
                if (parsedGeminiContent.originalUrl) {
                    console.log('Google Gemini API返回的原始网址:', parsedGeminiContent.originalUrl);
                }
                
                return parsedGeminiContent;
                
            case 'deepseek':
                // 构建请求参数
                const deepseekRequest = {
                    model: 'deepseek-chat',
                    messages: [
                        {
                            role: 'system',
                            content: '你是一个专业的新闻分析助手，擅长将新闻内容转换为结构化的卡片形式。'
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    response_format: {
                        type: 'json_object'
                    }
                };
                
                // 打印请求参数
                console.log('发送给DeepSeek API的请求:', JSON.stringify(deepseekRequest, null, 2));
                
                // 调用DeepSeek API
                response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${llmApiSettings.apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(deepseekRequest)
                });
                
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error('DeepSeek API请求失败: ' + errorText);
                }
                
                data = await response.json();
                
                // 打印返回的数据结构，以便调试
                console.log('DeepSeek API返回的数据:', JSON.stringify(data, null, 2));
                
                // 检查返回的数据结构
                if (!data) {
                    throw new Error('DeepSeek API返回的数据为空');
                }
                
                // 处理不同的返回格式
                if (data.choices && Array.isArray(data.choices) && data.choices.length > 0) {
                    const choice = data.choices[0];
                    
                    if (choice.message && choice.message.content) {
                        const content = choice.message.content;
                        
                        // 检查content是否直接包含cards数组
                        if (content.cards && Array.isArray(content.cards)) {
                            // 打印返回的原始内容，包括原文和网址
                            console.log('DeepSeek API返回的完整内容:', JSON.stringify(content, null, 2));
                            
                            // 提取并打印原文内容
                            if (content.originalContent) {
                                console.log('DeepSeek API返回的原文内容:', content.originalContent);
                            }
                            
                            // 提取并打印原始网址
                            if (content.originalUrl) {
                                console.log('DeepSeek API返回的原始网址:', content.originalUrl);
                            }
                            
                            return content;
                        }
                        // 检查content是否是字符串，可能需要解析
                        else if (typeof content === 'string') {
                            try {
                                const parsedContent = JSON.parse(content);
                                if (parsedContent.cards && Array.isArray(parsedContent.cards)) {
                                    // 打印返回的原始内容，包括原文和网址
                                    console.log('DeepSeek API返回的完整内容:', JSON.stringify(parsedContent, null, 2));
                                    
                                    // 提取并打印原文内容
                                    if (parsedContent.originalContent) {
                                        console.log('DeepSeek API返回的原文内容:', parsedContent.originalContent);
                                    }
                                    
                                    // 提取并打印原始网址
                                    if (parsedContent.originalUrl) {
                                        console.log('DeepSeek API返回的原始网址:', parsedContent.originalUrl);
                                    }
                                    
                                    return parsedContent;
                                } else {
                                    throw new Error('DeepSeek API返回的JSON字符串中没有cards数组');
                                }
                            } catch (parseError) {
                                throw new Error('DeepSeek API返回的内容不是有效的JSON字符串');
                            }
                        } else {
                            throw new Error('DeepSeek API返回的message.content格式不正确');
                        }
                    } else {
                        throw new Error('DeepSeek API返回的choice中没有message或content');
                    }
                } else {
                    throw new Error('DeepSeek API返回的数据中没有有效的choices');
                }
                
            default:
                throw new Error('不支持的API提供商');
        }
    } catch (error) {
        console.error('生成卡片时出错:', error);
        throw error;
    }
}

// 在DOM加载完成后初始化AI助手功能
document.addEventListener('DOMContentLoaded', function() {
    initAiAssistant();
});

